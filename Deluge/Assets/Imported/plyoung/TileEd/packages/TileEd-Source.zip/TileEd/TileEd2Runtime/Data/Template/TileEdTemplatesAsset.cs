﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdTemplatesAsset : ScriptableObject
	{
		public List<TileEdTemplate> templates = new List<TileEdTemplate>();

		// ------------------------------------------------------------------------------------------------------------
    }
}
