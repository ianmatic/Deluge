﻿using UnityEngine;
using UnityEditor;
using plyLib;

namespace TileEd
{
	[CustomEditor(typeof(TileEdMapAsset))]
	public class TileEdMapAssetInspector : Editor
	{
		public override void OnInspectorGUI()
		{
			GUILayout.Label("TileEd Data. Do not edit this asset.");
			//DrawDefaultInspector();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
