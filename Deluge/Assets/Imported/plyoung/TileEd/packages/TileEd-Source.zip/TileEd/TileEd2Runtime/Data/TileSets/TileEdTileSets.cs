﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdTileSet
	{
		public enum Type { Simple, Auto }
		public enum AutoType { Rotating, Directional } 
		public enum WallPivot { Terrain, Dungeon, Narrow }

		public int ident;
		public string name;
		public Type type = Type.Simple;
		public AutoType autoType = AutoType.Rotating;
		public List<TileEdTile> tiles = new List<TileEdTile>();
		public List<TileEdTransition> transitions = new List<TileEdTransition>();
		public WallPivot wallSystem = WallPivot.Terrain; // used by auto-tiles. walls with upper pivot will look away from floor while walls with lower pivot looks towards floor
		//public bool tileSpaceSharing = false;
		//public bool tileSpaceSharingFloorIncl = false; // true if floor is part of wall mesh, else false if need to be able to select the floor prefab for each wall/ corner

		public bool setTag = false;
		public string floorTag = "Untagged";
		public string wallTag = "Untagged";
		public bool setLayer = false;
		public int floorLayer = 0;
		public int wallLayer = 0;
		public bool setStaticFlags = true;
		public int floorStaticFlags = -1; //public StaticEditorFlags floorStaticFlags = (StaticEditorFlags)(-1);
		public int wallStaticFlags = -1; //public StaticEditorFlags wallStaticFlags = (StaticEditorFlags)(-1);
		public bool setNavArea = true;
		public int floorNavArea = 0;
		public int wallNavArea = 0;
		public bool setSort = false;
		public int floorSortLayeId = 0;
		public int wallSortLayeId = 0;
		public int floorSortOrder = 0;
		public int wallSortOrder = 0;

		// ------------------------------------------------------------------------------------------------------------

		public override string ToString()
		{
			return name;
		}

		public TileEdTile FindTile(int ident)
		{
			if (ident < 0) return null;				 
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].ident == ident) return tiles[i];
			}
			return null;
		}

		public bool ContainsPrefab(int idx, GameObject fab)
		{
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].prefab[idx] == fab) return true;
			}
			return false;
		}

		public TileEdTransition FindTransition(int targetSetIdent)
		{
			for (int i = 0; i < transitions.Count; i++)
			{
				if (transitions[i].targetTileSetIdent == targetSetIdent)
				{
					transitions[i].LoadCache(this, null);
					return transitions[i];
				}
			}
			return null;
		}

		// -1 if not wall, 0: side wall, 1: concave wall, 2: convex wall, 3:special wall
		public int GetWallIdentifier(int tileIdent)
		{
			if (tiles[1].ident == tileIdent) return 0;
			else if (tiles[2].ident == tileIdent) return 1;
			else if (tiles[3].ident == tileIdent) return 2;
			else if (tiles[4].ident == tileIdent) return 3;
			return -1;
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
