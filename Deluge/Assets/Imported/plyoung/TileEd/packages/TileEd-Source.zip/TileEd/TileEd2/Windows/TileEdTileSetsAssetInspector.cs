﻿using UnityEngine;
using UnityEditor;
using plyLib;

namespace TileEd
{
	[CustomEditor(typeof(TileEdTileSetsAsset))]
	public class TileEdTileSetsAssetInspector : Editor
	{
		public override void OnInspectorGUI()
		{
			GUILayout.Label("TileEd Data. Do not edit this asset.");
			//DrawDefaultInspector();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
