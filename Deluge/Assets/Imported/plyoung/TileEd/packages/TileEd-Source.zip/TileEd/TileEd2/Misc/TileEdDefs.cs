﻿using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public enum TileEdCursorMode
	{
		Normal, Delete, Mark, Paste
	}
}
