﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using System.IO;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	[InitializeOnLoad]
	public class TileEdGUI
    {
		public static StyleDefs Styles
		{
			get
			{
				if (_styles == null)
				{
					LoadResources(); // load textures resources needed by TileEd's UI
					_styles = new StyleDefs();
				}
				return _styles;
			}
		}
		private static StyleDefs _styles;

		public class StyleDefs
		{
			public GUIStyle DragDropBox;
			public GUIStyle TilePreview;
			public GUIStyle TileBox;
			public GUIStyle TileSelected;
			public GUIStyle AddButtonIcon;

			public GUIStyle PaletteTab;

			public GUIStyle BoxTopBorder;
			public GUIStyle BoxRightBorder;

			public GUIStyle ButtonInList;

			public GUIStyle GridSceneMessage;
			public GUIStyle[] GridCoordsDebug;

			public GUIStyle TileHeading;
			public GUIStyle SpecialTileLabel;

			public StyleDefs()
			{
				GUISkin skin = GUI.skin;
				string _p = (EditorGUIUtility.isProSkin ? "_p" : "");

				Color c = skin.box.normal.textColor; c.a = 0.25f;
				DragDropBox = new GUIStyle(skin.box) { margin = new RectOffset(10, 10, 0, 10), alignment = TextAnchor.MiddleCenter, fontSize = 20, fontStyle = FontStyle.Bold, normal = { textColor = c } };
				TilePreview = new GUIStyle(skin.box) { padding = new RectOffset(0,0,0,0), alignment = TextAnchor.MiddleCenter, font = plyEdGUI.Styles.icoFont, fontSize = 20 };
				TileBox = new GUIStyle() { alignment = TextAnchor.MiddleCenter, font = plyEdGUI.Styles.icoFont, fontSize = 20, border = new RectOffset(2, 2, 2, 2), padding = new RectOffset(2,2,2,2), normal = { background = plyEdGUI.LoadTextureResource("TileEd.res.tile_box.png", typeof(TileEdGlobal).Assembly) } };
				TileSelected = new GUIStyle() { border = new RectOffset(3, 3, 3, 9), normal = { background = plyEdGUI.LoadTextureResource("TileEd.res.tile_selected.png", typeof(TileEdGlobal).Assembly) } };
				AddButtonIcon = new GUIStyle() { fixedWidth = 50, fixedHeight = 50, imagePosition = ImagePosition.ImageOnly };

				PaletteTab = new GUIStyle() { alignment = TextAnchor.MiddleCenter, border = new RectOffset(1, 6, 6, 1), padding = new RectOffset(7, 10, 2, 1), margin = new RectOffset(0, 2, 0, 0), normal = { background = plyEdGUI.LoadTextureResource("TileEd.res.toolbarbutton" +_p + ".png", typeof(TileEdGlobal).Assembly) }, onNormal = { background = plyEdGUI.LoadTextureResource("TileEd.res.toolbarbutton" + _p + "_a.png", typeof(TileEdGlobal).Assembly) } };
				if (EditorGUIUtility.isProSkin) { PaletteTab.normal.textColor = Color.gray; PaletteTab.onNormal.textColor = Color.white; }

				BoxTopBorder = new GUIStyle() { border = new RectOffset(0, 0, 1, 0), normal = { background = plyEdGUI.LoadTextureResource("TileEd.res.box_topborder" + _p + ".png", typeof(TileEdGlobal).Assembly) } };
				BoxRightBorder = new GUIStyle() { border = new RectOffset(0, 1, 0, 0), normal = { background = plyEdGUI.LoadTextureResource("TileEd.res.box_rightborder" + _p + ".png", typeof(TileEdGlobal).Assembly) } };

				ButtonInList = new GUIStyle(plyEdGUI.Styles.ListElement) { padding = new RectOffset(1, 1, 1, 1), fontSize = 15 };

				GridSceneMessage = new GUIStyle(EditorGUIUtility.GetBuiltinSkin(EditorSkin.Scene).box) { font = plyEdGUI.Styles.icoFont, fontSize = 16, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, padding = new RectOffset(10, 10, 10, 10) };
				GridCoordsDebug = new GUIStyle[]
				{
					new GUIStyle() { fontSize = 12, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } },
					new GUIStyle() { fontSize = 12, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.black } }
				};

				TileHeading = new GUIStyle(skin.GetStyle("BoldLabel")) { padding = new RectOffset(0, 0, 0, 0), margin = new RectOffset(4, 0, 0, 0) };
				SpecialTileLabel = new GUIStyle(skin.label) { font = plyEdGUI.Styles.icoFont, fontSize = 15, alignment = TextAnchor.MiddleLeft, normal = { textColor = Color.white } };
			}
		}

		// ------------------------------------------------------------------------------------------------------------
		// system

		static TileEdGUI()
		{
			// register callback for Unity Editor Theme system
			string existing = EditorPrefs.GetString("EditorTheme-Refresh");
			EditorPrefs.SetString("EditorTheme-Refresh",existing+"|TileEd.TileEdGUI.OnEditorThemeChanged");
		}

		private static void OnEditorThemeChanged()
		{
			// simply set style null and it will be recreated when needed again
			_styles = null;
		}

		// ------------------------------------------------------------------------------------------------------------
		// gui resources

		public static Texture2D TransitionIcon = null;
		public static Texture2D[][] AutoTileIcons;
		public static Texture2D[] NarrowTileIcons;

		public static GUIContent GC_AddButtonIcon;

		public static void LoadResources()
		{
			if (TransitionIcon != null) return;

			TransitionIcon = plyEdGUI.LoadTextureResource("TileEd.res.icons.transition.png", typeof(TileEdGUI).Assembly);

			GC_AddButtonIcon = new GUIContent(plyEdGUI.LoadTextureResource("TileEd.res.button_add.png", typeof(TileEdGUI).Assembly));

			AutoTileIcons = new Texture2D[9][];

			// floor
			AutoTileIcons[0] = new Texture2D[] { plyEdGUI.LoadTextureResource("TileEd.res.icons.floor.png", typeof(TileEdGUI).Assembly) };
			
			// walls and corners
			AutoTileIcons[1] =new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_wall_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_wall_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_wall_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_wall_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[2] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_1_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_1_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_1_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_1_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[3] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_2_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_2_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_2_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_2_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[4] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_3_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_3_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_3_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_corner_3_d.png", typeof(TileEdGUI).Assembly),
			};

			// transitions
			AutoTileIcons[5] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_1_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_1_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_1_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_1_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[6] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_2_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_2_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_2_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_2_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[7] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_3_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_3_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_3_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_3_d.png", typeof(TileEdGUI).Assembly),
			};
			AutoTileIcons[8] = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_4_a.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_4_b.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_4_c.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.autotile_transition_4_d.png", typeof(TileEdGUI).Assembly),
			};

			// Narrow
			NarrowTileIcons = new Texture2D[] {
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_full.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_single.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_1side.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_1side1.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_1side3.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_1side2.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_corner.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_corner1.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_2side.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_2end.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_crossing.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_crossing1.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_crossing4.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_crossing2.png", typeof(TileEdGUI).Assembly),
				plyEdGUI.LoadTextureResource("TileEd.res.icons.00_crossing3.png", typeof(TileEdGUI).Assembly),
			};


		}

		// ------------------------------------------------------------------------------------------------------------
		// scene resources

		public static Mesh gridMesh;
		public static Mesh cursorMesh;
		public static Texture2D[] gridTextures = new Texture2D[4];
		public static Texture2D[] cursorTextures = new Texture2D[2];
		public static Material[] gridMats = new Material[2];
		public static Material[] cursorMats = new Material[2];
		public static Material selectionMat;
		public static int matColorPropID = 0;
		public static int matTexturePropID = 0;
		private static Shader[] gridShaders = new Shader[2];
		private static Shader selectionShader;

		public static void LoadSceneResources()
		{
			if (gridMesh == null)
			{
				gridMesh = new Mesh();
				gridMesh.hideFlags = HideFlags.HideAndDontSave;
			}

			if (cursorMesh == null)
			{
				cursorMesh = new Mesh();
				cursorMesh.hideFlags = HideFlags.HideAndDontSave;
			}

			if (gridShaders[0] == null)
			{
				matTexturePropID = Shader.PropertyToID("_MainTex");
				matColorPropID = Shader.PropertyToID("_Tint");

				byte[] bytes = plyEdGUI.GetByteResource("TileEd.res.tileed", typeof(TileEdGUI).Assembly);
				AssetBundle assetBundle = AssetBundle.LoadFromMemory(bytes);
				
				try
				{
					gridTextures[0] = assetBundle.LoadAsset<Texture2D>("GridSolid1");
					gridTextures[1] = assetBundle.LoadAsset<Texture2D>("GridSolid2");
					gridTextures[2] = assetBundle.LoadAsset<Texture2D>("GridDashed1");
					gridTextures[3] = assetBundle.LoadAsset<Texture2D>("GridDashed2");
					cursorTextures[0] = assetBundle.LoadAsset<Texture2D>("CursorSolid");
					cursorTextures[1] = assetBundle.LoadAsset<Texture2D>("CursorDashed");

					gridShaders[0] = LoadShader(assetBundle, "GridShader1");
					gridShaders[1] = LoadShader(assetBundle, "GridShader2");
					selectionShader = LoadShader(assetBundle, "SelectionShader");

					gridMats[0] = new Material(gridShaders[0]);
					gridMats[1] = new Material(gridShaders[1]);
					cursorMats[0] = new Material(gridShaders[0]);
					cursorMats[1] = new Material(gridShaders[1]);
					selectionMat = new Material(selectionShader);
				}
				catch  { }

				assetBundle.Unload(false);

				gridTextures[0].hideFlags = HideFlags.HideAndDontSave;
				gridTextures[1].hideFlags = HideFlags.HideAndDontSave;
				gridTextures[2].hideFlags = HideFlags.HideAndDontSave;
				gridTextures[3].hideFlags = HideFlags.HideAndDontSave;
				cursorTextures[0].hideFlags = HideFlags.HideAndDontSave;
				cursorTextures[1].hideFlags = HideFlags.HideAndDontSave;

				gridShaders[0].hideFlags = HideFlags.HideAndDontSave;
				gridShaders[1].hideFlags = HideFlags.HideAndDontSave;
				selectionShader.hideFlags = HideFlags.HideAndDontSave;

				gridMats[0].hideFlags = HideFlags.HideAndDontSave;
				gridMats[1].hideFlags = HideFlags.HideAndDontSave;
				cursorMats[0].hideFlags = HideFlags.HideAndDontSave;
				cursorMats[1].hideFlags = HideFlags.HideAndDontSave;
				selectionMat.hideFlags = HideFlags.HideAndDontSave;

				UpdateSelectionColours();
			}
		}

		private static Shader LoadShader(AssetBundle assetBundle, string name)
		{
			Shader shader = Shader.Find("Hidden/TileEd/" + name);
			if (shader == null)
			{
				try
				{
					plyEdUtil.CheckPath(TileEdGlobal.WORK_PATH);
					string fn = plyEdUtil.ProjectFullPath + TileEdGlobal.WORK_PATH + name + ".shader";
					if (!File.Exists(fn))
					{
						TextAsset source = assetBundle.LoadAsset<TextAsset>(name + "Source");
						File.WriteAllText(fn, source.text);
						AssetDatabase.ImportAsset(TileEdGlobal.WORK_PATH + name + ".shader");
					}
					shader = AssetDatabase.LoadAssetAtPath<Shader>(TileEdGlobal.WORK_PATH + name + ".shader");
				}
				catch { Debug.LogError("Error while trying to load TileEd resources."); }
			}
			return shader;
		}

		public static void UpdateSelectionColours()
		{
			selectionMat.SetColor("_MainColor", TileEdGlobal.selectionColors[0]);
			selectionMat.SetColor("_RimColor", TileEdGlobal.selectionColors[1]);
			selectionMat.SetColor("_BehindColor", TileEdGlobal.selectionColors[2]);
		}

		// ------------------------------------------------------------------------------------------------------------

		private static Transform selectionObjectsRoot;

		public static void ClearSelectionMarkers()
		{
			if (selectionObjectsRoot == null)
			{	// first make sure the reference to it was not just lost while the object is actually in scene
				GameObject g = GameObject.Find("TileEd Selection Object Markers");
				if (g != null) selectionObjectsRoot = g.transform;
			}

			if (selectionObjectsRoot != null)
			{
				Object.DestroyImmediate(selectionObjectsRoot.gameObject);
			}
		}

		public static GameObject AddSelectionMarker(GameObject obj)
		{
			LoadSceneResources();

			if (selectionObjectsRoot == null)
			{
				GameObject g = GameObject.Find("TileEd Selection Object Markers");
				if (g == null) g = new GameObject("TileEd Selection Object Markers");
				g.hideFlags = HideFlags.HideAndDontSave;
				selectionObjectsRoot = g.transform;
			}

			GameObject go = GameObject.Instantiate(obj);
			go.hideFlags = HideFlags.HideAndDontSave;
			go.transform.parent = selectionObjectsRoot;

			Renderer[] rens = go.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < rens.Length; i++)
			{
				EditorUtility.SetSelectedRenderState(rens[i], EditorSelectedRenderState.Hidden);
				rens[i].sharedMaterial = selectionMat;
				//for (int j = 0; j < rens[i].sharedMaterials.Length; j++)
				//{
				//	rens[i].sharedMaterials[j] = selectionMat;
				//}
			}

			return go;
		}

		public static void RemoveSelectionMarker(GameObject go)
		{
			if (go != null)
			{
				Object.DestroyImmediate(go);
			}
		}

		public static void Handles_DrawGridCoord(Vector3 pos, string label)
		{
			//Handles.Label(pos + new Vector3(0.03f, 0.0f, 0.03f), label, Styles.GridCoordsDebug[1]);
			Handles.Label(pos, label, Styles.GridCoordsDebug[0]);
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
