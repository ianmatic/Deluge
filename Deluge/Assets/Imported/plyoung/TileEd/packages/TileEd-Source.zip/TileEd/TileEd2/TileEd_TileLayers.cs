﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_TileLayers : EditorWindow
    {

		private static readonly GUIContent GC_Visible = new GUIContent(Ico._visible, "This Tile Layer is visible");
		private static readonly GUIContent GC_Hidden = new GUIContent(Ico._hidden, "This Tile Layer is hidden");
		private static readonly GUIContent GC_Combined = new GUIContent(Ico._grid_off, "This Tile Layer is combined. Use this button to remove combined meshes and recreate the Tile Layer from TileEd map data");
		private static readonly GUIContent GC_RecreateGroup = new GUIContent(Ico._refresh, "Recreate Tile Layer from TileEd map data");

		public static TileEd_TileLayers win { get; private set; }

		private static plyEdGUI.ListOps groupListOps;
		private static Vector2 scroll = Vector2.zero;
		private static GUIContent listGC = new GUIContent();

		public static void Show_Window()
		{
			win = EditorWindow.GetWindow<TileEd_TileLayers>("Tile Layers");
			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_layers" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			win.titleContent = new GUIContent("Tile Layers", icon);
		}

		protected void OnEnable()
		{
			win = this;
			TileEdGlobal.layersDocked = false;
			EditorPrefs.SetBool("TileEd.TileLayers.Docked", TileEdGlobal.layersDocked);
			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_layers" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			titleContent = new GUIContent("Tile Layers", icon);
			minSize = new Vector2(150, 150);
		}

		protected void OnDestroy()
		{
			win = null;
			TileEdGlobal.layersDocked = true;
			EditorPrefs.SetBool("TileEd.TileLayers.Docked", TileEdGlobal.layersDocked);
			TileEd.Instance?.Repaint();
		}

		protected void OnGUI()
		{
			if (TileEd.Instance == null)
			{
				GUILayout.Label("TileEd Map not selected");
			}
			else
			{
				DoGUI();
			}
		}

		public static void DoGUI()
		{
			if (groupListOps == null)
			{
				groupListOps = new plyEdGUI.ListOps()
				{
					toolbarStyle = plyEdGUI.ListOps.ToobarStyle.List,
					canAdd = true,
					canRemove = true,
					canDuplicate = true,
					canChangePosition = true,
					//onDrawHeader = OnDrawGroupListHeader,
					onAction = OnGroupListAction,
					onDrawElement = OnDrawGroupListEle,
					extraButtons = new plyEdGUI.ListOpsExtraToolbarButton[]
					{
						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._rename, "Edit Selected"),
							callback = () => TileEd_MapGroupWindow.ShowWiz(TileEd.Instance.group, OnEditGroupListEle),
						},

						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._undock, "Undock"),
							callback = Undock,
							enabled = () => { return TileEdGlobal.layersDocked; }
						},
					}
				};
			}

			//if (plyEdGUI.List<TileEdMapGroup>(ref activeGroupIdx, map.groups, ref scroll, groupListOps, GUILayout.MaxHeight(150), GUILayout.MinHeight(100)) == 1)
			if (plyEdGUI.List<TileEdMapGroup>(ref TileEd.activeGroupIdx, TileEd.Instance.map.groups, ref scroll, groupListOps, TileEdGlobal.layersDocked ? GUILayout.Height(TileEdGlobal.layersHeight) : GUILayout.ExpandHeight(true)) == 1)
			{
				if (TileEdGlobal.seperateGridHeights == false && TileEd.Instance.group != null)
				{
					TileEd.Instance.map.groups[TileEd.activeGroupIdx].gridYPos = TileEd.Instance.group.gridYPos;
				}

				TileEd.Instance.group = TileEd.Instance.map.groups[TileEd.activeGroupIdx];

				if (TileEdGlobal.activeTileEdToolIdx >= 0)
				{
					TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnGroupChanged();
				}

				TileEd.grid.gridPosDirty = true;
				TileEd.Instance.Repaint();
				SceneView.RepaintAll();
			}
		}

		private static void Undock()
		{
			TileEdGlobal.layersDocked = false;
			EditorPrefs.SetBool("TileEd.TileLayers.Docked", TileEdGlobal.layersDocked);
			Show_Window();
			TileEd.Instance.Repaint();
		}

		//private static void OnDrawGroupListHeader()
		//{
		//	//GUILayout.Label(GC_GroupListHead, plyEdGUI.Styles.Label);
		//}

		private static int OnGroupListAction(plyEdGUI.ListOps.ListAction act)
		{
			if (act == plyEdGUI.ListOps.ListAction.DoAdd)
			{
				TileEd.Instance.map.groups.Add(new TileEdMapGroup() { name = plyEdUtil.GetUniqueString<TileEdMapGroup>(TileEd.Instance.map.groups, "TileLayer "), ident = TileEd.Instance.map.GenerateGroupIdent() });
				plyEdUtil.SetDirty(TileEd.Instance.map);
				return -1;
			}

			else if (act == plyEdGUI.ListOps.ListAction.DoRemoveSelected)
			{
				if (TileEd.Instance.map.groups.Count > 1)
				{
					if (EditorUtility.DisplayDialog("TileEd", "All map data related to this Tile Layer will be deleted, including placed tiles. This action can't be undone. Are you sure you want to continue?", "Yes", "Cancel"))
					{
						// notify all editor tools that this group is being deleted
						for (int i = 0; i < TileEdGlobal.editors.Count; i++)
						{
							TileEdGlobal.editors[i].ed.OnDeletingGroup(TileEd.Instance.map.groups[TileEd.activeGroupIdx]);
						}

						TileEd.Instance.map.groups.RemoveAt(TileEd.activeGroupIdx);
						plyEdUtil.SetDirty(TileEd.Instance.map);
						EditorSceneManager.MarkAllScenesDirty();
						return -1;
					}
				}
				else
				{
					EditorUtility.DisplayDialog("TileEd", "You can't delete this Tile Layer. There must be at least one Tile Layer.", "OK");
				}
			}

			else if (act == plyEdGUI.ListOps.ListAction.DoDuplicateSelected)
			{
				if (TileEd.Instance.group.combined)
				{
					EditorUtility.DisplayDialog("TileEd", "Can't duplicate a Tile Layer which is combined.", "OK");
					return -2;
				}

				// create new group
				TileEdMapGroup source = TileEd.Instance.group;
				TileEdMapGroup target = source.Copy();
				target.name = target.name + " (copy)";
				target.ident = TileEd.Instance.map.GenerateGroupIdent(); // must have unique ident
				TileEd.Instance.map.groups.Add(target);

				// notify all tools to make a duplication of the source group into target group
				for (int i = 0; i < TileEdGlobal.editors.Count; i++)
				{
					TileEdGlobal.editors[i].ed.OnDuplicatedGroup(target);
				}

				// save
				plyEdUtil.SetDirty(TileEd.Instance.map);
				EditorSceneManager.MarkAllScenesDirty();
				return -1;
			}

			return -2;
		}

		private static void OnDrawGroupListEle(Rect rect, int idx, bool selected)
		{
			if (Event.current.type == EventType.Repaint)
			{
				plyEdGUI.Styles.ListElement.Draw(rect, selected, selected, selected, selected);
			}

			Rect r = rect;
			r.x += 5;
			r.width = 20;
			if (GUI.Button(r, TileEd.Instance.map.groups[idx].visible ? GC_Visible : GC_Hidden, TileEdGUI.Styles.ButtonInList))
			{
				TileEd.Instance.map.groups[idx].visible = !TileEd.Instance.map.groups[idx].visible;
				plyEdUtil.SetDirty(TileEd.Instance.map);
				SetGroupVisible(TileEd.Instance.map.groups[idx].ident,TileEd.Instance. map.groups[idx].visible);
			}

			r.x += 25;
			if (TileEd.Instance.map.groups[idx].combined)
			{
				if (GUI.Button(r, GC_Combined, TileEdGUI.Styles.ButtonInList))
				{
					RecreateGroup(TileEd.Instance.map.groups[idx]);
				}
			}
			else
			{
				if (GUI.Button(r, GC_RecreateGroup, TileEdGUI.Styles.ButtonInList))
				{
					RecreateGroup(TileEd.Instance.map.groups[idx]);
				}
			}

			listGC.text = Ico._scale + TileEd.Instance.map.groups[idx].tileSize + " " + Ico._swap_vert + TileEd.Instance.map.groups[idx].tileHeight;
			Vector2 sz = plyEdGUI.Styles.ListElement.CalcSize(listGC);
			sz.x += 10;

			r.x += 25;
			r.width = rect.width - (sz.x + 55);
			GUI.Label(r, TileEd.Instance.map.groups[idx].name, plyEdGUI.Styles.ListElement);

			r.x = rect.xMax - sz.x;
			r.width = sz.x;
			GUI.Label(r, listGC, plyEdGUI.Styles.ListElement);
		}

		private static void OnEditGroupListEle(TileEd_MapGroupWindow wiz)
		{
			if (!string.IsNullOrEmpty(wiz.groupName)) TileEd.Instance.group.name = wiz.groupName;
			if (wiz.tileSize != 0.0f) TileEd.Instance.group.tileSize = wiz.tileSize;
			if (wiz.tileHeight != 0.0f) TileEd.Instance.group.tileHeight = wiz.tileHeight;
			TileEd.Instance.group.centreTiles = wiz.centreTiles;
			plyEdUtil.SetDirty(TileEd.Instance.map);
			wiz.Close();
		}

		private static void SetGroupVisible(int groupIdent, bool visible)
		{
			// tell all tools that the group visibility changed
			for (int i = 0; i < TileEdGlobal.editors.Count; i++)
			{
				TileEdGlobal.editors[i].ed.OnGroupVisibiliyChanged(groupIdent, visible);
			}
		}

		private static void RecreateGroup(TileEdMapGroup group)
		{
			if (EditorUtility.DisplayDialog("TileEd", "All the objects of this group will be removed from the scene and then recreated from the TileEd Map Data. This action can't be undone. Are you sure?", "Yes", "Cancel"))
			{
				// make group visible
				group.visible = true;
				group.combined = false;
				SetGroupVisible(group.ident, true);

				// let tools recreate the group
				for (int i = 0; i < TileEdGlobal.editors.Count; i++)
				{
					TileEdGlobal.editors[i].ed.RecreateGroup(group, true);
				}

				// mark scene dirty since this change can't be undone
				plyEdUtil.SetDirty(TileEd.Instance.map);
				EditorSceneManager.MarkAllScenesDirty();
			}
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
