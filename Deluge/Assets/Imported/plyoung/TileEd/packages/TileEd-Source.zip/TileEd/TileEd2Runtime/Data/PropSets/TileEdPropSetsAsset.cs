﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdPropSetsAsset : ScriptableObject
	{
		public List<TileEdPropSet> tileSets = new List<TileEdPropSet>();
		[SerializeField] private int lastPropSetIdent = 0;
		[SerializeField] private int lastPropIdent = 0;

		public int GeneratePropSetIdent()
		{
			lastPropSetIdent++;
			return lastPropSetIdent;
		}

		public int GeneratePropIdent()
		{
			lastPropIdent++;
			return lastPropIdent;
		}

		public TileEdPropSet FindTileSet(int ident)
		{
			if (ident < 0) return null;
			for (int i = 0; i < tileSets.Count; i++)
			{
				if (tileSets[i].ident == ident) return tileSets[i];
			}
			return null;
		}

		[System.NonSerialized]
		private GUIContent[] _gc = null;
		public GUIContent[] GC_PropSets
		{
			get
			{
				if (_gc == null || _gc.Length != tileSets.Count)
				{
					_gc = new GUIContent[tileSets.Count];
					for (int i = 0; i < tileSets.Count; i++) _gc[i] = new GUIContent(tileSets[i].name);
				}
				return _gc;
			}

			set
			{
				_gc = value;
			}
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
