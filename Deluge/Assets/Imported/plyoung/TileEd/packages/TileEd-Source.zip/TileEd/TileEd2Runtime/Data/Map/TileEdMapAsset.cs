﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	/// <summary> This is the main asset file which represents the map data. When you place a tile an object is
	/// placed in the scene and an entry made in this asset. </summary>
	[System.Serializable]
	public class TileEdMapAsset: ScriptableObject, ISerializationCallbackReceiver
	{
		/// <summary> The unique identity of this map. It is the same as the map 
		/// asset file name (without the .asset part or the directories of course) </summary>
		public string ident;

		/// <summary> the Tile groups/ layers defined in this map 
		/// (they are set up via the map inspector) </summary>
		public List<TileEdMapGroup> groups = new List<TileEdMapGroup>();

		[SerializeField] private int lastGroupIdent = 0;

		[System.NonSerialized] public TileEdMap mapObjectCache;

		// ------------------------------------------------------------------------------------------------------------

		public void CopyTo(TileEdMapAsset m)
		{
			m.lastGroupIdent = lastGroupIdent;
			for (int i = 0; i < groups.Count; i++)
			{
				m.groups.Add(groups[i].Copy());
				m.groups[i].BuildCache(); 
			}
		}

		// ------------------------------------------------------------------------------------------------------------

		/// <summary> Used to create a new unique tile group/ layer ident when user
		/// adds new group via the map inspector </summary>
		public int GenerateGroupIdent()
		{
			lastGroupIdent++;
			return lastGroupIdent;
		}

		/// <summary> Returns the tile layer/ group that corresponds to the specific id </summary>
		public TileEdMapGroup GetGroup(int ident)
		{
			for (int i = 0; i < groups.Count; i++)
			{
				if (groups[i].ident == ident) return groups[i];
			}
			return null;
		}

		// ------------------------------------------------------------------------------------------------------------

		void ISerializationCallbackReceiver.OnAfterDeserialize()
		{
			for (int i = 0; i < groups.Count; i++)
			{	// re-build cache
				groups[i].BuildCache(); 
			}
		}

		void ISerializationCallbackReceiver.OnBeforeSerialize()
		{
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
