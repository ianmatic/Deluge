﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	[InitializeOnLoad]
	public class TileEdGlobal
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public static readonly string DATA_PATH = plyEdUtil.DataRoot + "TileEd/Data/";
		public static readonly string MAPS_PATH = plyEdUtil.DataRoot + "TileEd/Maps/";
		public static readonly string TEMP_PATH = plyEdUtil.DataRoot + "TileEd/Temp/";
		public static readonly string FABS_PATH = plyEdUtil.DataRoot + "TileEd/Fabs/";
		public static readonly string MESH_PATH = plyEdUtil.DataRoot + "TileEd/Mesh/";
		public static readonly string WORK_PATH = plyEdUtil.DataRoot + "TileEd/Work/";

		public static readonly string URL_DOCS = "https://plyoung.github.io/tile-ed.html";
		public static readonly string URL_SUPPORT = "http://forum.plyoung.com/c/tile-ed/";
		public static readonly string URL_STORE = "https://www.assetstore.unity3d.com/#!/content/49094?aid=1101lGtB";

		// TileEd Editor section definition
		public class TileEd_EdDef
		{
			public GUIContent label;	// label to show where needed
			public TileEd_Ed_Base ed;	// the editor with callbacks to use
			public int order;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public static List<TileEd_EdDef> editors = new List<TileEd_EdDef>();
		public static GUIContent[] GC_Editors = new GUIContent[0];

		private static int _activeTileEdToolIdx = -1;	// basically an index into editors list. TileEd_PalettePanel is mostly in control of changing this
		public static int activeTileEdToolIdx
		{
			get { return _activeTileEdToolIdx; }
			set
			{
				if (_activeTileEdToolIdx != value)
				{
					if (editors != null)
					{
						if (_activeTileEdToolIdx >= 0 && _activeTileEdToolIdx < editors.Count)
						{	// tell editor tool it was closed/ deselected
							TileEdGlobal.editors[_activeTileEdToolIdx].ed.OnPalleteLooseFocus();
						}

						if (value >= 0 && value < editors.Count)
						{	// tell editor tool it was opened/ selected
							TileEdGlobal.editors[value].ed.OnPalleteFocus();
						}
					}

					_activeTileEdToolIdx = value;
					plyEdUtil.RepaintInspector(typeof(TileEd));
				}
			}
		}

		public static bool edModeOn = true;				// is edit mode on or off?
		public static bool mouseWasOverPalette = false;	// used to detect if grid should be rendered this frame. do not render when mouse over the palette area. only applies when palette is docked in scene view
		public static int palletePreviewAlloc = 1;		// SetPreviewTextureCacheSize 
		public static int inspectorPreviewAlloc = 1;	// SetPreviewTextureCacheSize 

		// *** these are saved and restored from EditorPrefs

		public static bool autoDisableSceneGrid = true;	// auto-disable the SCene view grid when TileEd is active?
		public static bool permaOffSceneGrid = true;
		public static bool seperateGridHeights = true;	// each group remember its own grid height

		public static int templatesPreviewSize = 128;	// size of tiles preview
		public static bool paletteDocked = true;		// is palette docked in scene view or not?
		public static int paletteLayout = -1;			// 0:horizontal, 1:vertical (only valid while docked)
		public static int palettePreviewSize = 0;		// size of tiles
		public static int combineBlockSize = 16;        // number of tiles per block of combine (combineBlockSize x combineBlockSize_)
		//public static bool doLightmapUVs = false;       // should lightmap UVs be processed when combining mesh?
		public static bool recreateIgnoreProps = false;

		public static bool layersDocked = true;			// is tile layers panel docked in inspector or not?
		public static int layersHeight = 150;			// tile layers list size/ height

		// grid[0] = main visible grid, grid[1] = the part of grid behind tiles
		public static bool gridStyleChanged = true;						// helper
		public static int[] gridStyle = { 0, 1 };						// 0: solid, 1:dashes
		public static bool[] gridThin = { true, true };					// thick or thing variation of grid style
		public static Color[] gridColor = { new Color(0f, 0.62f, 1f, 1f), new Color(1f, 1f, 0f, 0.65f) };   // colour and alpha of grid		

		public static bool cursorStyleChanged = true;								// helper
		public static Color gridPlacementCursor = new Color(0.12f, 0.86f, 1f, 1f);	// colour used to indicate placement area
		public static Color gridDeleteCursor = new Color(1f, 0f, 0f, 1f);			// colour used to indicate deletion area
		public static Color gridMarkCursor = new Color(1f, 1f, 0f, 1f);				// colour used to indicate marking tiles
		public static Color gridSculptDownCursor = new Color(1f, 0.5f, 0f, 1f);		// colour used to indicate sculpting tiles down (terrain uses this)

		// selection marker object's colours. Main, Rim, Behind
		public static Color[] selectionColors = new Color[] { new Color(0.93f, 0.64f, 0f, 0.5f), new Color(1f, 1f, 0f, 0f), new Color(1f, 1f, 0f, 0.15f) };

		public static bool debugGridNumbers = false;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region menus

		[MenuItem("GameObject/TileEd Map", priority = 0)]
		//[MenuItem("Tools/TileEd/Create TileEd Map", priority = 0)]
		[MenuItem("Window/TileEd/Create TileEd Map", priority = 1000)]
		public static void Show_CreateNewMap()
		{
			if (EditorUtility.DisplayDialog("TileEd", "A new TileEd Map object will now be created in the scene. This is the root object for the objects which TileEd will place in the scene while you are painting tiles. The object will be called `TileEd Map` but you may rename it if you want. The object will be placed at position 0x0x0 - do not change this.\n\nDo not place any child objects of your own in this root object and do not delete anything that TileEd placed in it. Only TileEd should manipulate the child objects.", "OK", "Cancel"))
			{
				CreateNewMap(null);
			}
		}

		//[MenuItem("Tools/TileEd/Toggle TileEd mode On|Off", priority = 2)]
		[MenuItem("Window/TileEd/Toggle TileEd mode On|Off", priority = 1001)]
		public static void ToggleEdModeOnOff()
		{
			edModeOn = !edModeOn;
			EditorPrefs.SetBool("TileEd.EdModeOn", edModeOn);
			if (!edModeOn && activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.activeTileEdToolIdx = -1;
			}

			if (TileEdGlobal.autoDisableSceneGrid)
			{
				plyEdUtil.Gizmos_ShowGrid = (permaOffSceneGrid ? false : !TileEdGlobal.edModeOn && TileEd.Instance != null);
			}

			plyEdUtil.Gizmos_ShowSelectionOutline = (!TileEdGlobal.edModeOn && TileEd.Instance != null);
			plyEdUtil.Gizmos_ShowSelectionWire = (!TileEdGlobal.edModeOn && TileEd.Instance != null);

			SceneView.RepaintAll();
		}

		//[MenuItem("Tools/TileEd/Settings and Tile Sets", priority = 5)]
		[MenuItem("Window/TileEd/Settings and Tile Sets", priority = 1002)]
		public static void Show_Settings()
		{
			TileEd_Settings.Show_Window();
		}

		//[MenuItem("Tools/TileEd/Pivot Editor", priority = 6)]
		[MenuItem("Window/TileEd/Pivot Editor", priority = 1003)]
		public static void Show_PivotEditor()
		{
			TileEd_PivotEditorWindow.Show_PivotEditorWindow();
		}

		//[MenuItem("Tools/TileEd/About", priority = 7)]
		[MenuItem("Window/TileEd/About", priority = 1004)]
		public static void Show_About()
		{
			Texture2D logo = plyEdGUI.LoadTextureResource("TileEd.res.logo.png", typeof(TileEdGlobal).Assembly);
			plyAboutWindow.Show_AboutWindow(" ", logo, plyEdUtil.GetVersion(plyEdUtil.PackagesFullPath + "version-TileEd.txt"), URL_DOCS, URL_SUPPORT, URL_STORE, 320, 100);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		static TileEdGlobal()
		{
			// get version and register documentation package
			//plyEdHelpManager.RegisterDocumentation("tile-ed", "version-TileEd.txt", "TileEd", "tile-ed", "TileEd/packages/TileEd-Docs.zip");

			// register TileEd editors
			RegisterEditor(new TileEd_Ed_Tiles());
			RegisterEditor(new TileEd_Ed_Props());

			EditorApplication.update += OnUpdate;
			EditorApplication.delayCall += InitTileEd;
			//EditorApplication.hierarchyWindowChanged += OnHierarchyWindowChanged;
		}

		private static void InitTileEd()
		{
			gridStyleChanged = true;
			cursorStyleChanged = true;

			autoDisableSceneGrid = EditorPrefs.GetBool("TileEd.AutoDisableSceneGrid", autoDisableSceneGrid);
			permaOffSceneGrid = EditorPrefs.GetBool("TileEd.PermaOffSceneGrid", permaOffSceneGrid);			
			seperateGridHeights = EditorPrefs.GetBool("TileEd.SeperateGridHeights", seperateGridHeights);
			templatesPreviewSize = EditorPrefs.GetInt("TileEd.Templates.TilePreviewSize", templatesPreviewSize);
			paletteDocked = EditorPrefs.GetBool("TileEd.PalettePanel.Docked", true);
			paletteLayout = EditorPrefs.GetInt("TileEd.PalettePanel.Layout", 0);
			palettePreviewSize = EditorPrefs.GetInt("TileEd.PalettePanel.PreviewSize", palettePreviewSize);
			combineBlockSize = EditorPrefs.GetInt("TileEd.CombineBlockSize", combineBlockSize);
			//doLightmapUVs = EditorPrefs.GetBool("TileEd.DoLightmapUVs", doLightmapUVs);
			recreateIgnoreProps = EditorPrefs.GetBool("TileEd.recreateIgnoreProps", recreateIgnoreProps);
			layersDocked = EditorPrefs.GetBool("TileEd.TileLayers.Docked", true);
			layersHeight = EditorPrefs.GetInt("TileEd.TileLayers.Height", layersHeight);
			gridStyle[0] = EditorPrefs.GetInt("TileEd.Grid.Style0", gridStyle[0]);
			gridStyle[1] = EditorPrefs.GetInt("TileEd.Grid.Style1", gridStyle[1]);
			gridThin[0] = EditorPrefs.GetBool("TileEd.Grid.Thin0", gridThin[0]);
			gridThin[1] = EditorPrefs.GetBool("TileEd.Grid.Thin1", gridThin[1]);
			gridColor[0] = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.Color0", gridColor[0]);
			gridColor[1] = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.Color1", gridColor[1]);
			gridPlacementCursor = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.PlaceColor", gridPlacementCursor);
			gridDeleteCursor = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.DeleteColor", gridDeleteCursor);
			gridMarkCursor = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.MarkColor", gridMarkCursor);
			gridSculptDownCursor = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.SculptDownColor", gridSculptDownCursor);
			selectionColors[0] = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.SelectionColor0", selectionColors[0]);
			selectionColors[1] = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.SelectionColor1", selectionColors[1]);
			selectionColors[2] = plyEdUtil.EdPrefs_GetColor("TileEd.Grid.SelectionColor2", selectionColors[2]);
			debugGridNumbers = EditorPrefs.GetBool("TileEd.debugGridNumbers", debugGridNumbers);

			edModeOn = EditorPrefs.GetBool("TileEd.EdModeOn", edModeOn);

			// make sure the selection markers helper are not in the scene
			TileEdGUI.ClearSelectionMarkers();

			// clean up the temp folder
			plyEdUtil.DeleteAssets(TEMP_PATH);

			// preload scene resources
			TileEdGUI.LoadSceneResources();

			// check if the Palette is docked or not. It could happen that a Unity crash causes the docked state to become messed up
			// the palette win static should be set if it is not docked in scene view
			if (TileEd_PalettePanel.win == null)
			{
				paletteDocked = true;
				EditorPrefs.SetBool("TileEd.PalettePanel.Docked", paletteDocked);
			}
		
			if (TileEd_TileLayers.win == null)
			{
				layersDocked = true;
				EditorPrefs.SetBool("TileEd.TileLayers.Docked", layersDocked);
			}				
		}

		private static void OnUpdate()
		{
			if (edModeOn && TileEd.Instance != null && TileEd.Instance.map != null)
			{
				if (TileEdGlobal.activeTileEdToolIdx >= 0)
				{
					if (TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.hasLoadingPalettePreviews && AssetPreview.IsLoadingAssetPreviews())
					{
						SceneView.RepaintAll();
					}
				}
			}
		}

		private static void RegisterEditor(TileEd_Ed_Base editor)
		{
			editors.Add(new TileEd_EdDef() { label = new GUIContent(editor.PaletteName()), ed = editor, order = editor.PaletteOrder() });
			editors.Sort((a, b) => { return a.order.CompareTo(b.order); });

			GC_Editors = new GUIContent[editors.Count];
			for (int i = 0; i < editors.Count; i++) GC_Editors[i] = new GUIContent(editors[i].label);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public static void PreviewAlloc(int paletteAlloc, int inspetorAlloc)
		{
			if (palletePreviewAlloc < paletteAlloc) palletePreviewAlloc = paletteAlloc;
			if (inspectorPreviewAlloc < inspetorAlloc) inspectorPreviewAlloc = inspetorAlloc;
			AssetPreview.SetPreviewTextureCacheSize(palletePreviewAlloc + inspectorPreviewAlloc);
		}

		public static void CreateNewMap(TileEdMapAsset fromMap)
		{
			plyEdUtil.CheckPath(MAPS_PATH);

			GameObject go = new GameObject("TileEd Map");
			TileEdMap map = go.AddComponent<TileEdMap>();
				
			// make sure the ident is unique by simply checking existing file names
			bool done = false;
			while (!done)
			{
				map.ident = System.Guid.NewGuid().ToString("N");
				string path = plyEdUtil.ProjectFullPath + MAPS_PATH + map.ident + ".asset";
				if (false == System.IO.File.Exists(path)) done = true;
			}

			TileEdMapAsset mapAsset = plyEdUtil.LoadOrCreateAsset<TileEdMapAsset>(MAPS_PATH + map.ident + ".asset", false);
			mapAsset.ident = map.ident;

			if (fromMap == null)
			{	// create a default tile layer/ group
				mapAsset.groups.Add(new TileEdMapGroup() { name = "TileLayer 1", ident = mapAsset.GenerateGroupIdent() });
			}
			else
			{   // Copy contents of another map
				fromMap.CopyTo(mapAsset);
			}

			plyEdUtil.SetDirty(map);
			plyEdUtil.SetDirty(go);
			plyEdUtil.SetDirty(mapAsset);
			EditorSceneManager.MarkAllScenesDirty();
			AssetDatabase.SaveAssets();

			Selection.activeGameObject = go;
		}

		public static TileEd_Ed_Base GetEdByToolIdent(int ident)
		{
			for (int i = 0; i < editors.Count; i++)
			{
				if (editors[i].ed.ToolIdent() == ident) return editors[i].ed;
			}
			return null;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
