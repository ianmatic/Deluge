﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_NewTileSetWindow : EditorWindow
    {
		public string setName { get; private set; }
		public TileEdTileSet.Type setType { get; private set; }
		public TileEdTileSet.AutoType subType { get; private set; }
		public TileEdTileSet.WallPivot wallSystem { get; private set; }

		private System.Action<TileEd_NewTileSetWindow> callback;
		private bool accepted = false;
		private bool lostFocus = false;

		private static readonly GUIContent GC_Empty = new GUIContent(" ");

		public static void Show_NewTileSetWindow(string setName, System.Action<TileEd_NewTileSetWindow> callback)
		{
			TileEd_NewTileSetWindow win = EditorWindow.GetWindow<TileEd_NewTileSetWindow>(true, "Create TileSet", true);
			win.setName = setName;
			win.setType = TileEdTileSet.Type.Simple;
			win.subType = TileEdTileSet.AutoType.Rotating;
			win.wallSystem = TileEdTileSet.WallPivot.Terrain;
			win.callback = callback;
			win.minSize = win.maxSize = new Vector2(250, 120);
			win.ShowUtility();
		}

		protected void OnFocus() { lostFocus = false; }
		protected void OnLostFocus() { lostFocus = true; }

		protected void Update()
		{
			if (lostFocus) this.Close();
			if (accepted && callback != null) callback(this);
		}

		protected void OnGUI()
		{
			EditorGUILayout.Space();

			EditorGUIUtility.labelWidth = 70;
			setName = EditorGUILayout.TextField("Name", setName);

			setType = (TileEdTileSet.Type)EditorGUILayout.EnumPopup("Type", setType);

			if (setType == TileEdTileSet.Type.Auto)
			{
				EditorGUI.BeginChangeCheck();
				wallSystem = (TileEdTileSet.WallPivot)EditorGUILayout.EnumPopup(GC_Empty, wallSystem);
				if (wallSystem != TileEdTileSet.WallPivot.Narrow)
				{
					subType = (TileEdTileSet.AutoType)EditorGUILayout.EnumPopup(GC_Empty, subType);
				}
			}

			GUILayout.FlexibleSpace();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("Accept", GUILayout.Width(80))) accepted = true;
				GUILayout.Space(5);
				if (GUILayout.Button("Cancel", GUILayout.Width(80))) this.Close();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(10);			
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
