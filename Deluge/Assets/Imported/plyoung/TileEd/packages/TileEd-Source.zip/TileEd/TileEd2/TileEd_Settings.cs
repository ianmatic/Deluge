﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_Settings : EditorWindow
    {
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private static readonly GUIContent GC_General = new GUIContent("General");

		private static readonly GUIContent GC_Reset = new GUIContent(Ico._refresh, "Restore defaults");
		private static readonly GUIContent GC_AutoDisableSceneGrid = new GUIContent("Auto-control Scene Grid", "Auto hide/ show the Scene View Grid when TileEd is active or not. TileEd has its own grid so you probably want this on.");
		private static readonly GUIContent GC_PermaOffSceneGrid = new GUIContent("Perma-hidden", "Keep the Unity grid disabled even when TileEd is not active?");
		private static readonly GUIContent GC_SeperateGridHeights = new GUIContent("Individual Grid Height", "Should each map group track its own grid height or should the same grid height be kept when you switch between groups?");
		private static readonly GUIContent GC_TemplateSize = new GUIContent("Template Size", "Size of template image previews.");
		private static readonly GUIContent[] GC_TemplateSizes = new GUIContent[] { new GUIContent("64"), new GUIContent("128") };
		private static readonly GUIContent GC_CombineSize = new GUIContent("Combine Block Size", "The number of tiles used per block of combine when doing a tile mesh combine.");
		private static readonly GUIContent GC_CreateUV2 = new GUIContent("Generate uv2", "Generate uv2 while doing mesh combine?");
		private static readonly GUIContent GC_TileLayersListSize = new GUIContent("Tile Layers Height", "The height of the tile layers list when docked in the inspector.");
		private static readonly GUIContent GC_RecreateIgnoreProps = new GUIContent("Recreate ignores Props", "Should props be ignored, and only tiles processed, when the Recreate option is used?");

		private static readonly GUIContent GC_Grid0 = new GUIContent("Grid Main", "Settings for the main visible part of grid.");
		private static readonly GUIContent GC_Grid1 = new GUIContent("Grid Behind Tiles", "Settings for the part of grid that is behind tiles.");
		private static readonly GUIContent GC_GridSyle = new GUIContent("Style", "Style to use for grid.");
		private static readonly GUIContent GC_GridThin = new GUIContent("Thin", "Should a thin of thick grid line be used?");
		private static readonly GUIContent GC_GridColor = new GUIContent("Colour", "Colour and opacity to render Grid in.");
		private static readonly GUIContent[] GC_GridStyleOps = { new GUIContent("Solid"), new GUIContent("Dashed") };

		private static readonly GUIContent GC_Cursor = new GUIContent("Cursor", "The grid cursor is a visual indication of the position in the grid and brush size.");
		private static readonly GUIContent GC_GridPlaceColor = new GUIContent("Normal Colour", "Colour used to indicate the tile placement area in the TileEd Grid.");
		private static readonly GUIContent GC_GridDeleteColor = new GUIContent("Delete Colour", "Colour used to indicate the tile deletion area in the TileEd Grid.");
		private static readonly GUIContent GC_SculptDownColor = new GUIContent("Sculpt Colour", "Colour used to indicate the tile which will be sculpted downwards when in Sculpting mode.");
		private static readonly GUIContent GC_GridMarkColor = new GUIContent("Mark Colour", "Colour used when marking tiles.");

		private static readonly GUIContent GC_Selection = new GUIContent("Selection", "Settings related to tile selection.");
		private static readonly GUIContent GC_SelectColor0 = new GUIContent("Main Colour", "Main Colour of a selected tile.");
		private static readonly GUIContent GC_SelectColor1 = new GUIContent("Secondary Colour", "The second colour used to complete the visual effect of a selected tile.");
		private static readonly GUIContent GC_SelectColor2 = new GUIContent("Behind Tiles", "Colour used for selected tiles that are behind other tiles.");

		private static readonly GUIContent GC_HotkeysLabel = new GUIContent("Hot-keys");
		private static readonly string HotKeysInfo =
			"[Shift] - Cursor Delete mode\n" +
			"[Ctrl] - Cursor Mark mode\n" +
			"[Ctrl+Shift+ScrollWheel] - Change Grid Y-Position\n" +
			"[Ctrl+ScrollWheel] - Change Brush size\n" +
			"[Alt+ScrollWheel] - Rotate Brush\n" +
			"[Ctrl+Alt+ScrollWheel] - Change Y offset (Props only)\n";

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		private int activeSection = 1;
		private int prevSection = 1;
		private Vector2 scroll = Vector2.zero;
		private GUIContent[] labels;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		public static void Show_Window()
		{
			TileEd_Settings win = EditorWindow.GetWindow<TileEd_Settings>("TileEd");
			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_settings" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			win.titleContent = new GUIContent("TileEd", icon);
		}

		protected void OnEnable()
		{
			labels = new GUIContent[TileEdGlobal.editors.Count + 1];
			labels[0] = GC_General;
			for (int i = 0; i < TileEdGlobal.editors.Count; i++) labels[i+1] = TileEdGlobal.editors[i].label;

			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_settings" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			titleContent = new GUIContent("TileEd", icon);

			minSize = new Vector2(150, 150);
			activeSection = 1;
			prevSection = 1;
		}

		protected void OnFocus()
		{
			if (activeSection > 0)
			{
				TileEdGlobal.editors[activeSection-1].ed.OnSettingsFocus(this);
			}
		}

		//protected void OnLostFocus()
		//{
		//}

		//protected void OnSelectionChange()
		//{
		//}

		//protected void OnInspectorUpdate()
		//{ // 10 fps
		//}

		protected void Update()
		{ // 100 fps
			if (AssetPreview.IsLoadingAssetPreviews()) Repaint();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region GUI

		protected void OnGUI()
		{
			if (plyEdGUI.Tabbar(ref activeSection, labels))
			{
				if (activeSection != prevSection && activeSection > 0) TileEdGlobal.editors[activeSection-1].ed.OnSettingsFocus(this);
				prevSection = activeSection;
			}

			EditorGUILayout.Space();
			if (activeSection == 0)
			{
				OnGUI_General();
			}
			else
			{
				if (TileEdGlobal.activeTileEdToolIdx >= 0 && TileEdGlobal.activeTileEdToolIdx != (activeSection-1))
				{
					// make sure the active tool (if open in palette) is the same as what is open in settings
					// else the thumbs shown in palette might differ from those in settings and flicker will
					// occur as they need to continuously reload
					TileEdGlobal.activeTileEdToolIdx = (activeSection-1);
				}

				TileEdGlobal.editors[activeSection-1].ed.OnSettingsGUI(this);
			}

			//EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Tabbar);
			//{
			//	if (GUILayout.Toggle(activeSection == -1, GC_General, plyEdGUI.Styles.TabbarButton))
			//	{
			//		activeSection = -1;
			//		prevSection = -1;
			//	}

			//	for (int i = 0; i < TileEdGlobal.editors.Count; i++)
			//	{
			//		if (GUILayout.Toggle(activeSection == i, TileEdGlobal.editors[i].label, plyEdGUI.Styles.TabbarButton))
			//		{
			//			activeSection = i;
			//			if (prevSection != activeSection) TileEdGlobal.editors[activeSection].ed.OnSettingsFocus(this);
			//			prevSection = activeSection;
			//		}
			//	}
			//	GUILayout.FlexibleSpace();
			//}
			//EditorGUILayout.EndHorizontal();
			//EditorGUILayout.Space();

			//if (activeSection == -1)
			//{
			//	OnGUI_General();
			//}
			//else
			//{
			//	if (TileEdGlobal.activeTileEdToolIdx >= 0 && TileEdGlobal.activeTileEdToolIdx != activeSection)
			//	{
			//		// make sure the active tool (if open in palette) is the same as what is open in settings
			//		// else the thumbs shown in palette might differ from those in settings and flicker will
			//		// occur as they need to continuously reload
			//		TileEdGlobal.activeTileEdToolIdx = activeSection;
			//	}

			//	TileEdGlobal.editors[activeSection].ed.OnSettingsGUI(this);
			//}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region General

		private void OnGUI_General()
		{
			scroll = EditorGUILayout.BeginScrollView(scroll);
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(350));

			EditorGUILayout.BeginHorizontal();
			{
				EditorGUI.BeginChangeCheck();
				TileEdGlobal.autoDisableSceneGrid = EditorGUILayout.Toggle(GC_AutoDisableSceneGrid, TileEdGlobal.autoDisableSceneGrid);
				if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.AutoDisableSceneGrid", TileEdGlobal.autoDisableSceneGrid);

				if (TileEdGlobal.autoDisableSceneGrid)
				{
					EditorGUIUtility.labelWidth = 90;
					EditorGUI.BeginChangeCheck();
					TileEdGlobal.permaOffSceneGrid = EditorGUILayout.Toggle(GC_PermaOffSceneGrid, TileEdGlobal.permaOffSceneGrid);
					if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.PermaOffSceneGrid", TileEdGlobal.permaOffSceneGrid);
					EditorGUIUtility.labelWidth = 0;
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			EditorGUI.BeginChangeCheck();
			TileEdGlobal.seperateGridHeights = EditorGUILayout.Toggle(GC_SeperateGridHeights, TileEdGlobal.seperateGridHeights);
			if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.SeperateGridHeights", TileEdGlobal.seperateGridHeights);

			int idx = TileEdGlobal.templatesPreviewSize == 64 ? 0 : 1;
			EditorGUI.BeginChangeCheck();
			idx = EditorGUILayout.Popup(GC_TemplateSize, idx, GC_TemplateSizes);
			if (EditorGUI.EndChangeCheck()) 
			{
				TileEdGlobal.templatesPreviewSize = idx == 0 ? 64 : 128;
				EditorPrefs.SetInt("TileEd.Templates.TilePreviewSize", TileEdGlobal.templatesPreviewSize);
			}

			EditorGUI.BeginChangeCheck();
			TileEdGlobal.combineBlockSize = EditorGUILayout.IntSlider(GC_CombineSize, TileEdGlobal.combineBlockSize, 4, 128);
			if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.CombineBlockSize", TileEdGlobal.combineBlockSize);			

			//EditorGUI.BeginChangeCheck();
			//TileEdGlobal.doLightmapUVs = EditorGUILayout.Toggle(GC_CreateUV2, TileEdGlobal.doLightmapUVs);
			//if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.DoLightmapUVs", TileEdGlobal.doLightmapUVs);

			EditorGUI.BeginChangeCheck();
			TileEdGlobal.recreateIgnoreProps = EditorGUILayout.Toggle(GC_RecreateIgnoreProps, TileEdGlobal.recreateIgnoreProps);
			if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.recreateIgnoreProps", TileEdGlobal.recreateIgnoreProps);

			EditorGUI.BeginChangeCheck();
			TileEdGlobal.layersHeight = EditorGUILayout.IntField(GC_TileLayersListSize, TileEdGlobal.layersHeight);
			if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.TileLayers.Height", TileEdGlobal.layersHeight);

			if (RenderSectionHead(GC_Grid0))
			{
				TileEdGlobal.gridStyleChanged = true;
				TileEdGlobal.gridStyle[0] = 0;
				TileEdGlobal.gridColor[0] = new Color(0f, 0.62f, 1f, 1f);
				TileEdGlobal.gridThin[0] = true;
				EditorPrefs.SetInt("TileEd.Grid.Style0", TileEdGlobal.gridStyle[0]);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.Color0", TileEdGlobal.gridColor[0]);
				EditorPrefs.SetBool("TileEd.Grid.Thin0", TileEdGlobal.gridThin[0]);
			}
			EditorGUI.indentLevel++;
			{
				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridStyle[0] = EditorGUILayout.Popup(GC_GridSyle, TileEdGlobal.gridStyle[0], GC_GridStyleOps);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					EditorPrefs.SetInt("TileEd.Grid.Style0", TileEdGlobal.gridStyle[0]);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridColor[0] = EditorGUILayout.ColorField(GC_GridColor, TileEdGlobal.gridColor[0]);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.Color0", TileEdGlobal.gridColor[0]);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridThin[0] = EditorGUILayout.Toggle(GC_GridThin, TileEdGlobal.gridThin[0]);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					EditorPrefs.SetBool("TileEd.Grid.Thin0", TileEdGlobal.gridThin[0]);
				}
			}
			EditorGUI.indentLevel--;

			if (RenderSectionHead(GC_Grid1))
			{
				TileEdGlobal.gridStyleChanged = true;
				TileEdGlobal.gridStyle[1] = 1;
				TileEdGlobal.gridColor[1] = new Color(1f, 1f, 0f, 0.65f);
				TileEdGlobal.gridThin[1] = true;
				EditorPrefs.SetInt("TileEd.Grid.Style1", TileEdGlobal.gridStyle[1]);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.Color1", TileEdGlobal.gridColor[1]);
				EditorPrefs.SetBool("TileEd.Grid.Thin1", TileEdGlobal.gridThin[1]);
			}
			EditorGUI.indentLevel++;
			{
				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridStyle[1] = EditorGUILayout.Popup(GC_GridSyle, TileEdGlobal.gridStyle[1], GC_GridStyleOps);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					EditorPrefs.SetInt("TileEd.Grid.Style1", TileEdGlobal.gridStyle[1]);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridColor[1] = EditorGUILayout.ColorField(GC_GridColor, TileEdGlobal.gridColor[1]);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.Color1", TileEdGlobal.gridColor[1]);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridThin[1] = EditorGUILayout.Toggle(GC_GridThin, TileEdGlobal.gridThin[1]);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.gridStyleChanged = true;
					EditorPrefs.SetBool("TileEd.Grid.Thin1", TileEdGlobal.gridThin[1]);
				}
			}
			EditorGUI.indentLevel--;

			if (RenderSectionHead(GC_Cursor))
			{
				TileEdGlobal.cursorStyleChanged = true;
				TileEdGlobal.gridPlacementCursor = new Color(0.12f, 0.86f, 1f, 1f);
				TileEdGlobal.gridDeleteCursor = new Color(1f, 0f, 0f, 1f);
				TileEdGlobal.gridMarkCursor = new Color(1f, 1f, 0f, 1f);
				TileEdGlobal.gridSculptDownCursor = new Color(1f, 0.5f, 0f, 1f);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.PlaceColor", TileEdGlobal.gridPlacementCursor);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.DeleteColor", TileEdGlobal.gridDeleteCursor);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.MarkColor", TileEdGlobal.gridMarkCursor);
				plyEdUtil.EdPrefs_GetColor("TileEd.Grid.SculptDownColor", TileEdGlobal.gridSculptDownCursor);
			}
			EditorGUI.indentLevel++;
			{
				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridPlacementCursor = EditorGUILayout.ColorField(GC_GridPlaceColor, TileEdGlobal.gridPlacementCursor);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.cursorStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.PlaceColor", TileEdGlobal.gridPlacementCursor);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridDeleteCursor = EditorGUILayout.ColorField(GC_GridDeleteColor, TileEdGlobal.gridDeleteCursor);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.cursorStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.DeleteColor", TileEdGlobal.gridDeleteCursor);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridSculptDownCursor = EditorGUILayout.ColorField(GC_SculptDownColor, TileEdGlobal.gridSculptDownCursor);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.cursorStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SculptDownColor", TileEdGlobal.gridSculptDownCursor);
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.gridMarkCursor = EditorGUILayout.ColorField(GC_GridMarkColor, TileEdGlobal.gridMarkCursor);
				if (EditorGUI.EndChangeCheck())
				{
					TileEdGlobal.cursorStyleChanged = true;
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.MarkColor", TileEdGlobal.gridMarkCursor);
				}
			}
			EditorGUI.indentLevel--;

			if (RenderSectionHead(GC_Selection))
			{
				TileEdGlobal.selectionColors[0] = new Color(0.93f, 0.64f, 0f, 0.5f);
				TileEdGlobal.selectionColors[1] = new Color(1f, 1f, 0f, 0f);
				TileEdGlobal.selectionColors[2] = new Color(1f, 1f, 0f, 0.15f);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor0", TileEdGlobal.selectionColors[0]);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor1", TileEdGlobal.selectionColors[1]);
				plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor2", TileEdGlobal.selectionColors[2]);
				TileEdGUI.UpdateSelectionColours();
			}
			EditorGUI.indentLevel++;
			{
				EditorGUI.BeginChangeCheck();
				TileEdGlobal.selectionColors[0] = EditorGUILayout.ColorField(GC_SelectColor0, TileEdGlobal.selectionColors[0]);
				if (EditorGUI.EndChangeCheck())
				{
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor0", TileEdGlobal.selectionColors[0]);
					TileEdGUI.UpdateSelectionColours();
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.selectionColors[1] = EditorGUILayout.ColorField(GC_SelectColor1, TileEdGlobal.selectionColors[1]);
				if (EditorGUI.EndChangeCheck())
				{
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor1", TileEdGlobal.selectionColors[1]);
					TileEdGUI.UpdateSelectionColours();
				}

				EditorGUI.BeginChangeCheck();
				TileEdGlobal.selectionColors[2] = EditorGUILayout.ColorField(GC_SelectColor2, TileEdGlobal.selectionColors[2]);
				if (EditorGUI.EndChangeCheck())
				{
					plyEdUtil.EdPrefs_SetColor("TileEd.Grid.SelectionColor2", TileEdGlobal.selectionColors[2]);
					TileEdGUI.UpdateSelectionColours();
				}
			}
			EditorGUI.indentLevel--;
			
			EditorGUILayout.Space();
			GUILayout.Label(GC_HotkeysLabel);
			EditorGUILayout.HelpBox(HotKeysInfo, MessageType.None, true);

			GUILayout.Space(20);
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
		}

		private bool RenderSectionHead(GUIContent label)
		{
			bool res = false;
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.Label(label, GUILayout.Width(EditorGUIUtility.labelWidth - 4));
				
				if (GUILayout.Button(GC_Reset, plyEdGUI.Styles.MiniButton, GUILayout.Width(23))) res = true;
				EditorGUILayout.Space();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			return res;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
