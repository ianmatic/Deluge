﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_MapGroupWindow : EditorWindow
	{
		public string groupName { get; private set; }
		public float tileSize { get; private set; }
		public float tileHeight { get; private set; }
		public bool centreTiles { get; private set; }

		private System.Action<TileEd_MapGroupWindow> callback;
		private bool accepted = false;
		private bool lostFocus = false;
		private static readonly GUIContent GC_Name = new GUIContent("Name");
		private static readonly GUIContent GC_TileSize = new GUIContent("Tile size", "Square Size of grid tiles");
		private static readonly GUIContent GC_TileHeight = new GUIContent("Tile height", "Value to increase Y offset with when moving grid up or down");
		private static readonly GUIContent GC_CentreTiles = new GUIContent("Centre align", "The default is to align the centre of the centre tile to the centre of the world. With this option off a corner of the centre tile aligns with the world centre. This is useful when you regularly use tiles of different sizes and want them to align.");

		public static void ShowWiz(TileEdMapGroup group, System.Action<TileEd_MapGroupWindow> callback)
		{
			TileEd_MapGroupWindow wiz = EditorWindow.GetWindow<TileEd_MapGroupWindow>(true, "TileEd Map Group", true);
			wiz.groupName = group.name;
			wiz.tileSize = group.tileSize;
			wiz.tileHeight = group.tileHeight;
			wiz.centreTiles = group.centreTiles;
			wiz.callback = callback;
			wiz.minSize = wiz.maxSize = new Vector2(250, 120);
			wiz.ShowUtility();
		}

		protected void OnFocus() { lostFocus = false; }
		protected void OnLostFocus() { lostFocus = true; }

		protected void Update()
		{
			if (lostFocus) this.Close();
			if (accepted && callback != null) callback(this);
		}

		protected void OnGUI()
		{
			EditorGUILayout.Space();
			EditorGUIUtility.labelWidth = 80;
			groupName = EditorGUILayout.TextField(GC_Name, groupName);
			tileSize = EditorGUILayout.FloatField(GC_TileSize, tileSize);
			tileHeight = EditorGUILayout.FloatField(GC_TileHeight, tileHeight);
			centreTiles = EditorGUILayout.Toggle(GC_CentreTiles, centreTiles);
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("Accept", GUILayout.Width(80))) accepted = true;
				GUILayout.Space(5);
				if (GUILayout.Button("Cancel", GUILayout.Width(80))) this.Close();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(10);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
