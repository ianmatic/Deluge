﻿using UnityEngine;
using UnityEditor;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_Ed_Tiles_SettingsPopup : PopupWindowContent
	{
		public TileEdTileSetsAsset asset;
		public TileEdTile tile;

		private static readonly GUIContent GC_MetaUpdate = new GUIContent("Update Maps", "You must use this button to update all map assets after making changes to the tile's meta data.");
		private static readonly GUIContent GC_TileMeta = new GUIContent("Meta", "Extra data associated with this tile. Note that this is not applied to the placed GameObject but is inserted into the meta property of the tile in the TileEd Map asset");
		private static readonly GUIContent GC_SetTag = new GUIContent("Tag", "If not set then the Tag set in the prefab will be used as is");
		private static readonly GUIContent GC_SetLayer = new GUIContent("Layer", "If not set then the Layer set in the prefab will be used as is");
		private static readonly GUIContent GC_SetStatic = new GUIContent("Static", "If not set then the Static Flags set in the prefab will be used as is");
		private static readonly GUIContent GC_SetNavArea = new GUIContent("NavArea", "Set the navigation area to be used");
		private static readonly GUIContent GC_SetSort = new GUIContent("Sort", "Set the sorting layer and order");
		private static readonly GUIContent[] GC_SetLabel = new GUIContent[] { new GUIContent("Floor"), new GUIContent("Walls") };
		private GUIContent[] GC_NavAreas = new GUIContent[] { new GUIContent("Allowable"), new GUIContent("Not Walkable") };
		private GUIContent[] GC_SortNames = new GUIContent[0];
		private int navAreaNamesIdx = -1;

		public override void OnOpen()
		{
			if (asset == null || tile == null) return;
			navAreaNamesIdx = -1;
			string[] names = GameObjectUtility.GetNavMeshAreaNames();
			GC_NavAreas = new GUIContent[names.Length];
			for (int i = 0; i < names.Length; i++) 
			{
				GC_NavAreas[i] = new GUIContent(names[i]);
				if (tile.navArea == GameObjectUtility.GetNavMeshAreaFromName(names[i])) navAreaNamesIdx = i;
			}
			TileEd.GetSortingLayerNames(ref GC_SortNames);
		}

		public override void OnGUI(Rect rect)
		{
			if (asset == null || tile == null) return;

			EditorGUILayout.BeginHorizontal();
			tile.setNavArea = EditorGUILayout.ToggleLeft(GC_SetNavArea, tile.setNavArea, GUILayout.Width(86));
			if (tile.setNavArea)
			{
				EditorGUI.BeginChangeCheck();
				navAreaNamesIdx = EditorGUILayout.Popup(navAreaNamesIdx, GC_NavAreas);
				if (EditorGUI.EndChangeCheck()) tile.navArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[navAreaNamesIdx].text);
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			tile.setStaticFlags = EditorGUILayout.ToggleLeft(GC_SetStatic, tile.setStaticFlags, GUILayout.Width(86));
			if (tile.setStaticFlags) tile.staticFlags = (int)(StaticEditorFlags)EditorGUILayout.EnumFlagsField((StaticEditorFlags)tile.staticFlags);
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			tile.setLayer = EditorGUILayout.ToggleLeft(GC_SetLayer, tile.setLayer, GUILayout.Width(86));
			if (tile.setLayer) tile.layer = EditorGUILayout.LayerField(tile.layer);
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			tile.setSort = EditorGUILayout.ToggleLeft(GC_SetSort, tile.setSort, GUILayout.Width(86));
			if (tile.setSort)
			{
				int idx = TileEd.GetSortingLayerIdxFromUniqueId(tile.sortLayerId);
				EditorGUI.BeginChangeCheck();
				idx = EditorGUILayout.Popup(idx, GC_SortNames);
				if (EditorGUI.EndChangeCheck()) tile.sortLayerId = TileEd.GetSortingLayerUniqueID(idx);
				tile.sortOrder = EditorGUILayout.IntField(tile.sortOrder, GUILayout.Width(20));
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.BeginHorizontal();
			tile.setTag = EditorGUILayout.ToggleLeft(GC_SetTag, tile.setTag, GUILayout.Width(86));
			if (tile.setTag) tile.tag = EditorGUILayout.TagField(tile.tag);
			EditorGUILayout.EndHorizontal();

			EditorGUIUtility.labelWidth = 40;
			tile.meta = EditorGUILayout.TextField(GC_TileMeta, tile.meta);

			if (GUI.changed)
			{
				GUI.changed = false;
				plyEdUtil.SetDirty(asset);
			}

			if (GUILayout.Button(GC_MetaUpdate))
			{
				UpdateMapAssets();
			}

		}

		private void UpdateMapAssets()
		{
			EditorUtility.DisplayProgressBar("Updating map assets", "", 0f);

			string[] guids = AssetDatabase.FindAssets("t:TileEdMapAsset");
			float progress = 0f;
			float step = 1f / guids.Length;
			foreach (string guid in guids)
			{
				TileEdMapAsset map = AssetDatabase.LoadAssetAtPath<TileEdMapAsset>(AssetDatabase.GUIDToAssetPath(guid));
				if (map == null) continue;
				EditorUtility.DisplayProgressBar("Updating map assets", map.ident, progress += step);

				bool updated = false;
				foreach (TileEdMapGroup g in map.groups)
				{
					for (int i = 0; i < g.Count; i++)
					{
						TileEdMapTile t = g[i];
						if (t != null &&
							t.toolIdent == TileEd_Ed_Tiles.TOOL_IDENT &&
							t.data[TileEd_Ed_Tiles._TileIdent] == tile.ident)
						{
							updated = true;
							t.meta = tile.meta;
						}
					}
				}

				if (updated)
				{
					plyEdUtil.SetDirty(map);
				}
			}

			EditorUtility.ClearProgressBar();
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}

