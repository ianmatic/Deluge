﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdTransition
	{

		// the tile-set this transition is made with (it is between the TileSet that contains this transition and the targetTileSetIdent)
		public int targetTileSetIdent;

		// the actual tiles are created in the Tile list of TileSet that contains this transition
		public List<int> tileIdents = new List<int>();

		// helpers while editing
		[System.NonSerialized] public List<TileEdTile> _tileCache = null;

		public bool LoadCache(TileEdTileSet tileSet, TileEdTileSetsAsset asset)
		{
			bool save = false;
			if (_tileCache == null)
			{
				_tileCache = new List<TileEdTile>();
				for (int i = 0; i < tileIdents.Count; i++)
				{
					TileEdTile t = tileSet.FindTile(tileIdents[i]);
					
					if (t == null && asset != null)
					{	// this should not happen, but just in case ...
						save = true;
						t = new TileEdTile() { ident = asset.GenerateTileIdent() };
						tileSet.tiles.Add(t);
					}

					_tileCache.Add(t);
				}
			}
			return save;
		}

		// ------------------------------------------------------------------------------------------------------------
	}

}
