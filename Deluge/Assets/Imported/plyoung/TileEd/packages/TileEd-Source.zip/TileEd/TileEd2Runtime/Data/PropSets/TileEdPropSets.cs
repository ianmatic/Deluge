﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdPropSet
	{
		public int ident;
		public string name;
		public List<TileEdProp> tiles = new List<TileEdProp>();

		public override string ToString()
		{
			//#if DEBUG
			//			return name + " ("+ident+")" ;
			//#else
			//			return name;
			//#endif
			return name;
		}

		public TileEdProp FindTile(int ident)
		{
			if (ident < 0) return null;
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].ident == ident) return tiles[i];
			}
			return null;
		}

		public bool ContainsPrefab(int idx, GameObject fab)
		{
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].prefab[idx] == fab) return true;
			}
			return false;
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
