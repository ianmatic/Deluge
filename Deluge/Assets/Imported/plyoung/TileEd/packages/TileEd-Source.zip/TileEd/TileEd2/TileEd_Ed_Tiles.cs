﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_Ed_Tiles : TileEd_Ed_Base
    {
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public const int TOOL_IDENT = 1;
		private const string ASSET_NAME = "Tiles.asset";
		private const string TMPLT_NAME = "TileTemplates.asset";
		private const string ROOT_NAME = "Tiles";
		private const string PATH = "Tiles/";

		// these are used with TileEdMapTile.data[] array
		private const int _TileSetIdent = 0;		// TileSet ident (TileSet that tile is in)
		public const int  _TileIdent = 1;			// Tile ident
		private const int _TileIdx = 2;				// Index into tiles list of a TileSet. Help to quickly check tile idx without lookup into definitions
		private const int _TileRotation = 3;		// Rotation of tile (0, 90, 180, 270)
		private const int _TileFabIdx = 4;			// Index into Tile's prefab array
		private const int _TransitionSetIdent = 5;	// Help determine which TileSet this tile transitions towards. Same as _TileSetIdent if full tile
		private const int _TransitionIdx = 6;		// Index into tiles list of a TileSet's transition. Help to quickly determine transition state/ idx of the tile without extra lookups into definitions
		private const int _IsRotating = 7;			// Indicate if tile is rotating tile or not without having to first lookup the TileSet
		private const int _MaxTileProperties = 8;

		private static readonly int[][,] Rotations = new int[4][,]
		{
			new int[2,4] { { 270, 180, 0, 90 }, { 90, 0, 180, 270 } },
			new int[2,4] { { 0, 270, 90, 180 }, { 180, 90, 270, 0 } },
			new int[2,4] { { 90, 0, 180, 270 }, { 270, 180, 0, 90 } },
			new int[2,4] { { 180, 90, 270, 0 }, { 0, 270, 90, 180 } },
		};

		private const int b0001 = 8;
		private const int b0010 = 4;
		private const int b0100 = 2;
		private const int b1000 = 1;

		// original transition id runs from 1 to 14. Need to map this to 4 possible transition tiles and associated rotations
		private static readonly int[] TransitionIdMapping =  { 0, 1, 1, 0, 1, 3, 0, 2, 1, 0, 3, 2, 0, 2, 2 };
		private static readonly int[] TransitionNoRotation = { 0, 0, 3, 0, 2, 0, 3, 3, 1, 1, 1, 0, 2, 1, 2 };
		private static readonly int[] TransitionRotations =  { 0, 0, 270, 0, 180, 0, 270, 270, 90, 90, 90, 0, 180, 90, 180 };

		// reverse lookup from Transition Idx and Rotation data
		// { solid{90, 180, 270, 0} ,walls{90, 180, 270, 0}, convex{90, 180, 270, 0}, concave{90, 180, 270, 0}, special{90, 180, 270, 0} }
		private static readonly int[,] TransitionIdLookup = { { 15, 15, 15, 15 }, { 3, 9, 12, 6 }, { 1, 8, 4, 2 }, { 11, 13, 14, 7 }, { 5, 10, 5, 10 } };
		private static readonly int[] TransitionIdLookupNoRot = { 15, 3, 9, 12, 6, 1, 8, 4, 2, 11, 13, 14, 7, 5, 10, 5, 10 };

		private static readonly GUIContent GC_DropArea = new GUIContent("Drop tiles here or press =>");
		private static readonly GUIContent GC_DropAreaExtra = new GUIContent("Drop extra tiles here");
		private static readonly GUIContent GC_DelTmpl = new GUIContent(Ico._remove, "Delete Template");
		private static readonly GUIContent GC_Wait = new GUIContent(Ico._wait);
		private static readonly GUIContent GC_Error = new GUIContent(Ico._error_c);
		private static readonly GUIContent GC_Up = new GUIContent(Ico._chevron_up);
		private static readonly GUIContent GC_Down = new GUIContent(Ico._chevron_down);
		private static readonly GUIContent GC_Rotation = new GUIContent(Ico._rotate_right + "Rot", "Change tile rotation [Alt+ScrollWheel]");
		private static readonly GUIContent GC_EraseAll = new GUIContent(Ico._delete + " Remove All", "Remove all Tiles from selected Tile Layer");
		private static readonly GUIContent GC_SelectionHead = new GUIContent(Ico._marquee + " Selection");
		private static readonly GUIContent GC_Copy = new GUIContent(Ico._copy + " Copy", "Copy the selection");
		private static readonly GUIContent GC_Cut = new GUIContent(Ico._cut + " Cut", "Cut the selection");
		private static readonly GUIContent GC_Erase = new GUIContent(Ico._eraser + " Erase", "Erase the selection");
		private static readonly GUIContent GC_CopyBufferHead = new GUIContent(Ico._memory + " Copy Buffer");
		private static readonly GUIContent GC_TemplatesHead = new GUIContent(Ico._cube + " Templates");
		private static readonly GUIContent GC_CreateTemplate = new GUIContent("Save to Template");
		private static readonly GUIContent GC_NoTemplates = new GUIContent("No Templates saved.");
		private static readonly GUIContent GC_SimpleTilesHeading = new GUIContent("Simple Tiles");
		private static readonly GUIContent[] GC_AutoTilesHeading = new GUIContent[] { new GUIContent("Auto Tiles [Rotating]"), new GUIContent("Auto Tiles [Directional]"), new GUIContent("Auto Tiles [Narrow]") };
		private static readonly GUIContent GC_DungeonTilesHeading = new GUIContent("Dungeon Tiles");
		private static readonly GUIContent GC_OpenTileSettingsPopup = new GUIContent(Ico._chevron_down, "Show tile settings");
		private static readonly GUIContent GC_TileSetDef = new GUIContent(Ico._square_dotted + " Definition");
		private static readonly GUIContent GC_TileSetTransitions = new GUIContent(Ico._transition + " Transitions");
		private static readonly GUIContent GC_ClearTile = new GUIContent(Ico._remove, "Remove prefab from this tile");
		private static readonly GUIContent GC_CustomThumb = new GUIContent(Ico._stop, "Select a custom thumbnail image for this tile");
		private static readonly GUIContent GC_AddRandomTile = new GUIContent(Ico._add, "Add random tile option");
		private static readonly GUIContent[] GC_AutoTileSet = new GUIContent[] { new GUIContent("Floor"), new GUIContent("Wall"), new GUIContent("Convex"), new GUIContent("Concave"), new GUIContent("Special") };
		private static readonly GUIContent[] GC_AutoTileTransition = new GUIContent[] { new GUIContent("Side"), new GUIContent("Convex"), new GUIContent("Concave"), new GUIContent("Special") };
		private static readonly GUIContent[] GC_TileNumber = new GUIContent[] { new GUIContent("1"), new GUIContent("2"), new GUIContent("3"), new GUIContent("4") };
		private static readonly GUIContent GC_AutoTileIcon = new GUIContent(Ico._mountain);
		private static readonly GUIContent GC_RandomRotOn = new GUIContent(Ico._random_on, "Random Rotation of tile is on");
		private static readonly GUIContent GC_RandomRotOff = new GUIContent(Ico._random_off, "Random Rotation of tile is off");
		private static readonly GUIContent GC_RandomFabOn = new GUIContent(Ico._random_on, "Random tile prefab selection is on");
		private static readonly GUIContent GC_RandomFabOff = new GUIContent(Ico._random_off, "Random tile prefab selection is off");
		private static readonly GUIContent GC_RandomFabAllOn = new GUIContent(Ico._grid, "Choose a random tile for each tile in the brush. Only when random is on.");
		private static readonly GUIContent GC_RandomFabAllOff = new GUIContent(Ico._grid_off, "Choose one random tile to represent all tiles in the brush. Only when random is on.");
		private static readonly GUIContent GC_SculptOn = new GUIContent(Ico._image + " shift Sculpt", "[Shift+LeftMouse] in Sculpt mode to lower tiles\n[LeftMouse] to place or raise tiles");
		private static readonly GUIContent GC_SculptOff = new GUIContent(Ico._eraser +" shift Erase", "[Shift+LeftMouse] in Erase Mode to erase tiles\n[LeftMouse] to place tiles");
		private static readonly GUIContent GC_CreateTransition = new GUIContent("Create Transition");
		private static readonly GUIContent GC_DeleteTransition = new GUIContent("Delete Transition");
		private static readonly GUIContent GC_WallSystem = new GUIContent("System", "Determines how the sculpting mode of auto-tiles will behave");
		private static readonly GUIContent GC_SetTag = new GUIContent("Tag", "If not set then the Tag set in the prefab will be used as is");
		private static readonly GUIContent GC_SetLayer = new GUIContent("Layer", "If not set then the Layer set in the prefab will be used as is");
		private static readonly GUIContent GC_SetStatic = new GUIContent("Static", "If not set then the Static Flags set in the prefab will be used as is");
		private static readonly GUIContent GC_SetNavArea = new GUIContent("NavArea", "Set the navigation area to be used");
		private static readonly GUIContent GC_SetSort = new GUIContent("Sort", "Set the sorting layer and order");
		private static readonly GUIContent[] GC_SetLabel = new GUIContent[] { new GUIContent("Floor"), new GUIContent("Walls") };
		private static readonly GUIContent GC_Fab = new GUIContent(Ico._cube + "Fab", "Prefab options");
		//private static readonly GUIContent GC_TileSpaceSharing = new GUIContent("Tile space sharing", "Enable this if your walls are created such that they need to share the space otherwise occupied by a floor tile");
		//private static readonly GUIContent GC_TileSpaceSharingInclFloors = new GUIContent("Floor included", "If set then it is assumed that the floor is ");
		private static readonly GUIContent[] GC_ShowAutoPieces = { new GUIContent(Ico._visible), new GUIContent(Ico._hidden) };
		private static readonly GUIContent GC_AutoErase = new GUIContent("Auto-erase", "Auto-tile placement will auto erase tiles to depth above and below. Default value is 2. Setting these values to 0 can cause unexpected behaviour.");

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars
		
		public class PlacedTileInfo
		{
			/// <summary> the tile object that was placed in the scene </summary>
			public GameObject go;
			/// <summary> data saved in the TileEd map </summary>
			public TileEdMapTile tile;
			/// <summary> tile-group/ tile-layer this tile was placed under </summary>
			public TileEdMapGroup group;
		}

		/// <summary> Called after a tile was placed in the scene </summary>
		public static event System.Action<PlacedTileInfo> onPlacedTile = null;

		private TileEdTileSetsAsset asset;
		private TileEdTemplatesAsset tmplAsset;
		private static int tileSetIdx = -2;
		private static int currTileIdx = -1;
		private static bool currTileIsSimple = true;
		private int dragDropTarget = -2;		// -2:none, -1:main drop area, else index of an tile
		private int dragDropSubTarget = -2;		// -2:none, else index of an existing tile
		private static Vector2[] scroll = { Vector2.zero, Vector2.zero, Vector2.zero }; // 0: sets list, 1: settings tiles, 2: palette
		private plyEdGUI.ListOps listOps;
		private Transform parentTr = null;		// the root of this tool within the active map/tool/group
		private static int tileRotation = 0;	// 0, 90, 180, 270
		private bool wasClickOnSelected = false;
		private List<TileEdSelected> selection = new List<TileEdSelected>();
		private TileEdTemplate copyBuffer = new TileEdTemplate() { toolIdent = TOOL_IDENT };
		private GUIContent GC_CopyBuffer = new GUIContent(Ico._wait, "Click to enter paste mode");
		private float lastInspectorWidth = 0.0f;
		private bool edTransitions = false;
		private bool canRandomFab = true;
		private bool canRandomFabAll = true; // for each tile in brush
		private bool canRandomRotate = false;
		private bool canSculpt = false;
		private bool showTileSettings = true;
		private TileEdTileSet[] transitionSets = null;
		private GUIContent[] GC_TransitionTileSets = null;
		private int selTransitionIdx = -1;
		private TileEdTransition transition = null;
		private static bool[] foldouts = new bool[] { true, true, true, true, true, true, true, true, true };
		private TileEdTile tileWaitCustomThumb = null;
		private static int showAutoTilePieces = 0;
		private static int[] autoTileDepthAboveBelow = { 2, 2 };
		//private plyEdCoroutine cacheBuilder = null;

		private static TileEd_Ed_Tiles_SettingsPopup tileSettingsPopup = new TileEd_Ed_Tiles_SettingsPopup();
		private static bool def_setTag = false;
		private static string def_tag = "Untagged";
		private static bool def_setLayer = false;
		private static int def_layer = 0;
		private static bool def_setSort = false;
		private static int def_sortLayerNameIdx = 0;
		private static int def_sortOrder = 0;
		private static bool def_setStaticFlags = false;
		private static StaticEditorFlags def_staticFlags = (StaticEditorFlags)(-1);
		private static bool def_setNavArea = false;
		private static int def_navAreaNamesIdx = 1;
		private int autoSet_floorNavAreaNamesIdx = -1;
		private int autoSet_wallNavAreaNamesIdx = -1;

		private GUIContent[] GC_NavAreas = new GUIContent[] { new GUIContent("Walkable"), new GUIContent("Not Walkable") };
		private GUIContent[] GC_SortNames = new GUIContent[0];

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region settings

		public override int ToolIdent()
		{
			return TOOL_IDENT;
		}

		public override List<TileSetInfo> GetTileSets()
		{			
			List<TileSetInfo> res = new List<TileSetInfo>();
			if (LoadAsset())
			{
				for (int i = 0; i < asset.tileSets.Count; i++)
				{
					res.Add(new TileSetInfo() { toolIdent = TOOL_IDENT, setIdent = asset.tileSets[i].ident, setName = asset.tileSets[i].name });
				}
			}
			return res;
		}

		public override void OnSettingsFocus(EditorWindow ed)
		{
			string[] names = GameObjectUtility.GetNavMeshAreaNames();
			GC_NavAreas = new GUIContent[names.Length];
			for (int i = 0; i < names.Length; i++) GC_NavAreas[i] = new GUIContent(names[i]);
		}

		public override void OnSettingsGUI(EditorWindow ed)
		{
			base.OnSettingsGUI(ed);
			TileEdGUI.LoadResources();
			if (!LoadAsset()) return;

			if (listOps == null)
			{
				listOps = new plyEdGUI.ListOps()
				{
					emptyMsg = "Click [+] to add\na new Tile Set",
					canDuplicate = false,
					onAction = OnListAction,
					extraButtons = new plyEdGUI.ListOpsExtraToolbarButton[]
					{
						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._rename, "Rename Tile-Set"),
							callback = () => { plyTextInputWiz.ShowWiz("Rename Tile Set", null, asset.tileSets[tileSetIdx].name, DoRenameTileSet, null); },
							enabled = () => { return (tileSetIdx >= 0); },
							//shortcut = KeyCode.F2
						},
						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._help_c, "Open Documentation"),
							callback = () => { Application.OpenURL(TileEdGlobal.URL_DOCS); },
							//shortcut = KeyCode.F1
						},					
					}
				};
			}

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.List<TileEdTileSet>(ref tileSetIdx, asset.tileSets, ref scroll[0], listOps, GUILayout.Width(150)) == 1)
				{
					ResetTransition();
					dragDropTarget = -2; dragDropSubTarget = -2;
					scroll[1] = Vector2.zero;

					autoSet_floorNavAreaNamesIdx = -1;
					autoSet_wallNavAreaNamesIdx = -1;
					if (tileSetIdx >= 0)
					{
						for (int i = 0; i < GC_NavAreas.Length; i++)
						{
							int idx = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[i].text);
							if (asset.tileSets[tileSetIdx].floorNavArea == idx) autoSet_floorNavAreaNamesIdx = i;
							if (asset.tileSets[tileSetIdx].wallNavArea == idx) autoSet_wallNavAreaNamesIdx = i;
						}
					}
				}

				Rect r = EditorGUILayout.BeginVertical();
				{
					if (tileSetIdx >= 0)
					{
						if (asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Narrow) DrawNarrowTileSetSettings();
						else if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Simple) DrawSimpleTileSetSettings(0);
						else if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto) DrawAutoTileSetSettings();
					}
					else
					{
						EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
						GUILayout.FlexibleSpace();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				plyEdUtil.SetDirty(asset);
			}
		}

		private int OnListAction(plyEdGUI.ListOps.ListAction act)
		{
			if (act == plyEdGUI.ListOps.ListAction.DoAdd)
			{
				string nm = plyEdUtil.GetUniqueString<TileEdTileSet>(asset.tileSets, "Tile Set ");
				TileEd_NewTileSetWindow.Show_NewTileSetWindow(nm, DoAddTileSet);
				return -2;
			}

			else if (act == plyEdGUI.ListOps.ListAction.DoRemoveSelected)
			{
				if (EditorUtility.DisplayDialog("Delete Tile Set", "This action can't be undone. Are you sure?", "Yes", "Cancel"))
				{
					asset.tileSets.RemoveAt(tileSetIdx);
					
					plyEdUtil.SetDirty(asset);
					return -1;
				}
				else return -2;
			}

			plyEdUtil.SetDirty(asset);
			return -2;
		}

		private void DoAddTileSet(TileEd_NewTileSetWindow wiz)
		{
			string nm = wiz.setName;
			TileEdTileSet.Type tp = wiz.setType;
			TileEdTileSet.AutoType sub = wiz.subType;
			TileEdTileSet.WallPivot ws = wiz.wallSystem;

			wiz.Close();

			if (!string.IsNullOrEmpty(nm))
			{
				ResetTransition();

				TileEdTileSet set = new TileEdTileSet();
				set.ident = asset.GenerateTileSetIdent();
				set.name = nm;
				set.type = tp;
				set.autoType = sub;
				set.wallSystem = ws;

				if (set.type == TileEdTileSet.Type.Auto)
				{   // fill tile list with blank tiles
					if (set.wallSystem == TileEdTileSet.WallPivot.Narrow)
					{
						set.autoType = TileEdTileSet.AutoType.Rotating;
						for (int i = 0; i < 15; i++) set.tiles.Add(new TileEdTile() { ident = asset.GenerateTileIdent(), targetTransSet = set.ident, tileIdx = i, isRotating = 1 });
					}
					else if (set.autoType == TileEdTileSet.AutoType.Rotating)
					{
						for (int i = 0; i < 5; i++) set.tiles.Add(new TileEdTile() { ident = asset.GenerateTileIdent(), targetTransSet = set.ident, tileIdx = i, isRotating = 1 });
					}
					else if (set.autoType == TileEdTileSet.AutoType.Directional)
					{
						for (int i = 0; i < 17; i++) set.tiles.Add(new TileEdTile() { ident = asset.GenerateTileIdent(), targetTransSet = set.ident, tileIdx = i, isRotating = 0 });
					}
				}

				asset.tileSets.Add(set);
				tileSetIdx = asset.tileSets.Count - 1;
				asset.GC_TileSets = null; // reset so that the list gets refreshed
				plyEdUtil.SetDirty(asset);
				settingsEd.Repaint();
			}
		}

		private void DoRenameTileSet(plyTextInputWiz wiz)
		{
			string nm = wiz.text;
			wiz.Close();

			if (tileSetIdx >= 0 && !string.IsNullOrEmpty(nm))
			{
				asset.tileSets[tileSetIdx].name = nm;
				asset.GC_TileSets = null; // reset so that the list gets refreshed
				plyEdUtil.SetDirty(asset);
				settingsEd.Repaint();
			}
		}

		// Simple -----------------------------------------------------------------------------------------------------

		private void DrawSimpleTileSetSettings(int extraIdxOffs)
		{
			Event ev = Event.current;

			if (extraIdxOffs == 0)
			{
				EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
				{
					GUILayout.Label(GC_SimpleTilesHeading);
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				GUILayout.Space(5);

				// allocate preview space
				int count = 1;
				for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++) count += asset.tileSets[tileSetIdx].tiles[i].prefab.Length;
				TileEdGlobal.PreviewAlloc(count, 0);
			}
			else
			{
				GUILayout.Space(20);
			}

			Rect dropRect = GUILayoutUtility.GetRect(10, 85, TileEdGUI.Styles.DragDropBox, GUILayout.ExpandWidth(true));
			GUI.Box(dropRect, extraIdxOffs == 0 ? GC_DropArea : GC_DropAreaExtra, TileEdGUI.Styles.DragDropBox);

			Rect br = new Rect(dropRect.x + 3, dropRect.y + 3, 75, 16);
			def_setNavArea = EditorGUI.ToggleLeft(br, GC_SetNavArea, def_setNavArea);
			if (def_setNavArea) { br.x += 75; br.width = 100; def_navAreaNamesIdx = EditorGUI.Popup(br, def_navAreaNamesIdx, GC_NavAreas); br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setStaticFlags = EditorGUI.ToggleLeft(br, GC_SetStatic, def_setStaticFlags);
			if (def_setStaticFlags) { br.x += 75; br.width = 100; def_staticFlags = (StaticEditorFlags)EditorGUI.EnumFlagsField(br, def_staticFlags);br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setLayer = EditorGUI.ToggleLeft(br, GC_SetLayer, def_setLayer);
			if (def_setLayer) { br.x += 75; br.width = 100; def_layer = EditorGUI.LayerField(br, def_layer);br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setSort = EditorGUI.ToggleLeft(br, GC_SetSort, def_setSort);
			if (def_setSort)
			{
				br.x += 75; br.width = 80;
				TileEd.GetSortingLayerNames(ref GC_SortNames);
				def_sortLayerNameIdx = EditorGUI.Popup(br, def_sortLayerNameIdx, GC_SortNames);

				br.x += 80; br.width = 20;
				def_sortOrder = EditorGUI.IntField(br, def_sortOrder);
				br.x -= 155; br.width = 75;
			}
			br.y += br.height;
			def_setTag = EditorGUI.ToggleLeft(br, GC_SetTag, def_setTag);
			if (def_setTag) { br.x += 75; br.width = 100; def_tag = EditorGUI.TagField(br, def_tag); br.x -= 75; br.width = 75; }

			br = new Rect(dropRect.xMax - 55, dropRect.y + 17, 50, 50);
			if (GUI.Button(br, TileEdGUI.GC_AddButtonIcon, TileEdGUI.Styles.AddButtonIcon))
			{
				EditorGUIUtility.ShowObjectPicker<GameObject>(null, false, null, 0);
			}

			if (ev.type == EventType.DragUpdated && dropRect.Contains(ev.mousePosition))
			{
				dragDropTarget = -1; dragDropSubTarget = -2;
				DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
				ev.Use();
			}

			if (asset.tileSets[tileSetIdx].tiles.Count > extraIdxOffs)
			{
				if (extraIdxOffs == 0) scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);

				int settingsMaxX = (int)((Screen.width - 155) / 138);
				if (settingsMaxX < 1) settingsMaxX = 1;
				int cntX = 0;
				int rem = -1;
				bool open = false;
				for (int i = extraIdxOffs; i < asset.tileSets[tileSetIdx].tiles.Count; i++)
				{
					if (asset.tileSets[tileSetIdx].tiles[i].transitionIdx >= 0) continue;
					if (cntX == 0) { open = true; EditorGUILayout.BeginHorizontal(); }

					if (DrawTileSettings(ev, i, GUIContent.none, null, asset.tileSets[tileSetIdx].tiles[i], true))
					{
						rem = i;
					}

					cntX++;
					if (cntX == settingsMaxX) { cntX = 0; GUILayout.FlexibleSpace(); EditorGUILayout.EndHorizontal(); open = false; }
				}

				if (open) { GUILayout.FlexibleSpace(); EditorGUILayout.EndHorizontal(); }

				if (rem >= 0)
				{
					asset.tileSets[tileSetIdx].tiles.RemoveAt(rem);
					plyEdUtil.SetDirty(asset);
				}

				if (extraIdxOffs == 0)
				{
					EditorGUILayout.Space();
					EditorGUILayout.EndScrollView();
				}
			}

			if (ev.type == EventType.ExecuteCommand && ev.commandName == "ObjectSelectorClosed" && 
				EditorGUIUtility.GetObjectPickerControlID() == 0)
			{	// add tile via the blue [+] button on drop area
				Object obj = EditorGUIUtility.GetObjectPickerObject();
				if (obj != null) AddSimpleTilesToTileSet(new Object[] { obj });
				ev.Use();
			}

			if (ev.type == EventType.DragExited)
			{
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.DragPerform && dragDropTarget >= -1)
			{
				DragAndDrop.AcceptDrag();
				ev.Use();
				if (DragAndDrop.objectReferences.Length > 0)
				{
					if (dragDropTarget == -1) AddSimpleTilesToTileSet(DragAndDrop.objectReferences);
					else if (dragDropTarget >= 0 && dragDropTarget < asset.tileSets[tileSetIdx].tiles.Count)
					{
						GameObject go = DragAndDrop.objectReferences[0] as GameObject;
						if (go == null)
						{
							Debug.LogWarning("The object could not be used since it is not a prefab: " + DragAndDrop.objectReferences[0].name, DragAndDrop.objectReferences[0]);
						}
						else
						{
							asset.tileSets[tileSetIdx].tiles[dragDropTarget].prefab[0] = go;
							plyEdUtil.SetDirty(asset);
						}
					}
				}
				dragDropTarget = -2; dragDropSubTarget = -2;
			}
		}

		private void AddSimpleTilesToTileSet(Object[] objs)
		{
			for (int i = 0; i < objs.Length; i++)
			{
				GameObject go = objs[i] as GameObject;
				if (go == null)
				{
					Debug.LogWarning("The object could not be added since it is not a prefab: " + objs[i].name, objs[i]);
					continue;
				}

				if (false == asset.tileSets[tileSetIdx].ContainsPrefab(0, go))
				{
					TileEdTile t = new TileEdTile();
					t.ident = asset.GenerateTileIdent();
					t.prefab[0] = go;
					t.targetTransSet = asset.tileSets[tileSetIdx].ident;
					t.tileIdx = -1; // simple tile do not have IDX
					t.isRotating = asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating ? 1 : 0;

					t.setTag = def_setTag;
					t.tag = def_tag;
					t.setLayer = def_setLayer;
					t.layer = def_layer;
					t.setStaticFlags = def_setStaticFlags;
					t.staticFlags = (int)def_staticFlags;
					t.setNavArea = def_setNavArea;
					t.navArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[def_navAreaNamesIdx].text);
					t.setSort = def_setSort;
					t.sortOrder = def_sortOrder;
					t.sortLayerId = TileEd.GetSortingLayerUniqueID(def_sortLayerNameIdx);

					asset.tileSets[tileSetIdx].tiles.Add(t);
				}
			}

			plyEdUtil.SetDirty(asset);
		}

		// Auto --------------------------------------------------------------------------------------------------------

		private void DrawAutoTileSetSettings()
		{
			Event ev = Event.current;

			// toolbar
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				GUILayout.Label(GC_AutoTilesHeading[asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating ? 0 : 1]);
				GUILayout.Space(20);

				if (plyEdGUI.ToggleButton(edTransitions == false, GC_TileSetDef, plyEdGUI.Styles.ToolbarButton))
				{
					edTransitions = false; scroll[1] = Vector2.zero;
				}

				if (plyEdGUI.ToggleButton(edTransitions == true, GC_TileSetTransitions, plyEdGUI.Styles.ToolbarButton)) 
				{ 
					transition = null;
					scroll[1] = Vector2.zero;

					edTransitions = true;
					selTransitionIdx = -1;
					transitionSets = new TileEdTileSet[0];
					GC_TransitionTileSets = new GUIContent[0];
					for (int i = 0; i < asset.tileSets.Count; i++)
					{
						if (i != tileSetIdx && asset.tileSets[i].type == TileEdTileSet.Type.Auto)
						{
							ArrayUtility.Add(ref transitionSets, asset.tileSets[i]);
							ArrayUtility.Add(ref GC_TransitionTileSets, new GUIContent(asset.tileSets[i].name));
						}
					}

					// auto-select 1st transition if there is one
					if (asset.tileSets[tileSetIdx].transitions.Count > 0)
					{
						for (int i = 0; i < asset.tileSets[tileSetIdx].transitions.Count; i++)
						{
							for (int j = 0; j < transitionSets.Length; j++)
							{
								if (asset.tileSets[tileSetIdx].transitions[i].targetTileSetIdent == transitionSets[j].ident)
								{
									selTransitionIdx = j;
									transition = asset.tileSets[tileSetIdx].transitions[i];
									break;
								}
							}
						}
					}

				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(5);

			// allocate preview space
			int count = 1;
			for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++) count += asset.tileSets[tileSetIdx].tiles[i].prefab.Length;
			TileEdGlobal.PreviewAlloc(count, 0);

			if (edTransitions)
			{
				DrawAutoTileTransitionSettings(ev);
			}
			else
			{
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);

				// options
				EditorGUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.Width(300));
				{
					EditorGUILayout.BeginHorizontal();
					{
						showTileSettings = EditorGUILayout.Foldout(showTileSettings, GC_WallSystem);
						GUILayout.Label(asset.tileSets[tileSetIdx].wallSystem.ToString(), GUILayout.Width(204));
						//asset.tileSets[tileSetIdx].wallSystem = (TileEdTileSet.WallPivot)EditorGUILayout.EnumPopup(asset.tileSets[tileSetIdx].wallSystem, GUILayout.Width(204));
					}
					EditorGUILayout.EndHorizontal();

					if (showTileSettings)
					{
						EditorGUIUtility.labelWidth = 90;
						EditorGUILayout.BeginHorizontal();
						{
							GUILayout.Space(90);
							GUILayout.Label(GC_SetLabel[0], GUILayout.Width(100));
							GUILayout.Label(GC_SetLabel[1], GUILayout.Width(100));
						}
						EditorGUILayout.EndHorizontal(); 
						
						EditorGUILayout.BeginHorizontal();
						{
							asset.tileSets[tileSetIdx].setNavArea = EditorGUILayout.ToggleLeft(GC_SetNavArea, asset.tileSets[tileSetIdx].setNavArea, GUILayout.Width(86));
							if (asset.tileSets[tileSetIdx].setNavArea)
							{
								EditorGUI.BeginChangeCheck();
								autoSet_floorNavAreaNamesIdx = EditorGUILayout.Popup(autoSet_floorNavAreaNamesIdx, GC_NavAreas);
								if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].floorNavArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[autoSet_floorNavAreaNamesIdx].text);
								EditorGUI.BeginChangeCheck();
								autoSet_wallNavAreaNamesIdx = EditorGUILayout.Popup(autoSet_wallNavAreaNamesIdx, GC_NavAreas);
								if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].wallNavArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[autoSet_wallNavAreaNamesIdx].text);
							}
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setStaticFlags = EditorGUILayout.ToggleLeft(GC_SetStatic, asset.tileSets[tileSetIdx].setStaticFlags, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setStaticFlags)
						{
							asset.tileSets[tileSetIdx].floorStaticFlags = (int)(StaticEditorFlags)EditorGUILayout.EnumFlagsField((StaticEditorFlags)asset.tileSets[tileSetIdx].floorStaticFlags);
							asset.tileSets[tileSetIdx].wallStaticFlags = (int)(StaticEditorFlags)EditorGUILayout.EnumFlagsField((StaticEditorFlags)asset.tileSets[tileSetIdx].wallStaticFlags);
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setLayer = EditorGUILayout.ToggleLeft(GC_SetLayer, asset.tileSets[tileSetIdx].setLayer, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setLayer)
						{
							asset.tileSets[tileSetIdx].floorLayer = EditorGUILayout.LayerField(asset.tileSets[tileSetIdx].floorLayer);
							asset.tileSets[tileSetIdx].wallLayer = EditorGUILayout.LayerField(asset.tileSets[tileSetIdx].wallLayer);
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setSort= EditorGUILayout.ToggleLeft(GC_SetSort, asset.tileSets[tileSetIdx].setSort, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setSort)
						{
							TileEd.GetSortingLayerNames(ref GC_SortNames);
							int idx = TileEd.GetSortingLayerIdxFromUniqueId(asset.tileSets[tileSetIdx].floorSortLayeId);
							EditorGUI.BeginChangeCheck();
							idx = EditorGUILayout.Popup(idx, GC_SortNames);
							if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].floorSortLayeId = TileEd.GetSortingLayerUniqueID(idx);
							asset.tileSets[tileSetIdx].floorSortOrder = EditorGUILayout.IntField(asset.tileSets[tileSetIdx].floorSortOrder, GUILayout.Width(20));

							idx = TileEd.GetSortingLayerIdxFromUniqueId(asset.tileSets[tileSetIdx].wallSortLayeId);
							EditorGUI.BeginChangeCheck();
							idx = EditorGUILayout.Popup(idx, GC_SortNames);
							if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].wallSortLayeId = TileEd.GetSortingLayerUniqueID(idx);
							asset.tileSets[tileSetIdx].wallSortOrder = EditorGUILayout.IntField(asset.tileSets[tileSetIdx].wallSortOrder, GUILayout.Width(20));
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setTag = EditorGUILayout.ToggleLeft(GC_SetTag, asset.tileSets[tileSetIdx].setTag, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setTag)
						{
							asset.tileSets[tileSetIdx].floorTag = EditorGUILayout.TagField(asset.tileSets[tileSetIdx].floorTag);
							asset.tileSets[tileSetIdx].wallTag = EditorGUILayout.TagField(asset.tileSets[tileSetIdx].wallTag);
						}
						EditorGUILayout.EndHorizontal();
					}
					EditorGUIUtility.labelWidth = 0;
				}
				EditorGUILayout.EndVertical();
				GUILayout.Space(5);

				// tiles
				if (asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating)
				{
					EditorGUILayout.BeginHorizontal();
					for (int i = 0; i < 5; i++)
					{
						DrawTileSettings(ev, i, GC_AutoTileSet[i], TileEdGUI.AutoTileIcons[i][0], asset.tileSets[tileSetIdx].tiles[i], false);
					}
					GUILayout.Space(50);
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}

				else if (asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Directional)
				{
					int idx = 0;
					for (int i = 0; i < 5; i++)
					{
						EditorGUILayout.BeginHorizontal();
						{
							foldouts[i] = plyEdGUI.Foldout(foldouts[i], GC_AutoTileSet[i], GUILayout.Width(100));
							if (foldouts[i])
							{
								if (i > 0)
								{
									for (int j = 0; j < 4; j++)
									{
										DrawTileSettings(ev, idx, GC_TileNumber[j], TileEdGUI.AutoTileIcons[i][j], asset.tileSets[tileSetIdx].tiles[idx], false);
										idx++;
									}
								}
								else
								{
									DrawTileSettings(ev, idx, GC_AutoTileSet[0], TileEdGUI.AutoTileIcons[i][0], asset.tileSets[tileSetIdx].tiles[idx], false);
									idx++;
								}
							}
						}
						GUILayout.Space(50);
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
						GUILayout.Space(10);
					}
				}

				DrawSimpleTileSetSettings(asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating ? 5 : 17);

				GUILayout.Space(150);
				EditorGUILayout.EndScrollView();
			}
		}

		private void DrawAutoTileTransitionSettings(Event ev)
		{
			Rect r = EditorGUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.Width(250));
			{
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Label(asset.tileSets[tileSetIdx].name, GUILayout.Width(100));
					GUILayout.Space(55);

					EditorGUI.BeginChangeCheck();
					selTransitionIdx = EditorGUILayout.Popup(selTransitionIdx, GC_TransitionTileSets, GUILayout.Width(100));
					if (EditorGUI.EndChangeCheck())
					{	// check if transition exist and load it
						transition = null;
						for (int i = 0; i < asset.tileSets[tileSetIdx].transitions.Count; i++)
						{
							if (asset.tileSets[tileSetIdx].transitions[i].targetTileSetIdent == transitionSets[selTransitionIdx].ident)
							{
								transition = asset.tileSets[tileSetIdx].transitions[i];
								break;
							}
						}
					}
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Space(3);
					DrawPreview(ev, asset.tileSets[tileSetIdx].tiles[0].prefab[0], 100);
					GUILayout.Space(2);
					GUILayout.Label(TileEdGUI.TransitionIcon, GUILayout.Width(44));
					GUILayout.Space(2);
					DrawPreview(ev, selTransitionIdx >= 0 ? transitionSets[selTransitionIdx].tiles[0].prefab[0] : null, 100);
				}
				EditorGUILayout.EndHorizontal();
				GUILayout.Space(4);
			}
			EditorGUILayout.EndVertical();

			if (selTransitionIdx < 0) return;

			if (transition != null)
			{
				r.x = r.xMax + 5; r.y = r.yMax - 20; r.width = 120; r.height = 18;
				if (GUI.Button(r, GC_DeleteTransition))
				{
					// remove the tiles of tis transition
					for (int i = 0; i < transition.tileIdents.Count; i++)
					{
						TileEdTile t = asset.tileSets[tileSetIdx].FindTile(transition.tileIdents[i]);
						if (t != null) asset.tileSets[tileSetIdx].tiles.Remove(t);
					}

					asset.tileSets[tileSetIdx].transitions.Remove(transition);
					transition = null;
					plyEdUtil.SetDirty(asset);
				}
			}

			if (transition == null)
			{
				EditorGUILayout.Space();
				
				// create transition
				if (GUILayout.Button(GC_CreateTransition, GUILayout.Width(120)))
				{
					transition = new TileEdTransition();
					transition.targetTileSetIdent = transitionSets[selTransitionIdx].ident;
					asset.tileSets[tileSetIdx].transitions.Add(transition);

					transition.tileIdents = new List<int>();
					transition._tileCache = new List<TileEdTile>();

					int isRotating = 1;
					int max = 4;
					if (asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Directional)
					{ isRotating = 0; max = 16; }

					for (int i = 0; i < max; i++)
					{
						TileEdTile t = new TileEdTile() 
						{ 
							ident = asset.GenerateTileIdent(),
							transitionIdx = i,
							targetTransSet = transition.targetTileSetIdent,
							isRotating = isRotating
						};
						asset.tileSets[tileSetIdx].tiles.Add(t);
						transition.tileIdents.Add(t.ident);
						transition._tileCache.Add(t);
					}

					plyEdUtil.SetDirty(asset);
				}
				return;
			}

			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);

			if (transition._tileCache == null)
			{
				EditorGUILayout.BeginHorizontal();
				if (transition.LoadCache(asset.tileSets[tileSetIdx], asset)) 
				{
					plyEdUtil.SetDirty(asset);
				}
				GUILayout.Space(50);
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}

			if (asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating)
			{
				EditorGUILayout.BeginHorizontal();
				for (int i = 0; i < 4; i++)
				{
					DrawTileSettings(ev, i, GC_AutoTileTransition[i], TileEdGUI.AutoTileIcons[5 + i][0], transition._tileCache[i], false);
				}
				GUILayout.Space(50);
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
			else
			{
				int idx = 0;
				for (int i = 0; i < 4; i++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						foldouts[i + 5] = plyEdGUI.Foldout(foldouts[i + 5], GC_AutoTileTransition[i], GUILayout.Width(100));
						if (foldouts[i + 5])
						{
							for (int j = 0; j < 4; j++)
							{
								DrawTileSettings(ev, idx, GC_TileNumber[i], TileEdGUI.AutoTileIcons[i + 5][j], transition._tileCache[idx], false);
								idx++;
							}
						}
					}
					GUILayout.Space(50);
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
					GUILayout.Space(10);
				}
			}

			GUILayout.Space(50);
			EditorGUILayout.EndScrollView();

		}

		// Narrow ------------------------------------------------------------------------------------------------------

		private void DrawNarrowTileSetSettings()
		{
			Event ev = Event.current;

			// toolbar
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				GUILayout.Label(GC_AutoTilesHeading[2]);
				GUILayout.Space(20);
				plyEdGUI.ToggleButton(true, GC_TileSetDef, plyEdGUI.Styles.ToolbarButton);
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(5);

			// allocate preview space
			int idx = 0;
			int count = 1;
			for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++) count += asset.tileSets[tileSetIdx].tiles[i].prefab.Length;
			TileEdGlobal.PreviewAlloc(count, 0);

			if (edTransitions)
			{
				DrawAutoTileTransitionSettings(ev);
			}
			else
			{
				scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);

				// options
				EditorGUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.Width(300));
				{
					showTileSettings = EditorGUILayout.Foldout(showTileSettings, GC_WallSystem);
					if (showTileSettings)
					{
						EditorGUIUtility.labelWidth = 90;
						EditorGUILayout.BeginHorizontal();
						{
							GUILayout.Space(90);
							GUILayout.Label(GC_SetLabel[0], GUILayout.Width(100));
							GUILayout.Label(GC_SetLabel[1], GUILayout.Width(100));
						}
						EditorGUILayout.EndHorizontal();

						EditorGUILayout.BeginHorizontal();
						{
							asset.tileSets[tileSetIdx].setNavArea = EditorGUILayout.ToggleLeft(GC_SetNavArea, asset.tileSets[tileSetIdx].setNavArea, GUILayout.Width(86));
							if (asset.tileSets[tileSetIdx].setNavArea)
							{
								EditorGUI.BeginChangeCheck();
								autoSet_floorNavAreaNamesIdx = EditorGUILayout.Popup(autoSet_floorNavAreaNamesIdx, GC_NavAreas);
								if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].floorNavArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[autoSet_floorNavAreaNamesIdx].text);
								EditorGUI.BeginChangeCheck();
								autoSet_wallNavAreaNamesIdx = EditorGUILayout.Popup(autoSet_wallNavAreaNamesIdx, GC_NavAreas);
								if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].wallNavArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[autoSet_wallNavAreaNamesIdx].text);
							}
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setStaticFlags = EditorGUILayout.ToggleLeft(GC_SetStatic, asset.tileSets[tileSetIdx].setStaticFlags, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setStaticFlags)
						{
							asset.tileSets[tileSetIdx].floorStaticFlags = (int)(StaticEditorFlags)EditorGUILayout.EnumFlagsField((StaticEditorFlags)asset.tileSets[tileSetIdx].floorStaticFlags);
							asset.tileSets[tileSetIdx].wallStaticFlags = (int)(StaticEditorFlags)EditorGUILayout.EnumFlagsField((StaticEditorFlags)asset.tileSets[tileSetIdx].wallStaticFlags);
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setLayer = EditorGUILayout.ToggleLeft(GC_SetLayer, asset.tileSets[tileSetIdx].setLayer, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setLayer)
						{
							asset.tileSets[tileSetIdx].floorLayer = EditorGUILayout.LayerField(asset.tileSets[tileSetIdx].floorLayer);
							asset.tileSets[tileSetIdx].wallLayer = EditorGUILayout.LayerField(asset.tileSets[tileSetIdx].wallLayer);
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setSort = EditorGUILayout.ToggleLeft(GC_SetSort, asset.tileSets[tileSetIdx].setSort, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setSort)
						{
							TileEd.GetSortingLayerNames(ref GC_SortNames);
							idx = TileEd.GetSortingLayerIdxFromUniqueId(asset.tileSets[tileSetIdx].floorSortLayeId);
							EditorGUI.BeginChangeCheck();
							idx = EditorGUILayout.Popup(idx, GC_SortNames);
							if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].floorSortLayeId = TileEd.GetSortingLayerUniqueID(idx);
							asset.tileSets[tileSetIdx].floorSortOrder = EditorGUILayout.IntField(asset.tileSets[tileSetIdx].floorSortOrder, GUILayout.Width(20));

							idx = TileEd.GetSortingLayerIdxFromUniqueId(asset.tileSets[tileSetIdx].wallSortLayeId);
							EditorGUI.BeginChangeCheck();
							idx = EditorGUILayout.Popup(idx, GC_SortNames);
							if (EditorGUI.EndChangeCheck()) asset.tileSets[tileSetIdx].wallSortLayeId = TileEd.GetSortingLayerUniqueID(idx);
							asset.tileSets[tileSetIdx].wallSortOrder = EditorGUILayout.IntField(asset.tileSets[tileSetIdx].wallSortOrder, GUILayout.Width(20));
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.BeginHorizontal();
						asset.tileSets[tileSetIdx].setTag = EditorGUILayout.ToggleLeft(GC_SetTag, asset.tileSets[tileSetIdx].setTag, GUILayout.Width(86));
						if (asset.tileSets[tileSetIdx].setTag)
						{
							asset.tileSets[tileSetIdx].floorTag = EditorGUILayout.TagField(asset.tileSets[tileSetIdx].floorTag);
							asset.tileSets[tileSetIdx].wallTag = EditorGUILayout.TagField(asset.tileSets[tileSetIdx].wallTag);
						}
						EditorGUILayout.EndHorizontal();
					}
					EditorGUIUtility.labelWidth = 0;
				}
				EditorGUILayout.EndVertical();
				GUILayout.Space(5);

				// tiles
				idx = 0;
				for (int i = 0; i < 3; i++)
				{
					EditorGUILayout.BeginHorizontal();
					{
						for (int j = 0; j < 5; j++)
						{
							DrawTileSettings(ev, idx, GUIContent.none, TileEdGUI.NarrowTileIcons[idx], asset.tileSets[tileSetIdx].tiles[idx], false);
							idx++;
						}
					}
					GUILayout.Space(50);
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
					GUILayout.Space(10);
				}

				GUILayout.Space(150);
				EditorGUILayout.EndScrollView();
			}
		}

		// Helpers ----------------------------------------------------------------------------------------------------

		private bool DrawTileSettings(Event ev, int idx, GUIContent label, Texture2D icon, TileEdTile tile, bool simpleTile)
		{
			bool didRemoveFab0 = false;
			Rect r, br = new Rect(0, 0, 16, 16);
			EditorGUILayout.BeginVertical();
			{
				Rect rr = EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.Width(128));
				{
					if (icon != null)
					{
						EditorGUILayout.BeginHorizontal();
						{
							r = GUILayoutUtility.GetRect(32, 32, GUILayout.Width(32), GUILayout.Height(32));
							GUI.DrawTexture(r, icon);
							EditorGUILayout.BeginVertical();
#if DEBUG
							GUILayout.Label(tile.tileIdx + ": " + tile.ident, TileEdGUI.Styles.TileHeading);
#else
							GUILayout.Label(label, TileEdGUI.Styles.TileHeading);
#endif
							tile.prefab[0] = (GameObject)EditorGUILayout.ObjectField(tile.prefab[0], typeof(GameObject), false);
							EditorGUILayout.EndVertical();
						}
						EditorGUILayout.EndHorizontal();
					}
					else
					{
						tile.prefab[0] = (GameObject)EditorGUILayout.ObjectField(tile.prefab[0], typeof(GameObject), false);
					}

					r = GUILayoutUtility.GetRect(128, 130, GUILayout.Width(128), GUILayout.Height(130));
					r.y += 2; r.height = 128;

					if (ev.type == EventType.Repaint)
					{
						if (tile.prefab[0] != null)
						{
							Texture2D tex = tile.customThumb == null ? AssetPreview.GetAssetPreview(tile.prefab[0]) : tile.customThumb;
							if (tex == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
							else GUI.Box(r, tex, TileEdGUI.Styles.TilePreview);
						}
						else
						{
							GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TilePreview);
						}
					}

					br.x = r.xMax - 16; br.y = r.y;
					if (GUI.Button(br, GC_ClearTile, plyEdGUI.Styles.Button)) 
					{
						if (EditorUtility.DisplayDialog("Remove Tile", "Are you sure you want to remove this tile from the set? This action can't be undone.", "Yes", "Cancel"))
						{
							didRemoveFab0 = true;
							tile.prefab[0] = null;
							plyEdUtil.SetDirty(asset);
						}
					}

					br.x = br.x - 17;
					if (GUI.Button(br, GC_CustomThumb, plyEdGUI.Styles.Button))
					{
						tileWaitCustomThumb = tile;
						EditorGUIUtility.ShowObjectPicker<Texture2D>(tile.customThumb, false, null, 1);
					}

					//if (simpleTile)
					{
						br.x = br.x - 17;
						if (GUI.Button(br, GC_OpenTileSettingsPopup, plyEdGUI.Styles.Button))
						{
							tileSettingsPopup.asset = asset;
							tileSettingsPopup.tile = tile;
							PopupWindow.Show(br, tileSettingsPopup);
						}
					}

					if (tile.prefab[0] != null && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
					{
						EditorGUIUtility.PingObject(tile.prefab[0]);
						ev.Use();
					}

					if (ev.type == EventType.DragUpdated && r.Contains(ev.mousePosition))
					{
						dragDropTarget = idx; dragDropSubTarget = -2;
						DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
						ev.Use();
					}

					// draw the "random" tiles, if any
					GUILayoutUtility.GetRect(1, 3, GUILayout.Width(1), GUILayout.Height(3));
					if (tile.prefab.Length > 1)
					{
						int rem = -1;
						for (int i = 1; i < tile.prefab.Length; i++)
						{
							tile.prefab[i] = (GameObject)EditorGUILayout.ObjectField(tile.prefab[i], typeof(GameObject), false, GUILayout.Width(100));
							r = GUILayoutUtility.GetRect(100, 100, GUILayout.Width(100), GUILayout.Height(100));
							r.x = rr.x + 3;
							if (ev.type == EventType.Repaint)
							{
								if (tile.prefab[i] != null)
								{
									Texture2D tex = AssetPreview.GetAssetPreview(tile.prefab[i]);
									if (tex == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
									else GUI.Box(r, tex, TileEdGUI.Styles.TilePreview);
								}
								else
								{
									GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TilePreview);
								}
							}
							GUILayout.Space(3);

							br.x = r.xMax - 16; br.y = r.y;
							if (GUI.Button(br, GC_ClearTile, plyEdGUI.Styles.Button)) rem = i;

							if (tile.prefab[i] != null && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
							{
								EditorGUIUtility.PingObject(tile.prefab[i]);
								ev.Use();
							}

							if (ev.type == EventType.DragUpdated && r.Contains(ev.mousePosition))
							{
								dragDropTarget = idx; dragDropSubTarget = i;
								DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
								ev.Use();
							}
						}

						if (rem >= 1)
						{
							ArrayUtility.RemoveAt(ref tile.prefab, rem);
							plyEdUtil.SetDirty(asset);
						}
					}

					if (GUILayout.Button(GC_AddRandomTile, plyEdGUI.Styles.MiniButton, GUILayout.Width(25)))
					{
						ArrayUtility.Add(ref tile.prefab, null);
						plyEdUtil.SetDirty(asset);
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndVertical();

			if (ev.type == EventType.DragExited)
			{
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.DragPerform && dragDropTarget == idx)
			{
				DragAndDrop.AcceptDrag();
				ev.Use();
				if (DragAndDrop.objectReferences.Length > 0)
				{
					GameObject go = DragAndDrop.objectReferences[0] as GameObject;
					if (go == null)
					{
						Debug.LogWarning("The object could not be used since it is not a prefab: " + DragAndDrop.objectReferences[0].name, DragAndDrop.objectReferences[0]);
					}
					else
					{
						if (dragDropSubTarget >= 1) tile.prefab[dragDropSubTarget] = go;
						else tile.prefab[0] = go;
						plyEdUtil.SetDirty(asset);
					}
				}
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.ExecuteCommand && ev.commandName == "ObjectSelectorClosed" && 
				EditorGUIUtility.GetObjectPickerControlID() == 1)
			{
				if (tileWaitCustomThumb != null)
				{
					tileWaitCustomThumb.customThumb = EditorGUIUtility.GetObjectPickerObject() as Texture2D;
					plyEdUtil.SetDirty(asset);
				}

				tileWaitCustomThumb = null;
				ev.Use();
			}

			return didRemoveFab0;
		}

		private void ResetTransition()
		{
			transitionSets = null;
			GC_TransitionTileSets = null;
			selTransitionIdx = -1;
			transition = null;
			edTransitions = false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region palette

		public override string PaletteName()
		{
			return "Tiles";
		}

		public override int PaletteOrder()
		{
			return 1;
		}

		public override void OnPalleteFocus()
		{
			if (!LoadAsset()) return;

			showAutoTilePieces = EditorPrefs.GetInt("TileEd.showAutoTilePieces", showAutoTilePieces);
			autoTileDepthAboveBelow[0] = EditorPrefs.GetInt("TileEd.autoTileDepthAboveBelow.0", autoTileDepthAboveBelow[0]);
			autoTileDepthAboveBelow[1] = EditorPrefs.GetInt("TileEd.autoTileDepthAboveBelow.1", autoTileDepthAboveBelow[1]);
			// just in case it is less than 1 from a previous version
			if (autoTileDepthAboveBelow[0] < 1) autoTileDepthAboveBelow[0] = 1;
			if (autoTileDepthAboveBelow[1] < 1) autoTileDepthAboveBelow[1] = 1;

			ClearSelection();
			ClearPasteMode();
			OnMapChanged();

			if (tileSetIdx >= 0 && tileSetIdx < asset.tileSets.Count)
			{
				if (currTileIdx >= 0 && currTileIdx < asset.tileSets[tileSetIdx].tiles.Count)
				{
					TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
				}
				else
				{
					scroll[2] = Vector2.zero;
					if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
					{
						currTileIdx = 0; // auto select 1st tile
						currTileIsSimple = false;
						TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
					}
					else
					{
						currTileIdx = -1;
						currTileIsSimple = true;
					}
				}
			}
			else
			{
				tileSetIdx = -1;
				currTileIdx = -1;
				currTileIsSimple = true;
				scroll[2] = Vector2.zero;
			}
		}

		public override void OnPalleteLooseFocus()
		{
			ClearSelection();
			ClearPasteMode();
			parentTr = null;
			TileEd.grid.UpdatePreviewObject(null, 0f);
		}

		public override void OnPaletteGUI()
		{
			if (asset.tileSets.Count == 0) return;

			if (tileSetIdx < 0)
			{
				tileSetIdx = 0;
				if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
				{
					currTileIdx = 0; // auto select 1st tile
					currTileIsSimple = false;
					TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
				}
			}

			if (!TileEdGlobal.paletteDocked) GUILayout.Space(5);

			int prev = tileSetIdx;
			if (TileEdGlobal.paletteLayout == 0 || !TileEdGlobal.paletteDocked)
			{
				EditorGUILayout.BeginHorizontal();
				{
					tileSetIdx = EditorGUILayout.Popup(tileSetIdx, asset.GC_TileSets);
					for (int i = 0; i < asset.tileSets.Count; i++)
					{
						if (GUILayout.Toggle(tileSetIdx == i, asset.tileSets[i].name, TileEdGUI.Styles.PaletteTab))
						{
							tileSetIdx = i;
						}
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
			}
			else
			{
				tileSetIdx = EditorGUILayout.Popup(tileSetIdx, asset.GC_TileSets);
			}

			if (prev != tileSetIdx)
			{
				ResetTransition();
				ClearPasteMode(); // just in case in paste mode
				ClearSelection(); // in case selection mode was on

				scroll[2] = Vector2.zero;

				// auto-select 1st tile if not simple tiles
				if (tileSetIdx >= 0 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto && asset.tileSets[tileSetIdx].tiles[0].prefab != null)
				{
					currTileIdx = 0;
					currTileIsSimple = false;
					TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
				}
				else
				{
					currTileIdx = -1;
					currTileIsSimple = true;
					TileEd.grid.UpdatePreviewObject(null, 0f);
				}

				TileEd_PalettePanel.DoRepaint();
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}

			Event ev = Event.current;
			HandleGridEvents(ev);
			if (ev.type == EventType.Repaint)
			{
				hasLoadingPalettePreviews = false;
			}

			Rect mainRect = EditorGUILayout.BeginVertical(TileEdGlobal.paletteLayout == 0 || !TileEdGlobal.paletteDocked ? TileEdGUI.Styles.BoxTopBorder : TileEdGUI.Styles.BoxRightBorder, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			if (asset.tileSets[tileSetIdx].tiles.Count > 0)
			{
				TileEdGlobal.PreviewAlloc(asset.tileSets[tileSetIdx].tiles.Count + 1, 0);

				mainRect.y += 1;
				int sz = (TileEdGlobal.palettePreviewSize + 2);
				int maxW = (int)mainRect.width - 5;
				int maxX = maxW / sz;
				if (maxX < 1) maxX = 1;

				Rect r = new Rect(0, 0, 5 + (sz * maxX), (asset.tileSets[tileSetIdx].tiles.Count / maxX) * sz + sz + 10);

				if (ev.type == EventType.ScrollWheel && mainRect.Contains(ev.mousePosition))
				{
					scroll[2].y += (ev.delta.y > 0 ? sz : -sz);
					ev.Use();
				}

				Rect u_R = new Rect(mainRect.xMax - 20, mainRect.yMax - 40, 20, 18);
				if (!TileEdGlobal.paletteDocked) { u_R.y = 40; u_R.x -= 2; }
				Rect d_R = u_R; d_R.y += 18;
				Rect s_R = u_R; s_R.y -= 20;

				if (ev.type == EventType.MouseDown && ev.button == 0)
				{
					if (u_R.Contains(ev.mousePosition))
					{
						scroll[2].y -= sz;
						ev.Use();
					}
					else if (d_R.Contains(ev.mousePosition))
					{
						scroll[2].y += sz;
						ev.Use();
					}
					else if (tileSetIdx >= 0 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto && s_R.Contains(ev.mousePosition))
					{   // toggle auto-tile pieces show/hide
						showAutoTilePieces = showAutoTilePieces == 0 ? 1 : 0;
						EditorPrefs.SetInt("TileEd.showAutoTilePieces", showAutoTilePieces);
						TileEd_PalettePanel.DoRepaint();
					}
				}
				

				// draw tiles
				scroll[2] = GUI.BeginScrollView(mainRect, scroll[2], r, false, false, GUIStyle.none, GUIStyle.none);
				{
					if (currTileIdx >= asset.tileSets[tileSetIdx].tiles.Count)
					{
						currTileIdx = -1;
						currTileIsSimple = true;
						TileEd.grid.UpdatePreviewObject(null, 0f);
					}

					int rem = -1;
					Rect starR = new Rect(0, 0, 20, 20);
					r = new Rect(5, 2, TileEdGlobal.palettePreviewSize, TileEdGlobal.palettePreviewSize);

					for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++)
					{
						if (asset.tileSets[tileSetIdx].tiles[i] == null) continue;

						// skip empty tiles, except for the special for auto-tiles
						if (asset.tileSets[tileSetIdx].tiles[i].prefab[0] == null && (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Simple || i != 0))
						{
							if (currTileIdx == i)
							{
								currTileIdx = -1;
								currTileIsSimple = true;
								TileEd.grid.UpdatePreviewObject(null, 0f);
								TileEd_PalettePanel.DoRepaint();
							}
							continue;
						}

						if (i == 0 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
						{
							if (DrawTileOnPalette(currTileIdx == i && !currTileIsSimple, ev, asset.tileSets[tileSetIdx].tiles[i], r, starR, asset.tileSets[tileSetIdx].type))
							{
								currTileIdx = i;
								currTileIsSimple = false;
								TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
								TileEd_PalettePanel.DoRepaint();
								plyEdUtil.RepaintInspector(typeof(TileEd));
							}

							// give a second option of the tile but as a simple tile (but only if auto-tile pieces should be shown)
							if (asset.tileSets[tileSetIdx].tiles[i].prefab[0] != null && showAutoTilePieces == 0)
							{
								r.x += sz;
								if (r.xMax > maxW) { r.x = 5; r.y += sz; }

								if (DrawTileOnPalette(currTileIdx == i && currTileIsSimple, ev, asset.tileSets[tileSetIdx].tiles[i], r, starR, 0))
								{
									currTileIdx = i;
									currTileIsSimple = true;
									TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
									TileEd_PalettePanel.DoRepaint();
									plyEdUtil.RepaintInspector(typeof(TileEd));
								}
							}
							
						}
						else
						{
							if (showAutoTilePieces == 1 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
							{   // 1 = do not show the auto-tile pieces
								// that would be the 1st 5 tiles
								if (i < 5) continue;
							}

							if (DrawTileOnPalette(currTileIdx == i, ev, asset.tileSets[tileSetIdx].tiles[i], r, starR, TileEdTileSet.Type.Simple))
							{
								currTileIdx = i;
								currTileIsSimple = true;
								TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
								TileEd_PalettePanel.DoRepaint();
								plyEdUtil.RepaintInspector(typeof(TileEd));
							}

						}

						r.x += sz;
						if (r.xMax > maxW) { r.x = 5; r.y += sz; }
					}

					if (rem >= 0)
					{
						asset.tileSets[tileSetIdx].tiles.RemoveAt(rem);
						plyEdUtil.SetDirty(asset);
					}
				}
				GUI.EndScrollView();

				if (ev.type == EventType.Repaint)
				{

					if (tileSetIdx >= 0 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
					{	// draw the auto-tile piece hide/show button
						plyEdGUI.Styles.Button.Draw(s_R, GC_ShowAutoPieces[showAutoTilePieces], false, false, false, false);
					}

					plyEdGUI.Styles.Button.Draw(u_R, GC_Up, false, false, false, false);
					plyEdGUI.Styles.Button.Draw(d_R, GC_Down, false, false, false, false);
				}
			}
		}

		private bool DrawTileOnPalette(bool selected, Event ev, TileEdTile tile, Rect r, Rect starR, TileEdTileSet.Type marker)
		{
			if (ev.type == EventType.Repaint)
			{
				if (tile.prefab != null && tile.prefab.Length > 0 && tile.prefab[0] != null)
				{
					Texture2D tex = tile.customThumb == null ? AssetPreview.GetAssetPreview(tile.prefab[0]) : tile.customThumb;
					if (tex == null)
					{
						hasLoadingPalettePreviews = true;
						GUI.Box(r, GC_Wait, TileEdGUI.Styles.TileBox);
					}
					else GUI.Box(r, tex, TileEdGUI.Styles.TileBox);
				}
				else GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TileBox);

				if (selected) TileEdGUI.Styles.TileSelected.Draw(r, false, false, false, false);

				if (marker == TileEdTileSet.Type.Auto)
				{
					starR.x = r.x + 2; starR.y = r.y + 2;
					TileEdGUI.Styles.SpecialTileLabel.Draw(starR, GC_AutoTileIcon, false, false, false, false);
				}
			}

			if (ev.button == 0 && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
			{
				ClearPasteMode(); // just in case in paste mode
				ClearSelection(); // in case selection mode was on
				ev.Use();
				return true;
			}

			return false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region inspector

		public override void OnInspector(Editor inspectorEd)
		{
			HandleGridEvents(Event.current); // Events

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				tileRotation = plyEdGUI.IntStepField(GC_Rotation, tileRotation, 90, plyEdGUI.EdFieldState.Readonly, 0, 270, true);
				if (EditorGUI.EndChangeCheck()) TileEd.grid.UpdatePreviewObjectRotation(tileRotation);
				EditorGUIUtility.labelWidth = 0;

				GUILayout.Space(2);
				if (plyEdGUI.ToggleButton(canRandomRotate, canRandomRotate ? GC_RandomRotOn : GC_RandomRotOff, plyEdGUI.Styles.ToolbarButton))
				{
					canRandomRotate = !canRandomRotate;
					EditorPrefs.SetBool("TileEd.Tiles.canRandomRotate", canRandomRotate);
				}

				GUI.enabled = !currTileIsSimple; 
				if (plyEdGUI.ToggleButton(canSculpt, canSculpt && !currTileIsSimple ? GC_SculptOn : GC_SculptOff, plyEdGUI.Styles.ToolbarButtonNoHLight))
				{
					canSculpt = !canSculpt;
					EditorPrefs.SetBool("TileEd.Tiles.canSculpt", canSculpt);
				}
				GUI.enabled = true;

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				GUILayout.Label(GC_Fab, plyEdGUI.Styles.Label, GUILayout.Width(41));

				if (plyEdGUI.ToggleButton(canRandomFab, canRandomFab ? GC_RandomFabOn : GC_RandomFabOff, plyEdGUI.Styles.ToolbarButton))
				{
					canRandomFab = !canRandomFab;
					EditorPrefs.SetBool("TileEd.Tiles.canRandomFab", canRandomFab);
				}
				if (canRandomFab)
				{
					if (plyEdGUI.ToggleButton(canRandomFabAll, canRandomFabAll ? GC_RandomFabAllOn : GC_RandomFabAllOff, plyEdGUI.Styles.ToolbarButton))
					{
						canRandomFabAll = !canRandomFabAll;
						EditorPrefs.SetBool("TileEd.Tiles.canRandomFabAll", canRandomFabAll);
					}
				}

				// terrain auto-tiles allow setting depth to erase tiles above/below
				if (!currTileIsSimple && tileSetIdx >= 0 && asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto && asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Terrain)
				{
					GUILayout.Space(5);
					GUILayout.Label(GC_AutoErase, plyEdGUI.Styles.ToolbarLabel);
					EditorGUI.BeginChangeCheck();
					autoTileDepthAboveBelow[0] = plyEdGUI.IntStepField(null, autoTileDepthAboveBelow[0], 1, plyEdGUI.EdFieldState.Normal, 1, 10, true, 18);
					if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.autoTileDepthAboveBelow.0", autoTileDepthAboveBelow[0]);
					EditorGUI.BeginChangeCheck();
					autoTileDepthAboveBelow[1] = plyEdGUI.IntStepField(null, autoTileDepthAboveBelow[1], 1, plyEdGUI.EdFieldState.Normal, 1, 10, true, 18);
					if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.autoTileDepthAboveBelow.1", autoTileDepthAboveBelow[1]);
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				if (GUILayout.Button(GC_EraseAll, plyEdGUI.Styles.ToolbarButton))
				{
					if (EditorUtility.DisplayDialog("TileEd", "Remove all Tiles from active Tile Layer. This action can't be undone. Are you sure?", "Yes", "Cancel"))
					{
						ClearSelection();
						EraseAllTilesFromActiveGroup();
					}
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			// Selection (copy/cut/remove)
			if (selection.Count > 0)
			{
				EditorGUILayout.Space();
				GUILayout.Label(GC_SelectionHead, plyEdGUI.Styles.LargeLabel);
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(GC_Copy, plyEdGUI.Styles.ButtonLeft)) CopySelection(true);
					if (GUILayout.Button(GC_Cut, plyEdGUI.Styles.ButtonMid)) CutSelection();
					if (GUILayout.Button(GC_Erase, plyEdGUI.Styles.ButtonRight)) DeleteSelection();
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();
			}

			// Copy Buffer
			if (copyBuffer.tiles.Count > 0)
			{
				EditorGUILayout.Space();
				GUILayout.Label(GC_CopyBufferHead, plyEdGUI.Styles.LargeLabel);

				if (copyBuffer.texture == null)
				{
					copyBuffer.texture = AssetPreview.GetAssetPreview(copyBuffer.prefab);
				}

				if (copyBuffer.texture != null)
				{
					GC_CopyBuffer.text = null;
					GC_CopyBuffer.image = copyBuffer.texture;
				}
				else
				{
					GC_CopyBuffer.text = Ico._wait;
					GC_CopyBuffer.image = null;
				}

				if (GUILayout.Button(GC_CopyBuffer, TileEdGUI.Styles.TilePreview, GUILayout.Width(100), GUILayout.Height(100)))
				{
					EnterPasteMode();
				}

				if (GUILayout.Button(GC_CreateTemplate, plyEdGUI.Styles.MiniButton, GUILayout.Width(100)))
				{
					CreateNewTemplate();
				}
			}

			// Templates
			TemplatesInspector();
		}

		public override void Update(Editor inspectorEd)
		{
			if (copyBuffer.tiles.Count > 0 && AssetPreview.IsLoadingAssetPreviews())
			{
				inspectorEd.Repaint();
			}
		}

		//	// caching causes problems with undo system with wrong GameObjects being deleted 
		//	// sometimes when working with tiles restored by undo - disable this feature

		//public override void DoCacheMap()
		//{
		//	buildingCache = true;
		//	cacheBuilder?.Stop();
		//	cacheBuilder = plyEdCoroutine.Start(BuildCache(), true);
		//}

		//public override void DoCacheLoopUpdate()
		//{
		//	cacheBuilder?.DoUpdate();
		//}

		//private IEnumerator BuildCache()
		//{

		//	buildingCache = false;
		//	yield break;

		//	//Transform rootTr = TileEd.Instance.mapTr.Find(ROOT_NAME);
		//	//if (rootTr == null)
		//	//{
		//	//	buildingCache = false;
		//	//	yield break;
		//	//}
			
		//	//yield return null;
		//	//yield return null;

		//	//// cache the references to the tile objects in scene
		//	//int count = 0;
		//	//int groupsCount = rootTr.childCount;
		//	//for (int gidx = 0; gidx < groupsCount; gidx++)
		//	//{
		//	//	Transform groupTr = rootTr.GetChild(gidx);
		//	//	int groupId = -1;
		//	//	if (!int.TryParse(groupTr.name, out groupId)) continue;
					
		//	//	TileEdMapGroup group = TileEd.Instance.map.GetGroup(groupId);
		//	//	if (group == null) continue;

		//	//	int tilesCount = groupTr.childCount;
		//	//	for (int tidx = 0; tidx < tilesCount; tidx++)
		//	//	{
		//	//		Transform tr = groupTr.GetChild(tidx);

		//	//		IntVector3 pos;
		//	//		if (string.IsNullOrEmpty(tr.name) || tr.name.Length < 7) continue;
		//	//		string[] vals = tr.name.Substring(1, tr.name.Length - 2).Split('x');
		//	//		if (vals.Length == 3)
		//	//		{
		//	//			int[] v = new int[3];
		//	//			if (!int.TryParse(vals[0], out v[0])) continue;
		//	//			if (!int.TryParse(vals[1], out v[1])) continue;
		//	//			if (!int.TryParse(vals[2], out v[2])) continue;
		//	//			pos = new IntVector3(v[0], v[1], v[2]);
		//	//		}
		//	//		else continue;

		//	//		TileEdMapTile tile = group.GetTile(TOOL_IDENT, pos);
		//	//		if (tile != null)
		//	//		{
		//	//			tile.cachedTileObject = tr.gameObject;
		//	//		}

		//	//		count++; if (count > 5000) { count = 0; yield return null; }
		//	//	}
		//	//}

		//	//buildingCache = false;
		//}

		public override void OnMapChanged()
		{
			OnGroupChanged();
		}

		public override void OnGroupChanged()
		{
			ClearSelection();
			parentTr = null;
			if (TileEd.Instance != null && TileEd.Instance.map != null && TileEd.Instance.mapTr != null)
			{
				// find the Tool's main object, else create one
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr == null)
				{
					GameObject go = new GameObject(ROOT_NAME);
					tr = go.transform;
					tr.parent = TileEd.Instance.mapTr;
				}

				// now find the group object, or create one
				string groupIdent = TileEd.Instance.group.ident.ToString();
				parentTr = tr.Find(groupIdent);
				if (parentTr == null)
				{
					GameObject go = new GameObject(groupIdent);
					parentTr = go.transform;
					parentTr.parent = tr;
					EditorSceneManager.MarkAllScenesDirty();
				}
			}
		}

		public override void OnGroupVisibiliyChanged(int groupIdent, bool visible)
		{
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null) return; // no point to continue if the tool has not done anything yet

			// find the group root, if any exist
			string nm = groupIdent.ToString();
			for (int i = 0; i < topRoot.childCount; i++)
			{
				Transform tr = topRoot.GetChild(i);
				if (tr.name == nm)
				{
					tr.gameObject.SetActive(visible);
					return;
				}
			}
		}

		public override void OnDeletingGroup(TileEdMapGroup group)
		{
			// remove the game object that were placed by this tool
			// by simply deleting the whole group
			parentTr = null; // also, reset this just in case

			if (TileEd.Instance.map != null && TileEd.Instance.mapTr != null)
			{
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr != null)
				{
					tr = tr.Find(group.ident.ToString());
					if (tr != null)
					{
						Object.DestroyImmediate(tr.gameObject);						
					}
				}
			}

			// remove meshes related to this group
			plyEdUtil.CheckPath(TileEdGlobal.MESH_PATH + PATH);
			string s = TOOL_IDENT.ToString();
			for (int i = 0; i < group.combinedMeshNames.Count; i++)
			{
				if (group.combinedMeshNames[i].StartsWith(s))
				{
					AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + PATH + group.combinedMeshNames[i] + ".asset");
				}
			}
		}

		public override void OnDuplicatedGroup(TileEdMapGroup group)
		{
			RecreateGroup(group, false);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region map and group manipulation

		public override bool CanGroupCombine()
		{
			return true;
		}

		private class CombineBlock
		{
			public List<GameObject> objs;

			// each block of tiles is identified by this info
			public string tag;
			public int layer;
			public StaticEditorFlags staticFlags;
			public int navArea;
		}

		public override void CombineGroup(TileEdMapGroup group, bool doUv2, UnwrapParam unwrapParam)
		{
			plyEdUtil.CheckPath(TileEdGlobal.MESH_PATH + PATH);
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null)
			{
				GameObject go = new GameObject(ROOT_NAME);
				topRoot = go.transform;
				topRoot.parent = TileEd.Instance.mapTr;
			}

			Transform groupRoot = topRoot.Find(group.ident.ToString());
			if (groupRoot == null) return;

			EditorUtility.DisplayProgressBar("Combing Tiles from group: " + group.name, "Starting ...", 0f);
			try
			{
				List<CombineBlock> combineBlocks = new List<TileEd_Ed_Tiles.CombineBlock>();
				IntVector3[] minMaxPos = group.GetMinMaxGridPosition();

				for (int y = minMaxPos[0].y; y <= minMaxPos[1].y; y++)
				{
					for (int x = minMaxPos[0].x; x <= minMaxPos[1].x; x += TileEdGlobal.combineBlockSize)
					{
						for (int z = minMaxPos[0].z; z <= minMaxPos[1].z; z += TileEdGlobal.combineBlockSize)
						{
							// collect tiles to combine using blockSize to determine size of block of tiles to grab
							for (int xx = 0; xx < TileEdGlobal.combineBlockSize; xx++)
							{
								for (int zz = 0; zz < TileEdGlobal.combineBlockSize; zz++)
								{
									IntVector3 pos = new IntVector3(x + xx, y, z + zz);
									Transform tr = groupRoot.Find(pos.ToString());
									if (tr != null)
									{
										string tag = tr.gameObject.tag;
										int layer = tr.gameObject.layer;
										StaticEditorFlags staticFlags = GameObjectUtility.GetStaticEditorFlags(tr.gameObject);
										int navArea = GameObjectUtility.GetNavMeshArea(tr.gameObject);

										// find a block that this tile should be added to
										CombineBlock block = null;
										for (int blockIdx = 0; blockIdx < combineBlocks.Count; blockIdx++)
										{
											CombineBlock b = combineBlocks[blockIdx];
											if (b.tag == tag && b.layer == layer && b.staticFlags == staticFlags && b.navArea == navArea)
											{
												block = b; break;
											}
										}

										if (block == null)
										{
											block = new CombineBlock()
											{
												objs = new List<GameObject>(),
												tag = tag,
												layer = layer,
												staticFlags = staticFlags,
												navArea = navArea
											};
											combineBlocks.Add(block);
										}

										block.objs.Add(tr.gameObject);
									}
								}
							}

							//if (objs.Count > 0)
							if (combineBlocks.Count > 0)
							{
								float progress = 0f;
								float step = 1f / combineBlocks.Count;
								for (int blockIdx = 0; blockIdx < combineBlocks.Count; blockIdx++)
								{
									progress += step;

									CombineBlock b = combineBlocks[blockIdx];

									// combine and move new objects into group							
									string name = TOOL_IDENT + "-" + group.ident + "-" + System.Guid.NewGuid().ToString("N");
									List<GameObject> gos = plyEdUtil.MeshCombine(groupRoot, b.objs, true, name, TileEdGlobal.MESH_PATH + PATH, doUv2, unwrapParam, "Combing Tiles from group: " + group.name, progress);

									for (int i = 0; i < gos.Count; i++)
									{
										if (gos[i] == null) continue;

										gos[i].tag = b.tag;
										gos[i].layer = b.layer;
										GameObjectUtility.SetStaticEditorFlags(gos[i], b.staticFlags);
										GameObjectUtility.SetNavMeshArea(gos[i], b.navArea);

										if (!group.combinedMeshNames.Contains(gos[i].name))
										{
											group.combinedMeshNames.Add(gos[i].name);
										}
									}

									// remove old tiles
									for (int i = 0; i < b.objs.Count; i++) Object.DestroyImmediate(b.objs[i]);
									b.objs.Clear();
								}
							}

							combineBlocks.Clear();
						}
					}
				}

			}
			catch (System.Exception ex) { Debug.LogException(ex); }

			EditorUtility.ClearProgressBar();
		}

		public override void RecreateMap()
		{
			ClearSelection();

			// make sure this tool's asset is loaded
			if (!LoadAsset()) return;
			plyEdUtil.CheckPath(TileEdGlobal.MESH_PATH + PATH);

			// setup a few things
			string s = TOOL_IDENT.ToString();
			GameObject go;
			parentTr = null;
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null)
			{
				go = new GameObject(ROOT_NAME);
				topRoot = go.transform;
				topRoot.parent = TileEd.Instance.mapTr;
			}

			ClearUndo();

			// recreate the tiles in the various groups
			for (int grpIdx = 0; grpIdx < TileEd.Instance.map.groups.Count; grpIdx++)
			{
				TileEdMapGroup group = TileEd.Instance.map.groups[grpIdx];
				Transform tr = null;

				// first delete the mesh assets
				for (int i = 0; i < group.combinedMeshNames.Count; i++)
				{
					if (group.combinedMeshNames[i].StartsWith(s))
					{
						AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + PATH + group.combinedMeshNames[i] + ".asset");
					}
				}

				for (int tileIdx = 0; tileIdx < group.Count; tileIdx++)
				{
					if (group[tileIdx].toolIdent == TOOL_IDENT)
					{
						// find the tile in tiles asset
						TileEdTileSet tileSet = asset.FindTileSet(group[tileIdx].data[_TileSetIdent]);
						if (tileSet == null)
						{
							Debug.LogWarning("[Tiles] Could not find Tile Set for tiles used in map. You probably deleted the Tile Set after having placed tiles from it in the scene.");
							continue;
						}

						TileEdTile tile = tileSet.FindTile(group[tileIdx].data[_TileIdent]);
						if (tile == null)
						{
							Debug.LogWarning("[Tiles] Could not find Tile for the tile used in map. You probably deleted the Tile from The Tile Set after having placed the tile from it in the scene.");
							continue;
						}

						int fabIdx = group[tileIdx].data[_TileFabIdx];
						if (tile.prefab[fabIdx] == null)
						{
							Debug.LogWarning("[Tiles] The tile prefab is null. You probably deleted the prefab without updating the Tile Set. The tile will not be removed from the TileEd Data. You can go to the Tile Set's settings and add a new prefab over the empty tile to fix it. You can also remove it completely and then choose the Tile Layer or Map recreate option to have the tile removed from the TileEd map data.");
							continue;
						}

						// create root object for group in the tool's root
						if (tr == null)
						{
							tr = topRoot.Find(group.ident.ToString());
							if (tr == null)
							{
								go = new GameObject(group.ident.ToString());
								tr = go.transform;
								tr.parent = topRoot;
							}
						}

						// create the object in scene
						//group[tileIdx].cachedTileObject = CreateTileObject(null, tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], tileSet, tile, TileIsSimple(tileSet, tile), group.tileSize, group.tileHeight);
						CreateTileObject(null, tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], tileSet, tile, TileIsSimple(tileSet, tile), group.tileSize, group.tileHeight);
					}
				}
			}
		}

		public override void RecreateGroup(TileEdMapGroup group, bool fromMain)
		{
			ClearSelection();

			// make sure this tool's asset is loaded
			if (!LoadAsset()) return;

			// setup a few things
			string s = TOOL_IDENT.ToString();
			GameObject go;
			parentTr = null;
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null)
			{
				go = new GameObject(ROOT_NAME);
				topRoot = go.transform;
				topRoot.parent = TileEd.Instance.mapTr;
			}

			// delete the mesh assets
			for (int i = 0; i < group.combinedMeshNames.Count; i++)
			{
				if (group.combinedMeshNames[i].StartsWith(s))
				{
					AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + PATH + group.combinedMeshNames[i] + ".asset");
				}
			}

			// delete old group root and all child objects (tiles)
			Transform tr = topRoot.Find(group.ident.ToString());
			if (tr != null)
			{
				Object.DestroyImmediate(tr.gameObject);
			}

			ClearUndo();

			// create new group root
			go = new GameObject(group.ident.ToString());
			tr = go.transform;
			tr.parent = topRoot;
			List<int> rem = new List<int>();

			for (int tileIdx = 0; tileIdx < group.Count; tileIdx++)
			{
				if (group[tileIdx].toolIdent == TOOL_IDENT)
				{
					// find the tile in tiles asset
					TileEdTileSet tileSet = asset.FindTileSet(group[tileIdx].data[_TileSetIdent]);
					if (tileSet == null)
					{
						Debug.LogWarning("[Tiles] Could not find Tile Set for tiles used in map. You probably deleted the Tile Set after having placed tiles from it in the scene. The tile will be removed from the TileEd Map Data.");
						rem.Add(tileIdx);
						continue;
					}

					TileEdTile tile = tileSet.FindTile(group[tileIdx].data[_TileIdent]);
					if (tile == null)
					{
						Debug.LogWarning("[Tiles] Could not find Tile for the tile used in map. You probably deleted the Tile from The Tile Set after having placed the tile from it in the scene. The tile will be removed from the TileEd Map Data.");
						rem.Add(tileIdx);
						continue;
					}

					int fabIdx = group[tileIdx].data[_TileFabIdx];
					if (tile.prefab[fabIdx] == null)
					{
						Debug.LogWarning("[Tiles] The tile prefab is null. You probably deleted the prefab without updating the Tile Set. The tile will not be removed from the TileEd Data. You can go to the Tile Set's settings and add a new prefab over the empty tile to fix it. You can also remove it completely and then choose the Tile Layer or Map recreate option to have the tile removed from the TileEd map data.");
						continue;
					}

					// create the object in scene
					//group[tileIdx].cachedTileObject = CreateTileObject(null, tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], tileSet, tile, TileIsSimple(tileSet, tile), group.tileSize, group.tileHeight);
					CreateTileObject(null, tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], tileSet, tile, TileIsSimple(tileSet, tile), group.tileSize, group.tileHeight);
					
				}
			}

			if (rem.Count > 0)
			{
				for (int i = rem.Count - 1; i >= 0; i--)
				{
					group.RemoveTile(rem[i]);
				}

				plyEdUtil.SetDirty(TileEd.Instance.map);
				EditorSceneManager.MarkAllScenesDirty();
			}

		}

		public override void ReplaceTilesInMap(TileSetInfo oldSetNfo, TileSetInfo newSetNfo)
		{
			TileEdTileSet oldSet = asset.FindTileSet(oldSetNfo.setIdent);
			TileEdTileSet newSet = asset.FindTileSet(newSetNfo.setIdent);
			if (oldSet == null) { Debug.LogError("[ReplaceTilesInMap] Could not find the old TileSet"); return; }
			if (newSet == null) { Debug.LogError("[ReplaceTilesInMap] Could not find the new TileSet"); return; }

			for (int grpIdx = 0; grpIdx < TileEd.Instance.map.groups.Count; grpIdx++)
			{
				TileEdMapGroup group = TileEd.Instance.map.groups[grpIdx];
				for (int tIdx = 0; tIdx < group.Count; tIdx++)
				{
					if (group[tIdx].toolIdent != TOOL_IDENT) continue;
					if (group[tIdx].data[_TileSetIdent] != oldSet.ident) continue;

					// find the idx of the tile in the set since it must be matched to tile in same position of new set
					int oldTileIdent = group[tIdx].data[_TileIdent];
					int tileIdxInSet = -1;
					for (int i = 0; i < oldSet.tiles.Count; i++)
					{
						if (oldSet.tiles[i].ident == oldTileIdent) { tileIdxInSet = i; break; } 
					}

					if (tileIdxInSet < 0 || tileIdxInSet >= newSet.tiles.Count) continue;
					TileEdTile t = newSet.tiles[tileIdxInSet];

					// if there is no fab at idx then use the one at 0 (or ignore if none there either)
					int tileFabIdx = group[tIdx].data[_TileFabIdx];
					if (tileFabIdx >= t.prefab.Length || t.prefab[tileFabIdx] == null)
					{
						tileFabIdx = 0;
						if (t.prefab[0] == null) continue;
					}

					group[tIdx].data[_TileSetIdent] = newSet.ident;
					group[tIdx].data[_TileIdent] = t.ident;
					group[tIdx].data[_TileFabIdx] = tileFabIdx;
					group[tIdx].data[_TileIdx] = t.tileIdx;
					group[tIdx].data[_TransitionIdx] = t.transitionIdx;
					group[tIdx].data[_TransitionSetIdent] = t.targetTransSet;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region templates

		private void TemplatesInspector()
		{
			EditorGUILayout.Space();
			Event ev = Event.current;
			if (ev.type == EventType.Repaint) lastInspectorWidth = GUILayoutUtility.GetLastRect().width;
			else if (lastInspectorWidth == 0.0f) lastInspectorWidth = Screen.width - 19;

			GUILayout.Label(GC_TemplatesHead, plyEdGUI.Styles.LargeLabel);
			EditorGUILayout.Space();

			if (tmplAsset.templates.Count == 0)
			{
				GUILayout.Label(GC_NoTemplates);
				return;
			}

			TileEdGlobal.PreviewAlloc(0, tmplAsset.templates.Count + 1);
			//AssetPreview.SetPreviewTextureCacheSize(tmplAsset.templates.Count + 1);

			Rect refRect = GUILayoutUtility.GetRect(0, 5, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(false), GUILayout.Height(5));
			refRect.width = lastInspectorWidth;

			int sz = (TileEdGlobal.templatesPreviewSize + 5);

			float allocW = Mathf.Clamp(Mathf.FloorToInt(refRect.width / sz), 1, tmplAsset.templates.Count);
			GUILayoutUtility.GetRect(sz, Mathf.CeilToInt(tmplAsset.templates.Count / allocW) * sz);

			int rem = -1, sel = -1;
			Rect r = new Rect(refRect.x, refRect.y, TileEdGlobal.templatesPreviewSize, TileEdGlobal.templatesPreviewSize);
			Rect br = new Rect(0, 0, 16, 16);

			for (int i = 0; i < tmplAsset.templates.Count; i++)
			{
				if (ev.type == EventType.Repaint)
				{
					if (tmplAsset.templates[i].texture == null)
					{
						tmplAsset.templates[i].texture = AssetPreview.GetAssetPreview(tmplAsset.templates[i].prefab);
						if (tmplAsset.templates[i].texture != null)
						{
							tmplAsset.templates[i].texture = plyEdUtil.SavePNG(tmplAsset.templates[i].texture, TileEdGlobal.FABS_PATH + PATH + tmplAsset.templates[i].guid + ".png");
							plyEdUtil.SetDirty(tmplAsset);
						}
					}

					if (tmplAsset.templates[i].texture == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
					else GUI.Box(r, tmplAsset.templates[i].texture, TileEdGUI.Styles.TilePreview);
				}

				br.x = r.xMax - 16; br.y = r.y;
				if (GUI.Button(br, GC_DelTmpl, plyEdGUI.Styles.Button))
				{
					rem = i;
				}
				else if (ev.type == EventType.MouseDown && ev.button == 0 && r.Contains(ev.mousePosition))
				{
					sel = i;
					ev.Use();
				}

				r.x += sz;
				if (r.xMax > refRect.xMax)
				{
					r.x = refRect.x;
					r.y += sz;					
				}
			}

			if (rem >= 0)
			{
				if (EditorUtility.DisplayDialog("TileEd", "Remove the template. Are you sure?", "Yes", "Cancel"))
				{
					if (tmplAsset.templates[rem].texture != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[rem].texture));
					if (tmplAsset.templates[rem].prefab != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[rem].prefab));

					tmplAsset.templates.RemoveAt(rem);
					plyEdUtil.SetDirty(tmplAsset);
					AssetDatabase.Refresh();
				}
			}
			else if (sel >= 0)
			{
				ActivateTemplate(tmplAsset.templates[sel]);
			}

		}

		private void CreateNewTemplate()
		{
			plyEdUtil.CheckPath(TileEdGlobal.FABS_PATH);
			plyEdUtil.CheckPath(TileEdGlobal.FABS_PATH + PATH);

			TileEdTemplate t = copyBuffer.Copy();
			t.name = "Template " + (tmplAsset.templates.Count + 1).ToString();
			t.guid = "";

			// generate a unique name for the preview prefab
			bool done = false;
			while (!done)
			{
				t.guid = System.Guid.NewGuid().ToString("N");
				string path = plyEdUtil.ProjectFullPath + TileEdGlobal.FABS_PATH + PATH + t.guid + ".prefab";
				if (false == System.IO.File.Exists(path)) done = true;
			}

			// create preview texture (if available now)
			if (copyBuffer.texture == null) copyBuffer.texture = AssetPreview.GetAssetPreview(copyBuffer.prefab);
			if (copyBuffer.texture != null) t.texture = plyEdUtil.SavePNG(copyBuffer.texture, TileEdGlobal.FABS_PATH + PATH + t.guid + ".png");

			// create the preview prefab by making a copy of the copy buffer's
			t.prefab = plyEdUtil.CreatePrefabFromPrefab(copyBuffer.prefab, TileEdGlobal.FABS_PATH + PATH + t.guid + ".prefab");

			// update template asset
			tmplAsset.templates.Add(t);
			plyEdUtil.SetDirty(tmplAsset);
		}

		private void ActivateTemplate(TileEdTemplate tmpl)
		{
			ClearCopyBuffer();
			AssetDatabase.Refresh();

			plyEdUtil.CheckPath(TileEdGlobal.TEMP_PATH);
			copyBuffer = tmpl.Copy();
			copyBuffer.texture = null;
			copyBuffer.prefab = plyEdUtil.CreatePrefabFromPrefab(tmpl.prefab, TileEdGlobal.TEMP_PATH + "copy_buffer_preview.prefab");
			copyBuffer.prefab.name = "copy_buffer_preview";
			plyEdUtil.SetDirty(copyBuffer.prefab);

			EnterPasteMode();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region events

		public override void HandleGridEvents(Event ev)
		{
			// right-click clear selection/ pasting
			if ((TileEd.grid.cursorMode == TileEdCursorMode.Paste || selection.Count > 0) && 
				((ev.type == EventType.MouseDown && ev.button == 1) || (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.Escape)))
			{
				ClearSelection();
				ClearPasteMode();
				ev.Use();
				return;
			}

			if (selection.Count > 0)
			{
				if (ev.type == EventType.ValidateCommand)
				{
					switch (ev.commandName)
					{
						case "Duplicate":
						case "Cut":
						case "Copy":
						case "Delete":
						case "SoftDelete": ev.Use(); return;
					}
				}

				else if (ev.type == EventType.ExecuteCommand)
				{
					switch (ev.commandName)
					{
						case "Duplicate": { DuplicateSelection(); ev.Use(); } return;
						case "Cut": { CutSelection(); ev.Use(); } return;
						case "Copy": { CopySelection(true); ev.Use(); } return;
						case "Delete": case "SoftDelete": { DeleteSelection(); ev.Use(); } return;
					}
				}

				else if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.Delete)
				{
					DeleteSelection(); 
					ev.Use();
					return;
				}
			}

			if (copyBuffer.tiles.Count > 0)
			{
				if (ev.type == EventType.ValidateCommand)
				{
					if (ev.commandName == "Paste")
					{
						ev.Use();
					}
				}

				else if (ev.type == EventType.ExecuteCommand)
				{
					if (ev.commandName == "Paste")
					{
						EnterPasteMode();
						ev.Use();
					}
				}
			}

			// check if should clear selected tile
			if (ev.type == EventType.KeyUp && ev.keyCode == KeyCode.Escape)
			{
				if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
				{
					ev.Use();
					ClearPasteMode();
				}

				else if (currTileIdx >= 0)
				{
					ev.Use();
					currTileIdx = -1;
					currTileIsSimple = true;
					TileEd.grid.UpdatePreviewObject(null, 0f);
				}
			}

			// check if should rotate tile
			if (ev.modifiers == EventModifiers.Alt && ev.type == EventType.ScrollWheel)
			{
				tileRotation += (ev.delta.y > 0.0f ? +90 : -90);
				ev.Use();

				if (tileRotation < 0) tileRotation = 270;
				if (tileRotation > 270) tileRotation = 0;
				TileEd.grid.UpdatePreviewObjectRotation(tileRotation);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region grid

		public override TileEd_Grid.CursorStyle WantedDeleteCursorStyle()
		{
			if (TileEd.grid.cursorMode == TileEdCursorMode.Normal && (currTileIdx < 0 || tileSetIdx < 0)) return TileEd_Grid.CursorStyle.Delete;

			if ((TileEd.grid.cursorMode == TileEdCursorMode.Delete && tileSetIdx < 0) || currTileIsSimple)
			{
				return TileEd_Grid.CursorStyle.Delete;
			}
			else if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
			{
				if (canSculpt) return TileEd_Grid.CursorStyle.Sculpting;
				else return TileEd_Grid.CursorStyle.Delete;
			}

			return TileEd_Grid.CursorStyle.Delete;
		}

		public override void OnGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag, Vector3 mouseWorldPos)
		{
			if (parentTr == null)
			{	// should not really happen, but just in case
				OnMapChanged();
				if (parentTr == null) return;
			}

			// **** mark tile(s)
			if (cursorMode == TileEdCursorMode.Mark)
			{
				ClearPasteMode(); // just in case in paste mode
				if (isDrag == false) wasClickOnSelected = false;

				for (int i = 0; i < gridPos.Length; i++)
				{
					int idx = TileEdSelected.ListContains(selection, gridPos[i]);
					if (idx >= 0)
					{						
						if (wasClickOnSelected || !isDrag)
						{
							// remove from selection
							wasClickOnSelected = true;
							TileEdGUI.RemoveSelectionMarker(selection[idx].markerGo);
							selection.RemoveAt(idx);
						}
						continue;
					}

					// if the click was on an existing selected tile then any drag will 
					// only be valid when over selected tiles to remove them from selection
					// a new click-drag must be started on an unselected tile to continue
					// the selection action and adding tiles to selection
					if (wasClickOnSelected) continue;

					//cache TileEdMapTile tile = TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos[i]);
					//if (tile != null)
					//{
					//	Transform tileTr = parentTr.Find(gridPos[i].ToString());
					//	if (tileTr != null)
					//	{
					//		GameObject goMarker = TileEdGUI.AddSelectionMarker(tileTr.gameObject);
					//		selection.Add(new TileEdSelected()
					//		{
					//			//groupIdent = TileEd.Instance.group.ident,
					//			group = TileEd.Instance.group,
					//			tile = tile,
					//			gridPos = gridPos[i],
					//			markerGo = goMarker,
					//			mainGo = tileTr.gameObject
					//		});
					//	}
					//}

					TileEdMapTile tile = GetTile(gridPos[i]); // TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos[i]);
					if (tile != null)
					{
						GameObject go = GetTileGo(tile);
						GameObject goMarker = TileEdGUI.AddSelectionMarker(go);
						selection.Add(new TileEdSelected()
						{
							//groupIdent = TileEd.Instance.group.ident,
							group = TileEd.Instance.group,
							tile = tile,
							gridPos = gridPos[i],
							markerGo = goMarker,
							mainGo = go
						});
					}

				}
			}

			// **** paste tile(s)
			else if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
			{
				if (copyBuffer.tiles.Count == 0) return;
				PasteFromCopyBuffer(gridPos[0]);
			}

			// **** place or delete tile(s)
			else
			{
				ClearSelection(); // just in case previous action was a selection
				ClearPasteMode(); // just in case in paste mode

				if (cursorMode == TileEdCursorMode.Normal && (currTileIdx < 0 || tileSetIdx < 0)) return;

				if (currTileIsSimple)
				{
					HandleSimpleTileGridClick(gridPos, cursorMode, isDrag);
				}
				else if (asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Narrow)
				{
					HandleNarrowTileGridClick(gridPos, cursorMode, isDrag);
				}
				else if (asset.tileSets[tileSetIdx].type == TileEdTileSet.Type.Auto)
				{
					HandleAutoTileGridClick(gridPos, cursorMode, isDrag);
				}

			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region Paint Simple Tiles

		private void HandleSimpleTileGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag)
		{
			bool startedUndo = isDrag; // allow new undo group only if mouse went down, not during a mouse drag

			// **** place a tile(s)
			if (cursorMode == TileEdCursorMode.Normal)
			{
				int chosenFabIdx = 0;
				if (canRandomFab && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
				{
					chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
					if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
				}

				GameObject fab = asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx];
				if (fab == null) return;

				for (int i = 0; i < gridPos.Length; i++)
				{
					if (canRandomRotate) tileRotation = Random.Range(0, 4) * 90;

					if (canRandomFabAll && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
					{
						chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
						if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
						fab = asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx];
					}

					// find the existing tile in asset
					TileEdMapTile tile = GetTile(gridPos[i]); // TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos[i]);
					if (tile != null)
					{
						// check if the tile is same as one to be placed, set ident, tile ident, and rotation must all be the same
						if (tile.data[_TileSetIdent] == asset.tileSets[tileSetIdx].ident &&
							tile.data[_TileIdent] == asset.tileSets[tileSetIdx].tiles[currTileIdx].ident &&
							tile.data[_TileRotation] == tileRotation &&
							tile.data[_TileFabIdx] == chosenFabIdx)
						{
							continue;
						}
					}

					if (startedUndo == false)
					{
						startedUndo = true;
						Undo.IncrementCurrentGroup();
						Undo.SetCurrentGroupName("Paint Simple Tile(s)");
						Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Paint Simple Tile(s)");
					}

					if (tile != null) RemoveTile(tile);

					// add tile to asset
					CreateTile("Paint Simple Tile(s)", true, fab, gridPos[i], tileRotation,
						asset.tileSets[tileSetIdx],  asset.tileSets[tileSetIdx].tiles[currTileIdx], chosenFabIdx, 
						asset.tileSets[tileSetIdx].tiles[currTileIdx].targetTransSet, 
						asset.tileSets[tileSetIdx].tiles[currTileIdx].transitionIdx);

				}

				//if (startedUndo)
				//{
				//	plyEdUtil.SetDirty(TileEd.Instance.map);
				//}
			}

			// **** delete tile(s)
			else if (cursorMode == TileEdCursorMode.Delete)
			{
				for (int i = 0; i < gridPos.Length; i++)
				{
					// first check if there is actually an entry of the tile since it will help determine if
					// what is in the scene is correct or not and save on unnecessary parentTr.Find()
					TileEdMapTile tile = GetTile(gridPos[i]); //TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos[i]);
					if (tile != null)
					{
						if (startedUndo == false)
						{
							startedUndo = true;
							Undo.IncrementCurrentGroup();
							Undo.SetCurrentGroupName("Remove Simple Tile(s)");
							Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Remove Simple Tile(s)");
						}

						RemoveTile(tile);
					}
				}

				//if (startedUndo)
				//{
				//	plyEdUtil.SetDirty(TileEd.Instance.map);
				//}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region Paint Auto Tiles

		private void HandleAutoTileGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag)
		{
			bool startedUndo = isDrag; // allow new undo group only if mouse went down, not during a mouse drag
			bool sculptDown = (canSculpt && cursorMode == TileEdCursorMode.Delete);
			
			// can't sculpt down dungeon floors. Floor must be deleted
			if (sculptDown && asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Dungeon) sculptDown = false; 

			#region place or lower auto-tile(s)
			if (cursorMode == TileEdCursorMode.Normal || sculptDown)
			{
				int rot = tileRotation; // make copy so that original is not changed by canRandomRotate below 
				if (asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Directional) rot = 0;

				int chosenFabIdx = 0;
				if (canRandomFab && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
				{
					chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
					if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
				}

				GameObject fab = asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx];
				//if (fab == null) return; - allow for 'empty" tiles just do not place any game object

				if (startedUndo == false)
				{
					startedUndo = true;
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Paint Auto Tile(s)");
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Paint Auto Tile(s)");
				}

				List<TileEdMapTile> udpatedTiles = new List<TileEdMapTile>();
				for (int i = 0; i < gridPos.Length; i++)
				{
					if (canRandomFabAll && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
					{
						chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
						if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
						fab = asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx];
					}

					IntVector3 pos = gridPos[i];
					if (cursorMode == TileEdCursorMode.Delete) pos.y = pos.y - 1;

					if (canRandomRotate && asset.tileSets[tileSetIdx].autoType == TileEdTileSet.AutoType.Rotating)
					{
						rot = Random.Range(0, 4) * 90;
					}

					TileEdMapTile oldTile = null;
					if (asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Terrain)
					{
						// need to delete all above and below for sculpt mode when painting with terrain wall system
						List<TileEdMapTile> tiles = GetTilesXZ(pos, autoTileDepthAboveBelow[0], autoTileDepthAboveBelow[1]); //TileEd.Instance.group.GetTilesXZ(TOOL_IDENT, pos);
						if (tiles.Count > 0)
						{
							for (int tidx = 0; tidx < tiles.Count; tidx++)
							{
								// do not delete a tile which will not change (this will increase performance)
								// I will ignore the random tile in this case and just keep whatever the old tile used
								if (tiles[tidx].data[_TileIdent] == asset.tileSets[tileSetIdx].tiles[currTileIdx].ident && tiles[tidx].gridPos == pos)
								{
									oldTile = tiles[tidx];
									continue;
								}

								RemoveTile(tiles[tidx]);

							}
						}
					}
					else
					{
						TileEdMapTile tile = GetTile(pos); // TileEd.Instance.group.GetTile(TOOL_IDENT, pos);
						if (tile != null)
						{
							// do not delete a tile which will not change (this will increase performance)
							// I will ignore the random tile in this case and just keep whatever the old tile used
							if (tile.data[_TileIdent] == asset.tileSets[tileSetIdx].tiles[currTileIdx].ident && tile.gridPos == pos)
							{
								oldTile = tile;
							}
							else
							{
								RemoveTile(tile);
							}
						}
					}

					// add tile to asset
					if (oldTile == null)
					{
						TileEdMapTile newTile = CreateTile("Paint Auto Tile(s)", false, fab, pos, rot,  asset.tileSets[tileSetIdx],  asset.tileSets[tileSetIdx].tiles[currTileIdx], chosenFabIdx, asset.tileSets[tileSetIdx].ident, -1);
						udpatedTiles.Add(newTile);
					}
					else
					{
						udpatedTiles.Add(oldTile);
					}
				}

				//if (startedUndo)
				//{
					UpdateAutoTilesAround(asset.tileSets[tileSetIdx], udpatedTiles, null);
					//plyEdUtil.SetDirty(TileEd.Instance.map);
				//}
			}
			#endregion

			#region delete tile(s)
			else if (cursorMode == TileEdCursorMode.Delete)
			{
				List<IntVector3> udpatedPositions = new List<IntVector3>();
				for (int i = 0; i < gridPos.Length; i++)
				{
					// first check if there is actually an entry of the tile since it will help determine if
					// what is in the scene is correct or not and save on unnecessary parentTr.Find()
					TileEdMapTile tile = GetTile(gridPos[i]); // TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos[i]);
					if (tile != null)
					{
						if (startedUndo == false)
						{
							startedUndo = true;
							Undo.IncrementCurrentGroup();
							Undo.SetCurrentGroupName("Remove Auto Tile(s)");
							Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Remove Auto Tile(s)");
						}

						RemoveTile(tile);

						udpatedPositions.Add(gridPos[i]);
					}
				}

				//if (startedUndo)
				//{
					if (!canSculpt || asset.tileSets[tileSetIdx].wallSystem == TileEdTileSet.WallPivot.Dungeon)
					{
						// update the tiles around the new empty tile
						UpdateAutoTilesAround(asset.tileSets[tileSetIdx], null, udpatedPositions);
					}

					//plyEdUtil.SetDirty(TileEd.Instance.map);
				//}
			}
			#endregion
		}

		private void UpdateAutoTilesAround(TileEdTileSet refTileSet, List<TileEdMapTile> udpatedTiles, List<IntVector3> updatedPositions)
		{
			if (udpatedTiles != null)
			{
				for (int posIdx = 0; posIdx < udpatedTiles.Count; posIdx++)
				{
					TileEdMapTile refTile = udpatedTiles[posIdx];
					IntVector3 refGridPos = refTile.gridPos;

					for (int dir = 0; dir < 8; dir++)
					{
						bool good = true;
						IntVector3 p = refGridPos + TileEd_Grid.Direction[dir];
						for (int i = 0; i < udpatedTiles.Count; i++)
						{
							if (udpatedTiles[i].gridPos == p) { good = false; break; }
						}

						if (good)
						{
							UpdateAutoTileWall(refTile, refTileSet, p, dir, refTileSet.autoType == TileEdTileSet.AutoType.Directional);
						}
					}
				}
			}
			else
			{
				for (int posIdx = 0; posIdx < updatedPositions.Count; posIdx++)
				{
					IntVector3 refGridPos = updatedPositions[posIdx];

					for (int dir = 0; dir < 8; dir++)
					{
						bool good = true;
						IntVector3 p = refGridPos + TileEd_Grid.Direction[dir];
						for (int i = 0; i < updatedPositions.Count; i++)
						{
							if (updatedPositions[i] == p) { good = false; break; }
						}

						if (good)
						{
							UpdateAutoTileWall(null, refTileSet, p, dir, refTileSet.autoType == TileEdTileSet.AutoType.Directional);
						}
					}
				}
			}
		}

		private void UpdateAutoTileWall(TileEdMapTile refTile, TileEdTileSet refSet, IntVector3 gridPos, int dir, bool nonRot)
		{
			int targetIdx = -2;	// which tile to finally select (-2: none, -1:solid (must find a transition), else a wall)
			TileEdTile tile = null;
			int tileRotation = nonRot ? 0 : ClampTileRotation(90 * dir);

			// there must be wall/corner tile prefabs else do not bother
			// empty tiles are allowed - if (refSet.tiles[1].prefab[0] != null && refSet.tiles[2].prefab[0] != null && refSet.tiles[3].prefab[0] != null)
			//{
				#region setup
				// get positions for the 8 tiles around target tile
				IntVector3[] tPos = {
								gridPos + TileEd_Grid.Direction[0],
								gridPos + TileEd_Grid.Direction[1],
								gridPos + TileEd_Grid.Direction[2],
								gridPos + TileEd_Grid.Direction[3],
								gridPos + TileEd_Grid.Direction[4],
								gridPos + TileEd_Grid.Direction[5],
								gridPos + TileEd_Grid.Direction[6],
								gridPos + TileEd_Grid.Direction[7],
							};

				// get the test tiles
				TileEdMapTile[] tTile = GetTiles(tPos); // TileEd.Instance.group.GetTiles(TOOL_IDENT, tPos);

				// use to indicate if a tile is null (-1), same level (0), or level higher (1)
				int[] tr = {
								tTile[0] == null ? -1 : 0,
								tTile[1] == null ? -1 : 0,
								tTile[2] == null ? -1 : 0,
								tTile[3] == null ? -1 : 0,
								tTile[4] == null ? -1 : 0,
								tTile[5] == null ? -1 : 0,
								tTile[6] == null ? -1 : 0,
								tTile[7] == null ? -1 : 0,
				};

				// hight of tile from reference level
				int[] th = { 0, 0, 0, 0, 0, 0, 0, 0 };

				// get correct TransitionIdLookup[] idx 
				int[] tTransIdx = {		
						tTile[0] == null ? -2 : tTile[0].data[_TileIdx],
						tTile[1] == null ? -2 : tTile[1].data[_TileIdx],
						tTile[2] == null ? -2 : tTile[2].data[_TileIdx],
						tTile[3] == null ? -2 : tTile[3].data[_TileIdx],
						tTile[4] == null ? -2 : tTile[4].data[_TileIdx],
						tTile[5] == null ? -2 : tTile[5].data[_TileIdx],
						tTile[6] == null ? -2 : tTile[6].data[_TileIdx],
						tTile[7] == null ? -2 : tTile[7].data[_TileIdx],
				};

				// if a test tile is null then have to check a level higher
				// only for terrain wall system since dungeons do not support tile lowering
				if (refSet.wallSystem == TileEdTileSet.WallPivot.Terrain)
				{
					for (int i = 0; i < tTile.Length; i++)
					{
						if (tTile[i] == null)
						{
							tPos[i].y++;
							tTile[i] = GetTile(tPos[i]); //TileEd.Instance.group.GetTile(TOOL_IDENT, tPos[i]);
							if (tTile[i] != null)
							{
								tr[i] = 0; th[i] = 1;
								tTransIdx[i] = tTile[i].data[_TileIdx];
							}
							else
							{	// if still null, check one more level higher
								tPos[i].y++;
								tTile[i] = GetTile(tPos[i]); //TileEd.Instance.group.GetTile(TOOL_IDENT, tPos[i]);
								if (tTile[i] != null)
								{
									tr[i] = 0; th[i] = 2;
									tTransIdx[i] = tTile[i].data[_TileIdx];
								}
							}
						}
					}
				}

				// use the transition IDX and Rotation of the tile to determine the ID.
				// with special corner the rotation must be +90 if tr[]=1 (remember that tTransIdx[] is +1 and thus special corner is 4 and not 3)
				// { solid{90, 180, 270, 0} ,walls{90, 180, 270, 0}, convex{90, 180, 270, 0}, concave{90, 180, 270, 0}, special{90, 180, 270, 0} }
				int[] tId = { 0, 0, 0, 0, 0, 0, 0, 0 };
				for (int i = 0; i < 8; i++)
				{
					//if (dir == 0) Debug.Log(i + ": " + tTransIdx[i] + " => " + (tTile[i] == null ? "null" : (tTile[i].data[_TileIdent].ToString() + " :: " + tTile[i].gridPos.ToString()) ));
					if (tTransIdx[i] <= -2) { tId[i] = 0; continue; }  // empty tile
					if (tTransIdx[i] == -1) { tId[i] = 15; continue; } // full/simple tile
					if (tTile[i].data[_IsRotating] == 1) tId[i] = TransitionIdLookup[tTransIdx[i], ClampTileRotation(tTile[i].data[_TileRotation] + (tr[i] * 180) + (tr[i] == 1 && tTransIdx[i] == 4 ? 90 : 0)) / 90];
					else tId[i] = TransitionIdLookupNoRot[tTransIdx[i]];
				}

				//if (dir == 1) Debug.Log(tr[4] + " => " + tId[4]);
				//if (dir == 0) Debug.Log(System.Convert.ToString(tId[7], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[0], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[4], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[3], 2).PadLeft(4, '0') + " ### " + System.Convert.ToString(tId[1], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[6], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[2], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[5], 2).PadLeft(4, '0') + "\n");
				#endregion

				#region update tt[]
				// get tt, which represents the 4 corners touching the target tile. solid/reference (1) or the empty/transition (0)
				// tt[] starts at the BottomRight corner and goes anti-clockwise
				int[] tt = { 0, 0, 0, 0 };
				int hightMod = 0;

				if (dir == 0)
				{	// Top

					if (refTile != null) { tt[0] = 1; tt[1] = 1; tt[2] = 0; tt[3] = 0; }

					// 2: Top-Right-TopRight
					if ((tId[0] & b0100) == b0100 && tt[2] < th[0] + 1) tt[2] = th[0] + 1; else if (tt[2] < th[0] && (tId[0] & b0100) == 0) tt[2] = th[0];
					if ((tId[1] & b0001) == b0001 && tt[2] < th[1] + 1) tt[2] = th[1] + 1; else if (tt[2] < th[1] && (tId[1] & b0001) == 0) tt[2] = th[1];
					if ((tId[4] & b1000) == b1000 && tt[2] < th[4] + 1) tt[2] = th[4] + 1; else if (tt[2] < th[4] && (tId[4] & b1000) == 0) tt[2] = th[4];
						
					// 3: Top-Left-TopLeft
					if ((tId[0] & b1000) == b1000 && tt[3] < th[0] + 1) tt[3] = th[0] + 1; else if (tt[3] < th[0] && (tId[0] & b1000) == 0) tt[3] = th[0];
					if ((tId[3] & b0010) == b0010 && tt[3] < th[3] + 1) tt[3] = th[3] + 1; else if (tt[3] < th[3] && (tId[3] & b0010) == 0) tt[3] = th[3];
					if ((tId[7] & b0100) == b0100 && tt[3] < th[7] + 1) tt[3] = th[7] + 1; else if (tt[3] < th[7] && (tId[7] & b0100) == 0) tt[3] = th[7];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 1)
				{	// Right

					if (refTile != null) { tt[0] = 1; tt[1] = 0; tt[2] = 0; tt[3] = 1; }

					// 1: Bottom-Right-BottomRight
					if ((tId[1] & b1000) == b1000 && tt[1] < th[1] + 1) tt[1] = th[1] + 1; else if (tt[1] < th[1] && (tId[1] & b1000) == 0) tt[1] = th[1];
					if ((tId[2] & b0010) == b0010 && tt[1] < th[2] + 1) tt[1] = th[2] + 1; else if (tt[1] < th[2] && (tId[2] & b0010) == 0) tt[1] = th[2];
					if ((tId[5] & b0001) == b0001 && tt[1] < th[5] + 1) tt[1] = th[5] + 1; else if (tt[1] < th[5] && (tId[5] & b0001) == 0) tt[1] = th[5];

					// 2: Top-Right-TopRight
					if ((tId[0] & b0100) == b0100 && tt[2] < th[0] + 1) tt[2] = th[0] + 1; else if (tt[2] < th[0] && (tId[0] & b0100) == 0) tt[2] = th[0];
					if ((tId[1] & b0001) == b0001 && tt[2] < th[1] + 1) tt[2] = th[1] + 1; else if (tt[2] < th[1] && (tId[1] & b0001) == 0) tt[2] = th[1];
					if ((tId[4] & b1000) == b1000 && tt[2] < th[4] + 1) tt[2] = th[4] + 1; else if (tt[2] < th[4] && (tId[4] & b1000) == 0) tt[2] = th[4];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 2)
				{	// Bottom

					if (refTile != null) { tt[0] = 0; tt[1] = 0; tt[2] = 1; tt[3] = 1; }

					// 0: Bottom-Left-BottomLeft
					if ((tId[2] & b0001) == b0001 && tt[0] < th[2] + 1) tt[0] = th[2] + 1; else if (tt[0] < th[2] && (tId[0] & b0001) == 0) tt[0] = th[2];
					if ((tId[3] & b0100) == b0100 && tt[0] < th[3] + 1) tt[0] = th[3] + 1; else if (tt[0] < th[3] && (tId[3] & b0100) == 0) tt[0] = th[3];
					if ((tId[6] & b0010) == b0010 && tt[0] < th[6] + 1) tt[0] = th[6] + 1; else if (tt[0] < th[6] && (tId[7] & b0010) == 0) tt[0] = th[6];

					// 1: Bottom-Right-BottomRight
					if ((tId[1] & b1000) == b1000 && tt[1] < th[1] + 1) tt[1] = th[1] + 1; else if (tt[1] < th[1] && (tId[1] & b1000) == 0) tt[1] = th[1];
					if ((tId[2] & b0010) == b0010 && tt[1] < th[2] + 1) tt[1] = th[2] + 1; else if (tt[1] < th[2] && (tId[2] & b0010) == 0) tt[1] = th[2];
					if ((tId[5] & b0001) == b0001 && tt[1] < th[5] + 1) tt[1] = th[5] + 1; else if (tt[1] < th[5] && (tId[5] & b0001) == 0) tt[1] = th[5];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 3)
				{	// Left

					if (refTile != null) { tt[0] = 0; tt[1] = 1; tt[2] = 1; tt[3] = 0; }

					// 0: Bottom-Left-BottomLeft
					if ((tId[2] & b0001) == b0001 && tt[0] < th[2] + 1) tt[0] = th[2] + 1; else if (tt[0] < th[2] && (tId[0] & b0001) == 0) tt[0] = th[2];
					if ((tId[3] & b0100) == b0100 && tt[0] < th[3] + 1) tt[0] = th[3] + 1; else if (tt[0] < th[3] && (tId[3] & b0100) == 0) tt[0] = th[3];
					if ((tId[6] & b0010) == b0010 && tt[0] < th[6] + 1) tt[0] = th[6] + 1; else if (tt[0] < th[6] && (tId[7] & b0010) == 0) tt[0] = th[6];

					// 3: Top-Left-TopLeft
					if ((tId[0] & b1000) == b1000 && tt[3] < th[0] + 1) tt[3] = th[0] + 1; else if (tt[3] < th[0] && (tId[0] & b1000) == 0) tt[3] = th[0];
					if ((tId[3] & b0010) == b0010 && tt[3] < th[3] + 1) tt[3] = th[3] + 1; else if (tt[3] < th[3] && (tId[3] & b0010) == 0) tt[3] = th[3];
					if ((tId[7] & b0100) == b0100 && tt[3] < th[7] + 1) tt[3] = th[7] + 1; else if (tt[3] < th[7] && (tId[7] & b0100) == 0) tt[3] = th[7];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 4)
				{	// Top-Right

					if (refTile != null) { tt[0] = 1; tt[1] = 0; tt[2] = 0; tt[3] = 0; }

					// 1: Bottom-Right-BottomRight
					if ((tId[1] & b1000) == b1000 && tt[1] < th[1] + 1) tt[1] = th[1] + 1; else if (tt[1] < th[1] && (tId[1] & b1000) == 0) tt[1] = th[1];
					if ((tId[2] & b0010) == b0010 && tt[1] < th[2] + 1) tt[1] = th[2] + 1; else if (tt[1] < th[2] && (tId[2] & b0010) == 0) tt[1] = th[2];
					if ((tId[5] & b0001) == b0001 && tt[1] < th[5] + 1) tt[1] = th[5] + 1; else if (tt[1] < th[5] && (tId[5] & b0001) == 0) tt[1] = th[5];

					// 2: Top-Right-TopRight
					if ((tId[0] & b0100) == b0100 && tt[2] < th[0] + 1) tt[2] = th[0] + 1; else if (tt[2] < th[0] && (tId[0] & b0100) == 00) tt[2] = th[0];
					if ((tId[1] & b0001) == b0001 && tt[2] < th[1] + 1) tt[2] = th[1] + 1; else if (tt[2] < th[1] && (tId[1] & b0001) == 00) tt[2] = th[1];
					if ((tId[4] & b1000) == b1000 && tt[2] < th[4] + 1) tt[2] = th[4] + 1; else if (tt[2] < th[4] && (tId[4] & b1000) == 00) tt[2] = th[4];

					// 3: Top-Left-TopLeft
					if ((tId[0] & b1000) == b1000 && tt[3] < th[0] + 1) tt[3] = th[0] + 1; else if (tt[3] < th[0] && (tId[0] & b1000) == 0) tt[3] = th[0];
					if ((tId[3] & b0010) == b0010 && tt[3] < th[3] + 1) tt[3] = th[3] + 1; else if (tt[3] < th[3] && (tId[3] & b0010) == 0) tt[3] = th[3];
					if ((tId[7] & b0100) == b0100 && tt[3] < th[7] + 1) tt[3] = th[7] + 1; else if (tt[3] < th[7] && (tId[7] & b0100) == 0) tt[3] = th[7];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--; 
					}
				}
				else if (dir == 5)
				{	// Bottom-Right

					if (refTile != null) { tt[0] = 0; tt[1] = 0; tt[2] = 0; tt[3] = 1; }

					// 0: Bottom-Left-BottomLeft
					if ((tId[2] & b0001) == b0001 && tt[0] < th[2] + 1) tt[0] = th[2] + 1; else if (tt[0] < th[2] && (tId[0] & b0001) == 0) tt[0] = th[2];
					if ((tId[3] & b0100) == b0100 && tt[0] < th[3] + 1) tt[0] = th[3] + 1; else if (tt[0] < th[3] && (tId[3] & b0100) == 0) tt[0] = th[3];
					if ((tId[6] & b0010) == b0010 && tt[0] < th[6] + 1) tt[0] = th[6] + 1; else if (tt[0] < th[6] && (tId[7] & b0010) == 0) tt[0] = th[6];

					// 1: Bottom-Right-BottomRight
					if ((tId[1] & b1000) == b1000 && tt[1] < th[1] + 1) tt[1] = th[1] + 1; else if (tt[1] < th[1] && (tId[1] & b1000) == 0) tt[1] = th[1];
					if ((tId[2] & b0010) == b0010 && tt[1] < th[2] + 1) tt[1] = th[2] + 1; else if (tt[1] < th[2] && (tId[2] & b0010) == 0) tt[1] = th[2];
					if ((tId[5] & b0001) == b0001 && tt[1] < th[5] + 1) tt[1] = th[5] + 1; else if (tt[1] < th[5] && (tId[5] & b0001) == 0) tt[1] = th[5];

					// 2: Top-Right-TopRight
					if ((tId[0] & b0100) == b0100 && tt[2] < th[0] + 1) tt[2] = th[0] + 1; else if (tt[2] < th[0] && (tId[0] & b0100) == 0) tt[2] = th[0];
					if ((tId[1] & b0001) == b0001 && tt[2] < th[1] + 1) tt[2] = th[1] + 1; else if (tt[2] < th[1] && (tId[1] & b0001) == 0) tt[2] = th[1];
					if ((tId[4] & b1000) == b1000 && tt[2] < th[4] + 1) tt[2] = th[4] + 1; else if (tt[2] < th[4] && (tId[4] & b1000) == 0) tt[2] = th[4];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 6)
				{	// Bottom-Left

					if (refTile != null) { tt[0] = 0; tt[1] = 0; tt[2] = 1; tt[3] = 0; }

					// 0: Bottom-Left-BottomLeft
					if ((tId[2] & b0001) == b0001 && tt[0] < th[2] + 1) tt[0] = th[2] + 1; else if (tt[0] < th[2] && (tId[0] & b0001) == 0) tt[0] = th[2];
					if ((tId[3] & b0100) == b0100 && tt[0] < th[3] + 1) tt[0] = th[3] + 1; else if (tt[0] < th[3] && (tId[3] & b0100) == 0) tt[0] = th[3];
					if ((tId[6] & b0010) == b0010 && tt[0] < th[6] + 1) tt[0] = th[6] + 1; else if (tt[0] < th[6] && (tId[7] & b0010) == 0) tt[0] = th[6];

					// 1: Bottom-Right-BottomRight
					if ((tId[1] & b1000) == b1000 && tt[1] < th[1] + 1) tt[1] = th[1] + 1; else if (tt[1] < th[1] && (tId[1] & b1000) == 0) tt[1] = th[1];
					if ((tId[2] & b0010) == b0010 && tt[1] < th[2] + 1) tt[1] = th[2] + 1; else if (tt[1] < th[2] && (tId[2] & b0010) == 0) tt[1] = th[2];
					if ((tId[5] & b0001) == b0001 && tt[1] < th[5] + 1) tt[1] = th[5] + 1; else if (tt[1] < th[5] && (tId[5] & b0001) == 0) tt[1] = th[5];

					// 3: Top-Left-TopLeft
					if ((tId[0] & b1000) == b1000 && tt[3] < th[0] + 1) tt[3] = th[0] + 1; else if (tt[3] < th[0] && (tId[0] & b1000) == 0) tt[3] = th[0];
					if ((tId[3] & b0010) == b0010 && tt[3] < th[3] + 1) tt[3] = th[3] + 1; else if (tt[3] < th[3] && (tId[3] & b0010) == 0) tt[3] = th[3];
					if ((tId[7] & b0100) == b0100 && tt[3] < th[7] + 1) tt[3] = th[7] + 1; else if (tt[3] < th[7] && (tId[7] & b0100) == 0) tt[3] = th[7];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				else if (dir == 7)
				{	// Top-Left

					if (refTile != null) { tt[0] = 0; tt[1] = 1; tt[2] = 0; tt[3] = 0; }

					// 0: Bottom-Left-BottomLeft
					if ((tId[2] & b0001) == b0001 && tt[0] < th[2] + 1) tt[0] = th[2] + 1; else if (tt[0] < th[2] && (tId[0] & b0001) == 0) tt[0] = th[2];
					if ((tId[3] & b0100) == b0100 && tt[0] < th[3] + 1) tt[0] = th[3] + 1; else if (tt[0] < th[3] && (tId[3] & b0100) == 0) tt[0] = th[3];
					if ((tId[6] & b0010) == b0010 && tt[0] < th[6] + 1) tt[0] = th[6] + 1; else if (tt[0] < th[6] && (tId[7] & b0010) == 0) tt[0] = th[6];

					// 2: Top-Right-TopRight
					if ((tId[0] & b0100) == b0100 && tt[2] < th[0] + 1) tt[2] = th[0] + 1; else if (tt[2] < th[0] && (tId[0] & b0100) == 0) tt[2] = th[0];
					if ((tId[1] & b0001) == b0001 && tt[2] < th[1] + 1) tt[2] = th[1] + 1; else if (tt[2] < th[1] && (tId[1] & b0001) == 0) tt[2] = th[1];
					if ((tId[4] & b1000) == b1000 && tt[2] < th[4] + 1) tt[2] = th[4] + 1; else if (tt[2] < th[4] && (tId[4] & b1000) == 0) tt[2] = th[4];

					// 3: Top-Left-TopLeft
					if ((tId[0] & b1000) == b1000 && tt[3] < th[0] + 1) tt[3] = th[0] + 1; else if (tt[3] < th[0] && (tId[0] & b1000) == 0) tt[3] = th[0];
					if ((tId[3] & b0010) == b0010 && tt[3] < th[3] + 1) tt[3] = th[3] + 1; else if (tt[3] < th[3] && (tId[3] & b0010) == 0) tt[3] = th[3];
					if ((tId[7] & b0100) == b0100 && tt[3] < th[7] + 1) tt[3] = th[7] + 1; else if (tt[3] < th[7] && (tId[7] & b0100) == 0) tt[3] = th[7];

					if (tt[0] > 1 || tt[1] > 1 || tt[2] > 1 || tt[3] > 1)
					{
						hightMod = 1;
						tt[0]--; tt[1]--; tt[2]--; tt[3]--;
					}
				}
				#endregion
				
				#region choose tile

				// calculate id for transition to use
				int id = tt[0] + (2 * tt[1]) + (4 * tt[2]) + (8 * tt[3]);
				//if (dir == 0) Debug.Log(tt[3].ToString() + tt[2].ToString() + tt[1].ToString() + tt[0].ToString() + " = " + id.ToString());

				if (id == 15)
				{	// a solid do not need a transition
					tile = refSet.tiles[0];
					targetIdx = -1; // a solid (need to check for transitions like grass to sand)
					gridPos.y += hightMod;
				}

				else
				{
					// the transition id assumes a non-rotating set so now need to find correct transition id and rotation in a rotating set
					// original transition id runs from 1 to 14. Need to map this to 4 possible transition tiles and associated rotations
					// an invalid ID is possible if a corner could not be determined, simply ignore in that case.
					if (id > 0 && id < TransitionIdMapping.Length)
					{
						if (nonRot)
						{
							tile = refSet.tiles[(TransitionIdMapping[id] * 4) + 1 + TransitionNoRotation[id]];
							tileRotation = 0;

							//if (dir == 5) Debug.Log(dir + ": (" + TransitionIdMapping[id] + " * 4) + 1 + " + TransitionRotMapping[id] + " == " + ((TransitionIdMapping[id] * 4) + 1 + TransitionRotMapping[id]) + " => tileident: " + tile.ident);
						}
						else
						{
							tile = refSet.tiles[TransitionIdMapping[id] + 1];
							tileRotation = TransitionRotations[id];

							//if (dir == 5) Debug.Log(dir + ": " + TransitionIdMapping[id]);
						}
						targetIdx = 0; // a wall tile was selected
						gridPos.y += hightMod;
					}
				}
				#endregion
			//}
			//else
			//{
			//	targetIdx = -1; // so that transition check will be done at least
			//}

			#region CREATE TILE

			// if it is a solid then check if tile should become a transition tile
			if (targetIdx == -1 && refTile != null)
			{
				int r = 0;
				TileEdTile transitionTile = UpdateAutoTileTransition(refTile, refSet, gridPos, dir, ref r, nonRot);
				if (transitionTile != null)
				{
					tile = transitionTile;
					tileRotation = r;
				}
				else
				{
					if (nonRot == false && canRandomRotate) tileRotation = Random.Range(0, 4) * 90;
				}
			}

			// only continue if a tile was selected or if refTile == null (meaning this is a sculpt down to empty tile)
			//if (refTile != null && (tile == null || tile.prefab[0] == null)) return;
			if (refTile != null && tile == null) return;

			//Undo.IncrementCurrentGroup();
			//Undo.SetCurrentGroupName("Paint Auto Tile(s)");

			// choose a prefab to use from the tile
			int chosenFabIdx = 0;
			GameObject fab = null;
			if (tile != null)
			{
				if (canRandomFab && tile.prefab.Length > 1)
				{
					chosenFabIdx = Random.Range(0, tile.prefab.Length);
					if (tile.prefab[chosenFabIdx] == null) chosenFabIdx = 0;
				}
				fab = tile.prefab[chosenFabIdx];
			}

			// need to delete all above and below for sculpt mode
			bool canPlaceNewTile = true;
			if (refSet.wallSystem == TileEdTileSet.WallPivot.Dungeon)
			{
				TileEdMapTile dt = GetTile(gridPos); //TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos);
				if (dt != null)
				{
					// do not delete a tile which will not change (this will increase performance)
					if (tile != null && dt.data[_TileIdent] == tile.ident && dt.gridPos == gridPos && dt.data[_TileRotation] == tileRotation)
					{
						canPlaceNewTile = false;
					}
					else
					{
						RemoveTile(dt);
					}
				}
			}
			else
			{
				List<TileEdMapTile> tiles = GetTilesXZ(gridPos, autoTileDepthAboveBelow[0], autoTileDepthAboveBelow[1]); // TileEd.Instance.group.GetTilesXZ(TOOL_IDENT, gridPos);
				if (tiles.Count > 0)
				{
					for (int tidx = 0; tidx < tiles.Count; tidx++)
					{
						// do not delete a tile which will not change (this will increase performance)
						if (tile != null && tiles[tidx].data[_TileIdent] == tile.ident && tiles[tidx].gridPos == gridPos && tiles[tidx].data[_TileRotation] == tileRotation)
						{
							canPlaceNewTile = false;
							continue;
						}

						RemoveTile(tiles[tidx]);
					}
				}
			}

			// add new tile to asset
			//if (canPlaceNewTile && tile != null && fab != null)
			if (canPlaceNewTile && tile != null)
			{
				CreateTile("Paint Auto Tile(s)", false, fab, gridPos, tileRotation, refSet, tile, chosenFabIdx, tile.targetTransSet, tile.transitionIdx);
			}
			#endregion

		}

		private TileEdTile UpdateAutoTileTransition(TileEdMapTile refTile, TileEdTileSet refSet, IntVector3 gridPos, int dir, ref int chosenRotation, bool nonRot)
		{
			TileEdTile tile = null;

			// get positions for the 8 tiles around target tile
			IntVector3[] tPos = {
									gridPos + TileEd_Grid.Direction[0],
									gridPos + TileEd_Grid.Direction[1],
									gridPos + TileEd_Grid.Direction[2],
									gridPos + TileEd_Grid.Direction[3],
									gridPos + TileEd_Grid.Direction[4],
									gridPos + TileEd_Grid.Direction[5],
									gridPos + TileEd_Grid.Direction[6],
									gridPos + TileEd_Grid.Direction[7],
								};

			// get the test tiles
			TileEdMapTile[] tTile = GetTiles(tPos); // TileEd.Instance.group.GetTiles(TOOL_IDENT, tPos);

			// need to check the corners touching the target tile to determine which corners are same as reference and not
			// need to find the original transition id for the tile to get the binary data which represents the tile corners 		
			// tr[] tell's whether the rotation should be flipped or not during tId setup
			// if the tile is null then invalid (-1)
			// if the tile is full (not a transition) and is not a full from the ref set then invalid (-1)
			int[] tr = {
						   tTile[0] == null || (tTile[0].data[_TransitionIdx] < 0 && tTile[0].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[0].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[1] == null || (tTile[1].data[_TransitionIdx] < 0 && tTile[1].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[1].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[2] == null || (tTile[2].data[_TransitionIdx] < 0 && tTile[2].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[2].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[3] == null || (tTile[3].data[_TransitionIdx] < 0 && tTile[3].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[3].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[4] == null || (tTile[4].data[_TransitionIdx] < 0 && tTile[4].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[4].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[5] == null || (tTile[5].data[_TransitionIdx] < 0 && tTile[5].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[5].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[6] == null || (tTile[6].data[_TransitionIdx] < 0 && tTile[6].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[6].data[_TileSetIdent] == refSet.ident ? 0 : 1,
						   tTile[7] == null || (tTile[7].data[_TransitionIdx] < 0 && tTile[7].data[_TileSetIdent] != refSet.ident) ? -1 : tTile[7].data[_TileSetIdent] == refSet.ident ? 0 : 1,
					   };

			// take transition IDX and add 1 to get correct TransitionIdLookup[] idx 
			// Convex and Concave corners need to swap when tr is 1
			int[] tTransIdx = {						  								
								  tr[0] == -1 ? 0 : (tr[0] == 0 ? tTile[0].data[_TransitionIdx] : tTile[0].data[_TransitionIdx] == 1 ? 2 : tTile[0].data[_TransitionIdx] == 2 ? 1 : tTile[0].data[_TransitionIdx]) + 1,
								  tr[1] == -1 ? 0 : (tr[1] == 0 ? tTile[1].data[_TransitionIdx] : tTile[1].data[_TransitionIdx] == 1 ? 2 : tTile[1].data[_TransitionIdx] == 2 ? 1 : tTile[1].data[_TransitionIdx]) + 1,
								  tr[2] == -1 ? 0 : (tr[2] == 0 ? tTile[2].data[_TransitionIdx] : tTile[2].data[_TransitionIdx] == 1 ? 2 : tTile[2].data[_TransitionIdx] == 2 ? 1 : tTile[2].data[_TransitionIdx]) + 1,
								  tr[3] == -1 ? 0 : (tr[3] == 0 ? tTile[3].data[_TransitionIdx] : tTile[3].data[_TransitionIdx] == 1 ? 2 : tTile[3].data[_TransitionIdx] == 2 ? 1 : tTile[3].data[_TransitionIdx]) + 1,
								  tr[4] == -1 ? 0 : (tr[4] == 0 ? tTile[4].data[_TransitionIdx] : tTile[4].data[_TransitionIdx] == 1 ? 2 : tTile[4].data[_TransitionIdx] == 2 ? 1 : tTile[4].data[_TransitionIdx]) + 1,
								  tr[5] == -1 ? 0 : (tr[5] == 0 ? tTile[5].data[_TransitionIdx] : tTile[5].data[_TransitionIdx] == 1 ? 2 : tTile[5].data[_TransitionIdx] == 2 ? 1 : tTile[5].data[_TransitionIdx]) + 1,
								  tr[6] == -1 ? 0 : (tr[6] == 0 ? tTile[6].data[_TransitionIdx] : tTile[6].data[_TransitionIdx] == 1 ? 2 : tTile[6].data[_TransitionIdx] == 2 ? 1 : tTile[6].data[_TransitionIdx]) + 1,
								  tr[7] == -1 ? 0 : (tr[7] == 0 ? tTile[7].data[_TransitionIdx] : tTile[7].data[_TransitionIdx] == 1 ? 2 : tTile[7].data[_TransitionIdx] == 2 ? 1 : tTile[7].data[_TransitionIdx]) + 1,
							  };

			// use the transition IDX and Rotation of the tile to determine the ID.
			// with special corner the rotation must be +90 if tr[]=1 (remember that tTransIdx[] is +1 and thus special corner is 4 and not 3)
			// { solid{90, 180, 270, 0} ,walls{90, 180, 270, 0}, convex{90, 180, 270, 0}, concave{90, 180, 270, 0}, special{90, 180, 270, 0} }
			int[] tId = { 0, 0, 0, 0, 0, 0, 0, 0, };
			for (int i = 0; i < 8; i++)
			{
				if (tr[i] < 0) { tId[i] = 0; continue; }
				if (tTile[i].data[_IsRotating] == 1) tId[i] = TransitionIdLookup[tTransIdx[i], ClampTileRotation(tTile[i].data[_TileRotation] + (tr[i] * 180) + (tr[i] == 1 && tTransIdx[i] == 4 ? 90 : 0)) / 90];
				else tId[i] = TransitionIdLookupNoRot[tTransIdx[i]];
			}

			//int[] tId = {
			//				tr[0] == -1 ? 0 : TransitionIdLookup[tTransIdx[0], ClampTileRotation(tTile[0].data[_TileRotation] + (tr[0] * 180) + (tr[0] == 1 && tTransIdx[0] == 4 ? 90 : 0)) / 90],
			//				tr[1] == -1 ? 0 : TransitionIdLookup[tTransIdx[1], ClampTileRotation(tTile[1].data[_TileRotation] + (tr[1] * 180) + (tr[1] == 1 && tTransIdx[1] == 4 ? 90 : 0)) / 90],
			//				tr[2] == -1 ? 0 : TransitionIdLookup[tTransIdx[2], ClampTileRotation(tTile[2].data[_TileRotation] + (tr[2] * 180) + (tr[2] == 1 && tTransIdx[2] == 4 ? 90 : 0)) / 90],
			//				tr[3] == -1 ? 0 : TransitionIdLookup[tTransIdx[3], ClampTileRotation(tTile[3].data[_TileRotation] + (tr[3] * 180) + (tr[3] == 1 && tTransIdx[3] == 4 ? 90 : 0)) / 90],
			//				tr[4] == -1 ? 0 : TransitionIdLookup[tTransIdx[4], ClampTileRotation(tTile[4].data[_TileRotation] + (tr[4] * 180) + (tr[4] == 1 && tTransIdx[4] == 4 ? 90 : 0)) / 90],
			//				tr[5] == -1 ? 0 : TransitionIdLookup[tTransIdx[5], ClampTileRotation(tTile[5].data[_TileRotation] + (tr[5] * 180) + (tr[5] == 1 && tTransIdx[5] == 4 ? 90 : 0)) / 90],
			//				tr[6] == -1 ? 0 : TransitionIdLookup[tTransIdx[6], ClampTileRotation(tTile[6].data[_TileRotation] + (tr[6] * 180) + (tr[6] == 1 && tTransIdx[6] == 4 ? 90 : 0)) / 90],
			//				tr[7] == -1 ? 0 : TransitionIdLookup[tTransIdx[7], ClampTileRotation(tTile[7].data[_TileRotation] + (tr[7] * 180) + (tr[7] == 1 && tTransIdx[7] == 4 ? 90 : 0)) / 90],
			//			};

			//if (dir == 1) Debug.Log(tr[4] + " => " + tId[4]);
			//if (dir == 1) Debug.Log(System.Convert.ToString(tId[7], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[0], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[4], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[3], 2).PadLeft(4, '0') + " ### " + System.Convert.ToString(tId[1], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[6], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[2], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[5], 2).PadLeft(4, '0') + "\n");

			// get tt, which represents the 4 corners touching the target tile. solid/reference (1) or the empty/transition (0)
			// tt[] starts at the BottomRight corner and goes anti-clockwise
			int[] tt = { 0, 0, 0, 0};

			if (dir == 0)
			{	// Top
				tt[0] = 1; tt[1] = 1; // can assume this to be full since it touches reference tile
				tt[2] = (tId[0] & b0100) + (tId[1] & b0001) + (tId[4] & b1000) > 0 ? 1 : 0; // Top-Right-TopRight
				tt[3] = (tId[0] & b1000) + (tId[3] & b0010) + (tId[7] & b0100) > 0 ? 1 : 0; // Top-Left-TopLeft
			}
			else if (dir == 1)
			{	// Right
				tt[0] = 1; tt[3] = 1; // can assume this to be full since it touches reference tile
				tt[1] = (tId[1] & b1000) + (tId[2] & b0010) + (tId[5] & b0001) > 0 ? 1 : 0; // Bottom-Right-BottomRight
				tt[2] = (tId[0] & b0100) + (tId[1] & b0001) + (tId[4] & b1000) > 0 ? 1 : 0; // Top-Right-TopRight
			}
			else if (dir == 2)
			{	// Bottom
				tt[2] = 1; tt[3] = 1; // can assume this to be full since it touches reference tile
				tt[0] = (tId[2] & b0001) + (tId[3] & b0100) + (tId[6] & b0010) > 0 ? 1 : 0; // Bottom-Left-BottomLeft
				tt[1] = (tId[1] & b1000) + (tId[2] & b0010) + (tId[5] & b0001) > 0 ? 1 : 0; // Bottom-Right-BottomRight
			}
			else if (dir == 3)
			{	// Left
				tt[1] = 1; tt[2] = 1; // can assume this to be full since it touches reference tile
				tt[0] = (tId[2] & b0001) + (tId[3] & b0100) + (tId[6] & b0010) > 0 ? 1 : 0; // Bottom-Left-BottomLeft
				tt[3] = (tId[0] & b1000) + (tId[3] & b0010) + (tId[7] & b0100) > 0 ? 1 : 0; // Top-Left-TopLeft
			}
			else if (dir == 4)
			{	// Top-Right
				tt[0] = 1; // can assume this to be full since it touches reference tile
				tt[1] = (tId[1] & b1000) + (tId[2] & b0010) + (tId[5] & b0001) > 0 ? 1 : 0; // Bottom-Right-BottomRight
				tt[2] = (tId[0] & b0100) + (tId[1] & b0001) + (tId[4] & b1000) > 0 ? 1 : 0; // Top-Right-TopRight
				tt[3] = (tId[0] & b1000) + (tId[3] & b0010) + (tId[7] & b0100) > 0 ? 1 : 0; // Top-Left-TopLeft
				//Debug.Log(gridPos + "\n" + System.Convert.ToString(tId[7], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[0], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[4], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[3], 2).PadLeft(4, '0') + " ### " + System.Convert.ToString(tId[1], 2).PadLeft(4, '0') + "\n" + System.Convert.ToString(tId[6], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[2], 2).PadLeft(4, '0') + " " + System.Convert.ToString(tId[5], 2).PadLeft(4, '0') + "\n");
			}
			else if (dir == 5)
			{	// Bottom-Right
				tt[3] = 1; // can assume this to be full since it touches reference tile
				tt[0] = (tId[2] & b0001) + (tId[3] & b0100) + (tId[6] & b0010) > 0 ? 1 : 0; // Bottom-Left-BottomLeft
				tt[1] = (tId[1] & b1000) + (tId[2] & b0010) + (tId[5] & b0001) > 0 ? 1 : 0; // Bottom-Right-BottomRight
				tt[2] = (tId[0] & b0100) + (tId[1] & b0001) + (tId[4] & b1000) > 0 ? 1 : 0; // Top-Right-TopRight
			}
			else if (dir == 6)
			{	// Bottom-Left
				tt[2] = 1; // can assume this to be full since it touches reference tile
				tt[0] = (tId[2] & b0001) + (tId[3] & b0100) + (tId[6] & b0010) > 0 ? 1 : 0; // Bottom-Left-BottomLeft
				tt[1] = (tId[1] & b1000) + (tId[2] & b0010) + (tId[5] & b0001) > 0 ? 1 : 0; // Bottom-Right-BottomRight
				tt[3] = (tId[0] & b1000) + (tId[3] & b0010) + (tId[7] & b0100) > 0 ? 1 : 0; // Top-Left-TopLeft
			}
			else if (dir == 7)
			{	// Top-Left
				tt[1] = 1; // can assume this to be full since it touches reference tile
				tt[0] = (tId[2] & b0001) + (tId[3] & b0100) + (tId[6] & b0010) > 0 ? 1 : 0; // Bottom-Left-BottomLeft
				tt[2] = (tId[0] & b0100) + (tId[1] & b0001) + (tId[4] & b1000) > 0 ? 1 : 0; // Top-Right-TopRight
				tt[3] = (tId[0] & b1000) + (tId[3] & b0010) + (tId[7] & b0100) > 0 ? 1 : 0; // Top-Left-TopLeft
			}

			// calculate id for transition to use
			int id = tt[0] + (2 * tt[1]) + (4 * tt[2]) + (8 * tt[3]);
			//if (dir == 0) Debug.Log(tt[3].ToString() + tt[2].ToString() + tt[1].ToString() + tt[0].ToString() + " = " + id.ToString());

			if (id == 15)
			{	// a solid do not need a transition
				tile = refSet.tiles[0];
				chosenRotation = 0;
				if (nonRot == false && canRandomRotate) chosenRotation = Random.Range(0, 4) * 90;
			}

			else
			{
				// check which set is most likely to be transition towards
				// this would be the test tile in the same direction as
				// target from reference or two neighbours for corners
				TileEdTransition transition = null;
				if (dir < 4)
				{
					// if the transition set of the test is the same as the ref set then it is probably a transition from 
					// test set to ref set. in that case, take the test's set ident and not its transition set ident
					transition = tTile[dir] == null ? null : refSet.FindTransition(tTile[dir].data[_TransitionSetIdent] == refSet.ident ? tTile[dir].data[_TileSetIdent] : tTile[dir].data[_TransitionSetIdent]);
				}
				else
				{
					int[] d = { dir - 4, dir - 3 }; if (d[1] == 4) d[1] = 0;
					// if the transition set of the test is the same as the ref set then it is probably a transition from 
					// test set to ref set. in that case, take the test's set ident and not its transition set ident
					transition = tTile[d[0]] == null ? null : refSet.FindTransition(tTile[d[0]].data[_TransitionSetIdent] ==refSet.ident ? tTile[d[0]].data[_TileSetIdent] : tTile[d[0]].data[_TransitionSetIdent]);
					if (transition == null && tTile[d[1]] != null) transition = refSet.FindTransition(tTile[d[1]].data[_TransitionSetIdent] == refSet.ident ? tTile[d[1]].data[_TileSetIdent] : tTile[d[1]].data[_TransitionSetIdent]);
				}

				if (transition != null)
				{
					if (nonRot)
					{
						tile = refSet.FindTile(transition.tileIdents[(TransitionIdMapping[id] * 4) + TransitionNoRotation[id]]);
						chosenRotation = 0;
					}
					else
					{
						// the transition id assumes a non-rotating set so now need to find correct transition id and rotation in a rotating set
						// original transition id runs from 1 to 14. Need to map this to 4 possible transition tiles and associated rotations
						tile = refSet.FindTile(transition.tileIdents[TransitionIdMapping[id]]);
						chosenRotation = TransitionRotations[id];
					}

				}
			}

			return tile;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region Paint Narrow Tiles

		private void HandleNarrowTileGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag)
		{
			bool startedUndo = isDrag; // allow new undo group only if mouse went down, not during a mouse drag

			#region place tiles(s)
			if (cursorMode == TileEdCursorMode.Normal)
			{
				if (startedUndo == false)
				{
					startedUndo = true;
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Paint Narrow Tile(s)");
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Paint Narrow Tile(s)");
				}

				int tileIdx, rot;
				List<TileEdMapTile> udpatedTiles = new List<TileEdMapTile>();
				for (int i = 0; i < gridPos.Length; i++)
				{
					IntVector3 pos = gridPos[i];
					CalcNarrowTileIdx(pos, asset.tileSets[tileSetIdx].ident, out tileIdx, out rot);
					if (tileIdx < 0) continue;
					rot = rot * 90;

					int chosenFabIdx = 0;
					if ((canRandomFab || canRandomFabAll) && asset.tileSets[tileSetIdx].tiles[tileIdx].prefab.Length > 1)
					{
						chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[tileIdx].prefab.Length);
						if (asset.tileSets[tileSetIdx].tiles[tileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
					}

					GameObject fab = asset.tileSets[tileSetIdx].tiles[tileIdx].prefab[chosenFabIdx];
					if (fab == null) continue; // is possible that no prefab was placed for this one
					
					TileEdMapTile oldTile = null;
					TileEdMapTile tile = GetTile(pos);
					if (tile != null)
					{
						// do not delete a tile which will not change (this will increase performance)
						// I will ignore the random tile in this case and just keep whatever the old tile used
						if (tile.data[_TileIdent] == asset.tileSets[tileSetIdx].tiles[tileIdx].ident && tile.gridPos == pos && tile.data[_TileRotation] == rot)
						{
							oldTile = tile;
						}
						else
						{
							RemoveTile(tile);
						}
					}

					// add tile to asset
					if (oldTile == null)
					{
						TileEdMapTile newTile = CreateTile("Paint Narrow Tile(s)", false, fab, pos, rot, asset.tileSets[tileSetIdx], asset.tileSets[tileSetIdx].tiles[tileIdx], chosenFabIdx, -1, -1);
						udpatedTiles.Add(newTile);
					}
					else
					{
						udpatedTiles.Add(oldTile);
					}
				}

				UpdateNarrowTilesAround(asset.tileSets[tileSetIdx], udpatedTiles, null);
			}
			#endregion

			#region delete tile(s)
			else if (cursorMode == TileEdCursorMode.Delete)
			{
				List<IntVector3> udpatedPositions = new List<IntVector3>();
				for (int i = 0; i < gridPos.Length; i++)
				{
					// first check if there is actually an entry of the tile since it will help determine if
					// what is in the scene is correct or not and save on unnecessary parentTr.Find()
					TileEdMapTile tile = GetTile(gridPos[i]);
					if (tile != null)
					{
						if (startedUndo == false)
						{
							startedUndo = true;
							Undo.IncrementCurrentGroup();
							Undo.SetCurrentGroupName("Remove Narrow Tile(s)");
							Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Remove Narrow Tile(s)");
						}

						RemoveTile(tile);
						udpatedPositions.Add(gridPos[i]);
					}
				}

				// update the tiles around the new empty tile
				UpdateNarrowTilesAround(asset.tileSets[tileSetIdx], null, udpatedPositions);
			}
			#endregion
		}

		private void UpdateNarrowTilesAround(TileEdTileSet refTileSet, List<TileEdMapTile> udpatedTiles, List<IntVector3> updatedPositions)
		{
			if (udpatedTiles != null)
			{
				List<IntVector3> touched = new List<IntVector3>();
				for (int j = 0; j < udpatedTiles.Count; j++)
				{
					TileEdMapTile refTile = udpatedTiles[j];
					IntVector3 refGridPos = refTile.gridPos;

					for (int dir = 0; dir < 8; dir++)
					{
						IntVector3 p = refGridPos + TileEd_Grid.Direction[dir];

						if (touched.Contains(p)) continue;
						touched.Add(p);

						TileEdMapTile oldTile = null;
						for (int i = 0; i < udpatedTiles.Count; i++)
							if (udpatedTiles[i].gridPos == p) { oldTile = udpatedTiles[i]; break; }
						if (oldTile == null) oldTile = GetTile(p);
						if (oldTile == null || oldTile.data[_TileSetIdent] != refTileSet.ident) continue;

						UpdateNarrowTile(p, refTileSet.ident, oldTile);
					}
				}
			}
			else
			{
				for (int j = 0; j < updatedPositions.Count; j++)
				{
					IntVector3 refGridPos = updatedPositions[j];
					List<IntVector3> touched = new List<IntVector3>();
					for (int dir = 0; dir < 8; dir++)
					{
						IntVector3 p = refGridPos + TileEd_Grid.Direction[dir];

						if (touched.Contains(p)) continue;
						touched.Add(p);

						TileEdMapTile oldTile = GetTile(p);
						if (oldTile == null || oldTile.data[_TileSetIdent] != refTileSet.ident) continue;

						UpdateNarrowTile(p, refTileSet.ident, oldTile);
					}
				}
			}
		}

		private void UpdateNarrowTile(IntVector3 pos, int tileSetIdent, TileEdMapTile oldTile)
		{
			int tileIdx, rot;
			CalcNarrowTileIdx(pos, tileSetIdent, out tileIdx, out rot);
			if (tileIdx < 0) return;
			rot = rot * 90;

			int chosenFabIdx = 0;
			if ((canRandomFab || canRandomFabAll) && asset.tileSets[tileSetIdx].tiles[tileIdx].prefab.Length > 1)
			{
				chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[tileIdx].prefab.Length);
				if (asset.tileSets[tileSetIdx].tiles[tileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
			}

			if (oldTile.data[_TileIdent] == tileIdx && oldTile.data[_TileRotation] == rot && oldTile.data[_TileFabIdx] == chosenFabIdx)
			{	// no need to replace, it is same
				return;
			}

			GameObject fab = asset.tileSets[tileSetIdx].tiles[tileIdx].prefab[chosenFabIdx];
			if (fab == null) return;

			RemoveTile(oldTile);
			CreateTile("Paint Narrow Tile(s)", false, fab, pos, rot, asset.tileSets[tileSetIdx], asset.tileSets[tileSetIdx].tiles[tileIdx], chosenFabIdx, -1, -1);
		}

		private void CalcNarrowTileIdx(IntVector3 pos, int tileSetIdent, out int tileIdx, out int tileRot)
		{
			tileIdx = 0;
			tileRot = 0;

			int[] neighbour_ids =
			{
				GetTileIdx(new IntVector3(pos.x + 0, pos.y, pos.z + 1), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x + 1, pos.y, pos.z + 1), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x + 1, pos.y, pos.z + 0), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x + 1, pos.y, pos.z - 1), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x + 0, pos.y, pos.z - 1), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x - 1, pos.y, pos.z - 1), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x - 1, pos.y, pos.z + 0), tileSetIdent) >= 0 ? 1 : 0,
				GetTileIdx(new IntVector3(pos.x - 1, pos.y, pos.z + 1), tileSetIdent) >= 0 ? 1 : 0,
			};

			int idx = (
				neighbour_ids[0] * 1 +
				neighbour_ids[1] * 2 * (neighbour_ids[0] * neighbour_ids[2]) +
				neighbour_ids[2] * 4 +
				neighbour_ids[3] * 8 * (neighbour_ids[2] * neighbour_ids[4]) +
				neighbour_ids[4] * 16 +
				neighbour_ids[5] * 32 * (neighbour_ids[4] * neighbour_ids[6]) +
				neighbour_ids[6] * 64 +
				neighbour_ids[7] * 128 * (neighbour_ids[6] * neighbour_ids[0])
			);

			int[] mapped;
			if (NarrowTileMap.TryGetValue(idx, out mapped))
			{
				tileIdx = mapped[0];
				tileRot = mapped[1];
			}
			else
			{
				Debug.LogError("Missing narrow tile mapping from: " + idx);
			}
		}

		private static readonly Dictionary<int, int[]> NarrowTileMap = new Dictionary<int, int[]>()
		{
			{ 0,   new int[]{ 1,  0 } }, // 0
			{ 1,   new int[]{ 9,  3 } }, // 1 
			{ 4,   new int[]{ 9,  0 } }, // 2
			{ 16,  new int[]{ 9,  1 } }, // 3
			{ 64,  new int[]{ 9,  2 } }, // 4
			{ 5,   new int[]{ 7,  0 } }, // 5
			{ 20,  new int[]{ 7,  1 } }, // 6
			{ 80,  new int[]{ 7,  2 } }, // 7
			{ 65,  new int[]{ 7,  3 } }, // 8
			{ 7,   new int[]{ 6,  0 } }, // 9
			{ 28,  new int[]{ 6,  1 } }, // 10
			{ 112, new int[]{ 6,  2 } }, // 11
			{ 193, new int[]{ 6,  3 } }, // 12
			{ 17,  new int[]{ 8,  3 } }, // 13
			{ 68,  new int[]{ 8,  2 } }, // 14
			{ 21,  new int[]{ 5,  1 } }, // 15
			{ 84,  new int[]{ 5,  2 } }, // 16
			{ 81,  new int[]{ 5,  3 } }, // 17
			{ 69,  new int[]{ 5,  0 } }, // 18
			{ 23,  new int[]{ 4,  1 } }, // 19
			{ 92,  new int[]{ 4,  2 } }, // 20
			{ 113, new int[]{ 4,  3 } }, // 21
			{ 197, new int[]{ 4,  0 } }, // 22
			{ 29,  new int[]{ 3,  1 } }, // 23
			{ 116, new int[]{ 3,  2 } }, // 24
			{ 209, new int[]{ 3,  3 } }, // 25
			{ 71,  new int[]{ 3,  0 } }, // 26
			{ 31,  new int[]{ 2,  1 } }, // 27
			{ 124, new int[]{ 2,  2 } }, // 28
			{ 241, new int[]{ 2,  3 } }, // 29
			{ 199, new int[]{ 2,  0 } }, // 30
			{ 85,  new int[]{ 10, 2 } }, // 31
			{ 87,  new int[]{ 11, 1 } }, // 32
			{ 93,  new int[]{ 11, 2 } }, // 33
			{ 117, new int[]{ 11, 3 } }, // 34
			{ 213, new int[]{ 11, 0 } }, // 35
			{ 95,  new int[]{ 13, 1 } }, // 36
			{ 125, new int[]{ 13, 2 } }, // 37
			{ 245, new int[]{ 13, 3 } }, // 38
			{ 215, new int[]{ 13, 0 } }, // 39
			{ 119, new int[]{ 12, 3 } }, // 40
			{ 221, new int[]{ 12, 2 } }, // 41
			{ 127, new int[]{ 14, 2 } }, // 42
			{ 253, new int[]{ 14, 3 } }, // 43
			{ 247, new int[]{ 14, 0 } }, // 44
			{ 223, new int[]{ 14, 1 } }, // 45
			{ 255, new int[]{ 0,  0 } }, // 46
		};

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region selection tools and copy buffer

		private void ClearSelection()
		{
			wasClickOnSelected = false;
			if (selection.Count > 0)
			{
				selection.Clear();
				TileEdGUI.ClearSelectionMarkers();
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		private void ClearCopyBuffer()
		{
			if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
			{
				TileEd.grid.cursorMode = TileEdCursorMode.Normal;
				TileEd.grid.UpdatePreviewObject(null, 0);
			}

			GC_CopyBuffer.text = Ico._wait;
			GC_CopyBuffer.image = null;
			copyBuffer.texture = null; // do not call DestroyImmediate() on this one
			if (copyBuffer.prefab != null) Object.DestroyImmediate(copyBuffer.prefab, true);
			copyBuffer.tiles.Clear();
		}

		private void CutSelection()
		{
			CopySelection(false);
			DeleteSelection();
		}

		private void DuplicateSelection()
		{
			CopySelection(true);
			EnterPasteMode();
		}

		private void CopySelection(bool doClearSel)
		{
			// destroy old buffer data
			ClearCopyBuffer();

			// create the template
			IntVector3 offs = new IntVector3(999999, 999999, 999999);
			for (int i = 0; i < selection.Count; i++)
			{
				//TileEdMapTile tile = TileEd.Instance.group.GetTile(TOOL_IDENT, selection[i].gridPos);
				//if (tile == null) continue;

				TileEdMapTile tile = selection[i].tile;
				copyBuffer.tiles.Add(tile.Copy());

				if (selection[i].gridPos.x < offs.x) offs.x = selection[i].gridPos.x;
				if (selection[i].gridPos.y < offs.y) offs.y = selection[i].gridPos.y;
				if (selection[i].gridPos.z < offs.z) offs.z = selection[i].gridPos.z;
			}
			
			if (doClearSel) ClearSelection();

			// create the preview prefab
			if (copyBuffer.tiles.Count > 0)
			{
				GameObject templatePreviewGo = new GameObject("copy_buffer_preview");
				templatePreviewGo.hideFlags = HideFlags.HideAndDontSave;

				for (int i = 0; i < copyBuffer.tiles.Count; i++)
				{
					copyBuffer.tiles[i].gridPos -= offs;

					TileEdTileSet tset = asset.FindTileSet(copyBuffer.tiles[i].data[_TileSetIdent]);
					if (tset == null) continue;
					TileEdTile t = tset.FindTile(copyBuffer.tiles[i].data[_TileIdent]);
					int fabIdx = copyBuffer.tiles[i].data[_TileFabIdx];
					if (t == null || t.prefab[fabIdx] == null) continue;

					// if the wall system is a Dungeon type then the walls need to be rotated
					int rot = copyBuffer.tiles[i].data[_TileRotation];
					if (tset.wallSystem == TileEdTileSet.WallPivot.Dungeon && t.transitionIdx < 0 && TileIsSimple(tset, t) == false) rot += 180;

					GameObject go = GameObject.Instantiate(t.prefab[fabIdx]);
					go.hideFlags = HideFlags.HideAndDontSave;
					go.name = copyBuffer.tiles[i].gridPos.ToString();
					go.transform.parent = templatePreviewGo.transform;
					go.transform.position = new Vector3(
						copyBuffer.tiles[i].gridPos.x * TileEd.Instance.group.tileSize,
						copyBuffer.tiles[i].gridPos.y * TileEd.Instance.group.tileHeight,
						copyBuffer.tiles[i].gridPos.z * TileEd.Instance.group.tileSize);
					go.transform.rotation = Quaternion.Euler(0f, rot, 0f);
					plyEdUtil.HideWireframes(go);
					plyEdUtil.SetStaticEditorFlagsRecursive(go, 0, 1);
				}
				

				plyEdUtil.CheckPath(TileEdGlobal.TEMP_PATH);
				copyBuffer.prefab = plyEdUtil.CreatePrefabFromPrefab(templatePreviewGo, TileEdGlobal.TEMP_PATH + "copy_buffer_preview.prefab");
				Object.DestroyImmediate(templatePreviewGo);
			}

			plyEdUtil.RepaintInspector(typeof(TileEd));
		}

		private void DeleteSelection()
		{
			bool startedUndo = false;
			for (int i = 0; i < selection.Count; i++)
			{
				if (startedUndo == false)
				{
					startedUndo = true;
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Remove Tile(s)");
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Remove Tile(s)");
				}

				// remove from asset
				selection[i].group.RemoveTile(selection[i].tile);

				// remove from scene
				if (selection[i].mainGo != null) Undo.DestroyObjectImmediate(selection[i].mainGo);
			}

			//if (startedUndo)
			//{
				//plyEdUtil.SetDirty(TileEd.Instance.map);
			//}

			ClearSelection();
		}

		private void EnterPasteMode()
		{
			if (copyBuffer.tiles.Count > 0)
			{
				ClearSelection();
				currTileIdx = -1;
				currTileIsSimple = true;
				TileEd.grid.cursorMode = TileEdCursorMode.Paste;
				TileEd.grid.UpdatePreviewObject(copyBuffer.prefab, tileRotation);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		private void ClearPasteMode()
		{
			TileEd.grid.ClearPasteMode();
		}

		private void PasteFromCopyBuffer(IntVector3 pos)
		{
			bool startedUndo = false;

			for (int i = 0; i < copyBuffer.tiles.Count; i++)
			{
				TileEdMapTile placeTile = copyBuffer.tiles[i];
				IntVector3 p = placeTile.gridPos;

				if (tileRotation == 90)
				{
					p.x = placeTile.gridPos.z;
					p.z = -placeTile.gridPos.x;
				}
				else if (tileRotation == 180)
				{
					p.x = -placeTile.gridPos.x;
					p.z = -placeTile.gridPos.z;
				}
				else if (tileRotation == 270)
				{
					p.x = -placeTile.gridPos.z;
					p.z = placeTile.gridPos.x;
				}

				IntVector3 gridPos = pos + p;
				int[] data = new int[placeTile.data.Length];
				for (int dIdx=0; dIdx < data.Length; dIdx++) data[dIdx] = placeTile.data[dIdx];
				data[_TileRotation] = ClampTileRotation(placeTile.data[_TileRotation] + tileRotation);

				TileEdMapTile tile = GetTile(gridPos); // TileEd.Instance.group.GetTile(TOOL_IDENT, gridPos);
				TileEdTileSet tset = asset.FindTileSet(data[_TileSetIdent]);
				if (tset == null) continue;
				TileEdTile t = tset.FindTile(data[_TileIdent]);
				if (t == null || t.prefab[data[_TileFabIdx]] == null) continue;

				if (startedUndo == false)
				{
					startedUndo = true;
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Paste Tile(s)");
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "Paste Tile(s)");
				}

				// delete the old tile from asset and scene
				if (tile != null)
				{
					RemoveTile(tile);
				}

				// add tile to asset
				CreateTile("Paste Tiles", TileIsSimple(tset, t), t.prefab[data[_TileFabIdx]], gridPos, data[_TileRotation], tset, t, data[_TileFabIdx], data[_TransitionSetIdent], data[_TransitionIdx]);

			}

			//if (startedUndo)
			//{
				//plyEdUtil.SetDirty(TileEd.Instance.map);
			//}
			
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region workers

		private void RemoveTile(TileEdMapTile tile)
		{
			TileEd.Instance.group.RemoveTile(tile);
			Transform tr = parentTr.Find(tile.gridPos.ToString());
			if (tr != null) Undo.DestroyObjectImmediate(tr.gameObject);

		}

		private GameObject GetTileGo(TileEdMapTile tile)
		{
			//return tile.cachedTileObject ?? parentTr.Find(gridPos[i].ToString())?.gameObject;
			return parentTr.Find(tile.gridPos.ToString())?.gameObject;
		}

		private TileEdMapTile GetTile(IntVector3 pos)
		{			
			return TileEd.Instance.group.GetTile(TOOL_IDENT, pos);
		}

		private int GetTileIdx(IntVector3 pos, int limitToTileSet)
		{
			TileEdMapTile t = TileEd.Instance.group.GetTile(TOOL_IDENT, pos);
			if (t != null && t.data[_TileSetIdent] == limitToTileSet) return t.data[_TileIdx];
			return -1;
		}

		private TileEdMapTile[] GetTiles(IntVector3[] pos)
		{
			return TileEd.Instance.group.GetTiles(TOOL_IDENT, pos);
		}

		private List<TileEdMapTile> GetTilesXZ(IntVector3 pos, int depthAbove, int depthBelow)
		{
			return TileEd.Instance.group.GetTilesXZ(TOOL_IDENT, pos, depthAbove, depthBelow);
		}

		private bool LoadAsset()
		{
			canRandomRotate = EditorPrefs.GetBool("TileEd.Tiles.canRandomRotate", canRandomRotate);
			canRandomFab = EditorPrefs.GetBool("TileEd.Tiles.canRandomFab", canRandomFab);
			canRandomFabAll = EditorPrefs.GetBool("TileEd.Tiles.canRandomFabAll", canRandomFabAll);
			canSculpt = EditorPrefs.GetBool("TileEd.Tiles.canSculpt", canSculpt);
			showTileSettings = EditorPrefs.GetBool("TileEd.Tiles.showSettings", showTileSettings); 

			if (asset == null)
			{
				plyEdUtil.CheckPath(TileEdGlobal.DATA_PATH);
				asset = plyEdUtil.LoadOrCreateAsset<TileEdTileSetsAsset>(TileEdGlobal.DATA_PATH + ASSET_NAME);
				if (asset == null)
				{
					GUILayout.Label("Error: Could not load the Tiles asset.");
					return false;
				}
			}

			if (tmplAsset == null)
			{
				plyEdUtil.CheckPath(TileEdGlobal.DATA_PATH);
				tmplAsset = plyEdUtil.LoadOrCreateAsset<TileEdTemplatesAsset>(TileEdGlobal.DATA_PATH + TMPLT_NAME);
				if (tmplAsset == null)
				{
					GUILayout.Label("Error: Could not load the Tile Templates asset.");
					return false;
				}
			}

			return true;
		}

		private void EraseAllTilesFromActiveGroup()
		{
			ClearUndo();

			if (parentTr == null && TileEd.Instance.group != null)
			{	// it might happen that this is null
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr == null) return;
				string groupIdent = TileEd.Instance.group.ident.ToString();
				parentTr = tr.Find(groupIdent);
				if (parentTr == null) return;
			}

			if (parentTr.childCount > 0)
			{
				// remove from asset
				TileEd.Instance.group.RemoveAllTiles(TOOL_IDENT);

				// remove from scene
				for (int i = parentTr.childCount - 1; i >= 0; i--)
				{
					Object.DestroyImmediate(parentTr.GetChild(i).gameObject);
				}

				plyEdUtil.SetDirty(TileEd.Instance.map);
			}
		}

		private void ClearUndo()
		{
			Undo.ClearUndo(TileEd.Instance.map);
		}

		private int ClampTileRotation(int rot)
		{
			if (rot < 0) rot += 360;
			else if (rot >= 360) rot -= 360;
			return rot;
		}

		private void DrawPreview(Event ev, GameObject obj, int size)
		{
			Rect r = GUILayoutUtility.GetRect(size, size, GUILayout.Width(size), GUILayout.Height(size));
			if (ev.type == EventType.Repaint)
			{
				if (obj != null)
				{
					Texture2D tex = AssetPreview.GetAssetPreview(obj);
					if (tex == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
					else GUI.Box(r, tex, TileEdGUI.Styles.TilePreview);
				}
				else
				{
					GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TilePreview);
				}
			}
		}

		private bool TileIsSimple(TileEdTileSet tset, TileEdTile tile)
		{
			if (tset.type != TileEdTileSet.Type.Simple)
			{
				// find out of the tile is part of the auto-tile set or extra tiles added as simple tiles
				if (tile.transitionIdx >= 0) return false; // transitions are not simple tiles
				else
				{
					if (tset.type == TileEdTileSet.Type.Auto)
					{
						if (tile.tileIdx >= 0)
						{
							if (tset.autoType == TileEdTileSet.AutoType.Rotating && tile.tileIdx <= 4) return false;
							else if (tset.autoType == TileEdTileSet.AutoType.Directional && tile.tileIdx <= 16) return false;
						}
					}
				}
			}

			return true;
		}

		private TileEdMapTile CreateTile(string canUndo, bool isSimpleTile, GameObject fab, IntVector3 pos, int rot, TileEdTileSet tileSet, TileEdTile tileDef, int fabIdx, int transSetIdent, int transIdx)
		{
			TileEdMapTile newTile = new TileEdMapTile()
			{
				toolIdent = TOOL_IDENT,
				gridPos = pos,
				data = new int[_MaxTileProperties]
			};

			newTile.data[_TileSetIdent] = tileSet.ident;
			newTile.data[_TileIdent] = tileDef.ident;
			newTile.data[_TileIdx] = tileDef.tileIdx;
			newTile.data[_TileRotation] = rot;
			newTile.data[_TileFabIdx] = fabIdx;
			newTile.data[_TransitionSetIdent] = transSetIdent;
			newTile.data[_TransitionIdx] = tileDef.transitionIdx; // transIdx;
			newTile.data[_IsRotating] = tileDef.isRotating;
			newTile.meta = tileDef.meta;

			//TileEd.Instance.group.tiles.Add(newTile);
			TileEd.Instance.group.AddTile(newTile);

			// create the tile in scene
			//newTile.cachedTileObject = CreateTileObject(canUndo, parentTr, fab, pos, rot, tileSet, tileDef, isSimpleTile, TileEd.Instance.group.tileSize, TileEd.Instance.group.tileHeight);
			GameObject go = CreateTileObject(canUndo, parentTr, fab, pos, rot, tileSet, tileDef, isSimpleTile, TileEd.Instance.group.tileSize, TileEd.Instance.group.tileHeight);

			if (onPlacedTile != null)
			{
				onPlacedTile.Invoke(new PlacedTileInfo()
				{
					go = go,
					tile = newTile,
					group = TileEd.Instance.group
				});
			}

			return newTile;
		}

		private GameObject CreateTileObject(string canUndo, Transform parent, GameObject fab, IntVector3 pos, int rot, TileEdTileSet tileSet, TileEdTile tileDef, bool isSimplePlacement, float tileSize, float tileHeight)
		{
			// create the tile in scene. note that it is possible to add an empty tile so 1st check if fab is set.
			if (fab == null) return null;

			// if the wall system is a Dungeon type then the walls need to be rotated
			if (tileSet.wallSystem == TileEdTileSet.WallPivot.Dungeon && tileDef.transitionIdx < 0 && false == isSimplePlacement) rot += 180;

			//GameObject go = GameObject.Instantiate(fab);
			GameObject go = (GameObject)PrefabUtility.InstantiatePrefab(fab);
			if (canUndo!=null) Undo.RegisterCreatedObjectUndo(go, canUndo);
			go.name = pos.ToString();
			go.transform.parent = parent;
			go.transform.position = new Vector3(pos.x * tileSize, pos.y * tileHeight, pos.z * tileSize);
			go.transform.rotation = Quaternion.Euler(0f, rot, 0f);
			plyEdUtil.HideWireframes(go);

			if (TileEd.Instance.group.centreTiles == false)
			{
				float offs = -TileEd.Instance.group.tileSize / 2f;
				go.transform.position += new Vector3(offs, 0f, offs);				
			}

			if (TileIsSimple(tileSet, tileDef))
			{
				if (tileDef.setTag) plyEdUtil.SetTagRecursive(go, tileDef.tag);
				
				if (tileDef.setLayer) plyEdUtil.SetLayerRecursive(go, tileDef.layer);

				if (tileDef.setSort) TileEd.SetObjectSortOrder(go, tileDef.sortLayerId, tileDef.sortOrder);

				if (tileDef.setStaticFlags && tileDef.setNavArea) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileDef.staticFlags, tileDef.navArea);
				else if (tileDef.setStaticFlags) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileDef.staticFlags);
				else if (tileDef.setNavArea) plyEdUtil.SetNavAreaRecursive(go, tileDef.navArea);
			}
			else
			{
				if (tileDef.tileIdx == 0 || tileDef.transitionIdx >= 0)
				{	// floor
					if (tileSet.setTag) plyEdUtil.SetTagRecursive(go, tileSet.floorTag);

					if (tileSet.setLayer) plyEdUtil.SetLayerRecursive(go, tileSet.floorLayer);

					if (tileSet.setSort) TileEd.SetObjectSortOrder(go, tileSet.floorSortLayeId, tileSet.floorSortOrder);

					if (tileSet.setStaticFlags && tileSet.setNavArea) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileSet.floorStaticFlags, tileSet.floorNavArea);
					else if (tileSet.setStaticFlags) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileSet.floorStaticFlags);
					else if (tileSet.setNavArea) plyEdUtil.SetNavAreaRecursive(go, tileSet.floorNavArea);
				}
				else
				{	// wall
					if (tileSet.setTag) plyEdUtil.SetTagRecursive(go, tileSet.wallTag);

					if (tileSet.setLayer) plyEdUtil.SetLayerRecursive(go, tileSet.wallLayer);

					if (tileSet.setSort) TileEd.SetObjectSortOrder(go, tileSet.wallSortLayeId, tileSet.wallSortOrder);

					if (tileSet.setStaticFlags && tileSet.setNavArea) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileSet.wallStaticFlags, tileSet.wallNavArea);
					else if (tileSet.setStaticFlags) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)tileSet.wallStaticFlags);
					else if (tileSet.setNavArea) plyEdUtil.SetNavAreaRecursive(go, tileSet.wallNavArea);
				}
			}

			return go;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
