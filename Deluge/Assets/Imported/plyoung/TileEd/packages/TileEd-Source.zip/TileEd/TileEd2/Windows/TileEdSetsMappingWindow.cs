﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using plyLib;
using plyLibEditor;


namespace TileEd
{
	public class TileEdSetsMappingWindow : EditorWindow
	{
		// ------------------------------------------------------------------------------------------------------------

		private static readonly string MSG = "Make a backup of your project or create a duplicate map before using this feature. Choose which Tile and Prop sets should be replaced in the map. The sets on the Left will be replaced with those chosen on the Right. The Tile and Prop sets must match exactly in number of and position of tiles and props and type of set it is else tiles/ props which does not match up will be skipped or unexpected errors might occur.";
		private static readonly GUIContent GC_CancelButton = new GUIContent("Close");
		private static readonly GUIContent GC_ApplyButton = new GUIContent("Apply");

		[System.NonSerialized] public System.Action<TileEdSetsMappingWindow> callback;
		[System.NonSerialized] public bool forceRecreate;
		[System.NonSerialized] public bool wasCancel = false;
		[System.NonSerialized] public List<List<TileEd_Ed_Base.TileSetInfo>> sets = null;
		[System.NonSerialized] public List<int[]> setsMapping = null;

		[System.NonSerialized] private Vector2 scroll = Vector2.zero;
		[System.NonSerialized] private List<string[]> setsNames = null;

		// ------------------------------------------------------------------------------------------------------------

		public static void Show_TileEdSetsMappingWindow(System.Action<TileEdSetsMappingWindow> callback, bool forceRecreate)
		{
			TileEdSetsMappingWindow win = EditorWindow.GetWindow<TileEdSetsMappingWindow>(true, "Tile & Prop Mapping", true);
			win.callback = callback;
			win.forceRecreate = forceRecreate;
			win.minSize = new Vector2(430, 400);
			win.ShowUtility();
		}

		protected void OnEnable()
		{
			minSize = new Vector2(430, 400);

			sets = new List<List<TileEd_Ed_Base.TileSetInfo>>();
			setsNames = new List<string[]>();
			setsMapping = new List<int[]>();

			for (int edIdx = 0; edIdx < TileEdGlobal.editors.Count; edIdx++)
			{
				List<TileEd_Ed_Base.TileSetInfo> set = TileEdGlobal.editors[edIdx].ed.GetTileSets();
				if (set.Count == 0) continue;

				string[] names = new string[set.Count];
				int[] ids = new int[set.Count];
				for (int i = 0; i < set.Count; i++)
				{
					names[i] = set[i].setName;
					ids[i] = i;
				}
				sets.Add(set);
				setsNames.Add(names);
				setsMapping.Add(ids);
			}

		}

		protected void OnDestroy()
		{
			wasCancel = true;
			callback(this);
		}

		protected void OnFocus()
		{
		}

		protected void OnGUI()
		{
			scroll = EditorGUILayout.BeginScrollView(scroll);
			{
				GUILayout.Label(MSG, plyEdGUI.Styles.WordWrappedLabel);

				for (int setsIdx = 0; setsIdx < sets.Count; setsIdx++)
				{
					List<TileEd_Ed_Base.TileSetInfo> set = sets[setsIdx];
					EditorGUILayout.Space();
					if (set[0].toolIdent == 1) GUILayout.Label("Tile Sets", EditorStyles.boldLabel);
					else if (set[0].toolIdent == 2) GUILayout.Label("Prop Sets", EditorStyles.boldLabel);
					else GUILayout.Label("Custom Sets", EditorStyles.boldLabel);

					for (int i = 0; i < set.Count; i++)
					{
						setsMapping[setsIdx][i] = EditorGUILayout.Popup(set[i].setName + " => ", setsMapping[setsIdx][i], setsNames[setsIdx]);
					}
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndScrollView();

			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.BottomBar);
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button(GC_ApplyButton, GUILayout.MinWidth(60))) { callback(this); }
				if (GUILayout.Button(GC_CancelButton, GUILayout.MinWidth(60))) { Close(); }
				EditorGUILayout.Space();
			}
			EditorGUILayout.EndHorizontal();
		}		

		// ------------------------------------------------------------------------------------------------------------
	}
}
