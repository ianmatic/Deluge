﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdProp
	{
		public int ident;								// this ident is unique among props of same and different props-sets
		public GameObject[] prefab = new GameObject[1]; // 0: is the main, any additional are for random model selection

		public bool setTag = false;
		public string tag = "Untagged";

		public bool setLayer = false;
		public int layer = 0;

		public bool setStaticFlags = false;
		public int staticFlags = -1; //public StaticEditorFlags staticFlags = (StaticEditorFlags)(-1);

		public bool setNavArea = false;
		public int navArea = 1;

		public bool setSort = false;
		public int sortLayerId = 0;
		public int sortOrder = 0;

		public Texture2D customThumb;
		public string meta; // extra data that can be associated with this prop

		// ------------------------------------------------------------------------------------------------------------
    }
}
