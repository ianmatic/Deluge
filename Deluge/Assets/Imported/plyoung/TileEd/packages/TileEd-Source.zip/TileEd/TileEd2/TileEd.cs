﻿//#define DEBUG
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using plyLib;
using plyLibEditor;
using System.Reflection;

namespace TileEd
{
	[CustomEditor(typeof(TileEdMap))]
	public class TileEd : Editor
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private static readonly GUIContent GC_GroupNotVisible = new GUIContent("Tool not available for Tile Layer that is not visible");
		private static readonly GUIContent GC_GroupCombined = new GUIContent("Tool not available for Tile Layer that is combined");
		private static readonly GUIContent GC_RecreateMap = new GUIContent(Ico._grid + " Recreate", "Recreate the map from TileEd Map data");
		private static readonly GUIContent GC_CombineMap = new GUIContent(Ico._square_dotted + " Combine", "Combine tiles objects into fewer objects");
		private static readonly GUIContent GC_ReplaceTileSet = new GUIContent(Ico._cube + " Duplicate or Replace", "This option allows you to duplicate the map into a new TileEd asset file and also to choose new TileSet(s) for this duplicate");
		private static readonly GUIContent GC_ToggleTileEd = new GUIContent(Ico._radio_button_checked, "Turn TileEd mode off");
		private static readonly GUIContent GC_GroupListHead = new GUIContent("Tile Layers");
		//private static readonly GUIContent GC_Visible = new GUIContent(Ico._visible, "This Tile Layer is visible");
		//private static readonly GUIContent GC_Hidden = new GUIContent(Ico._hidden, "This Tile Layer is hidden");
		//private static readonly GUIContent GC_Combined = new GUIContent(Ico._grid_off, "This Tile Layer is combined. Use this button to remove combined meshes and recreate the Tile Layer from TileEd map data");
		//private static readonly GUIContent GC_RecreateGroup = new GUIContent(Ico._refresh, "Recreate Tile Layer from TileEd map data");
		private static readonly GUIContent GC_YPos = new GUIContent(Ico._swap_vert + "Grid", "Current Y position of the grid [Ctrl+Shift+ScrollWheel]");
		private static readonly GUIContent GC_TilePreviewVisible = new GUIContent(Ico._visible, "Show the tile preview in the scene?");
		private static readonly GUIContent GC_TilePreviewHidden = new GUIContent(Ico._hidden, "Show the tile preview in the scene?");
		private static readonly GUIContent[] GC_Brush = new GUIContent[] { new GUIContent(Ico._brush, "Brush Size [Ctrl+ScrollWheel]"), new GUIContent(Ico._eraser, "Brush Size [Alt+ScrollWheel]"), new GUIContent(Ico._marquee, "Brush Size [Alt+ScrollWheel]"), new GUIContent(Ico._paste, "Brush Size [Alt+ScrollWheel]") };
		private static readonly GUIContent[] GC_Mode = new GUIContent[] { new GUIContent("Paint Mode"), new GUIContent("Remove Mode"), new GUIContent("Mark Mode"), new GUIContent("Paste mode") };
		private static readonly GUIContent[] GC_MainTabs = new GUIContent[] { new GUIContent("Tile Layers"), new GUIContent("Map Tools"), new GUIContent(Ico._settings + " Settings", "Open settings and Tile Set editor") };
		private static readonly GUIContent GC_Loading = new GUIContent("loading");
		private static readonly GUIContent GC_MapIdent = new GUIContent("Map ident", "This is the unique identifier of this map. It is the same as the asset file found under `Assets/projectData/TileEd/Maps/`");

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public static TileEd Instance { get; private set; }

		/// <summary> A reference to the component on the currently selected map object. It only contains the ident of the map. </summary>
		public TileEdMap mapObj;

		/// <summary> Reference to the transform of the currently selected map object. </summary>
		public Transform mapTr;

		/// <summary> Reference to the map data (asset file) of the currently selected map. </summary>
		public TileEdMapAsset map;

		/// <summary> The index (into list of groups) of the currently selected Tile Layer/ Group (as seen in the Inspector). 
		/// Static so that the active group is kept when switching away and back to map (will update group property in OnEnable) </summary>
		public static int activeGroupIdx = 0;

		/// <summary> Reference to the currently selected Tile Layer/ Group (as seen in the Inspector). </summary>
		public TileEdMapGroup group;

		/// <summary> Reference to the TileEd grid. It does various things like drawing the grid, preview object and handing clicks. </summary>
		public static TileEd_Grid grid = new TileEd_Grid();

		/// <summary> True while TileEd tools are building their caches. Do not do anything until this is done. </summary>
		public bool buildingCache { get; private set; }

		public static bool wasMapDuplication = false;

		private int selectedMainArea = 0;
		private int selectedMainAreaPrev = 0;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		protected void OnEnable()
		{
			buildingCache = false;
			Instance = this;
			mapObj = target as TileEdMap;
			mapTr = mapObj.transform;

			if (map == null)
			{
				map = plyEdUtil.LoadAsset<TileEdMapAsset>(TileEdGlobal.MAPS_PATH + mapObj.ident + ".asset");
				if (map == null)
				{
					EditorUtility.DisplayDialog("TileEd", "The Selected object is a TileEd Map but the associated map asset could not be found. Either restore the asset or remove the TileEdMap component from this object.", "OK");
					Debug.LogError("[TileEd] The Selected object is a TileEd Map but the associated map asset could not be found. Either restore the asset or remove the TileEdMap Component from this object.", target);
					return;
				}
			}

			if (map.groups.Count > 0)
			{
				if (activeGroupIdx >= map.groups.Count) activeGroupIdx = 0;
				group = map.groups[activeGroupIdx];
			}
			else
			{
				group = null;
				activeGroupIdx = -1;
			}

			if (TileEdGlobal.autoDisableSceneGrid)
			{
				plyEdUtil.Gizmos_ShowGrid = (TileEdGlobal.permaOffSceneGrid ? false : !TileEdGlobal.edModeOn);
			}

			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnPalleteFocus();
			}

			//// hide wireframes
			//plyEdUtil.HideWireframes(mapObj.gameObject);

			// disable the selection outline/ wire
			plyEdUtil.Gizmos_ShowSelectionOutline = false;
			plyEdUtil.Gizmos_ShowSelectionWire = false;

			//// build caches
			// - not used since it causes problems with undo system
			//if (map.mapObjectCache == null)
			//{
			//	buildingCache = true;
			//	// inform all editors that a new map was opened				
			//	for (int i = 0; i < TileEdGlobal.editors.Count; i++)
			//	{
			//		TileEdGlobal.editors[i].ed.DoCacheMap();
			//	}
			//}

			// check if inspector was activated during a map duplication
			if (wasMapDuplication)
			{   // reset flag and move on to next step
				wasMapDuplication = false;
				TileEdSetsMappingWindow.Show_TileEdSetsMappingWindow(OnChooseTileSetReplacements, true);
			}

		}

		protected void OnDisable()
		{
			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnPalleteLooseFocus();
			}

			grid.UpdatePreviewObject(null, 0f);
			Instance = null;

			if (TileEdGlobal.autoDisableSceneGrid)
			{
				plyEdUtil.Gizmos_ShowGrid = (TileEdGlobal.permaOffSceneGrid ? false : true);
			}

			plyEdUtil.Gizmos_ShowSelectionOutline = true;
			plyEdUtil.Gizmos_ShowSelectionWire = true;
		}

		protected void OnDestroy()
		{
			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnPalleteLooseFocus();
			}

			grid.UpdatePreviewObject(null, 0f);
			Instance = null;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region inspector

		public override void OnInspectorGUI()
		{
			if (map == null || EditorApplication.isPlayingOrWillChangePlaymode) return;

			if (buildingCache)
			{
				bool buildingCache_change = false;
				for (int i = 0; i < TileEdGlobal.editors.Count; i++)
				{
					TileEdGlobal.editors[i].ed.DoCacheLoopUpdate();
					if (TileEdGlobal.editors[i].ed.buildingCache) buildingCache_change = true;
				}

				if (Event.current.type == EventType.Repaint)
				{
					buildingCache = buildingCache_change;
				}

				if (!buildingCache_change)
				{
					map.mapObjectCache = mapObj;
				}

				EditorGUILayout.Space();
				plyEdGUI.DrawSpinner(GC_Loading, true, true);
				Repaint();
				return;
			}

			EditorGUILayout.Space();
			selectedMainAreaPrev = selectedMainArea;

			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				if (GUILayout.Toggle(selectedMainArea == 0, GC_MainTabs[0], plyEdGUI.Styles.ToolbarButton)) selectedMainArea = 0;
				if (GUILayout.Toggle(selectedMainArea == 1, GC_MainTabs[1], plyEdGUI.Styles.ToolbarButton)) selectedMainArea = 1;

				TileEdGlobal.activeTileEdToolIdx = EditorGUILayout.Popup(TileEdGlobal.activeTileEdToolIdx, TileEdGlobal.GC_Editors, plyEdGUI.Styles.ToolbarPopup);

				GUILayout.FlexibleSpace();
				if (GUILayout.Button(GC_MainTabs[2], plyEdGUI.Styles.ToolbarButton)) TileEd_Settings.Show_Window();
			}
			EditorGUILayout.EndHorizontal();

			if (selectedMainArea == 0)
			{
				DrawLayers();

				if (TileEdGlobal.activeTileEdToolIdx >= 0)
				{
					if (!TileEd.Instance.group.visible)
					{
						EditorGUILayout.Space();
						GUILayout.Label(GC_GroupNotVisible);
					}
					else if (TileEd.Instance.group.combined && TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.CanGroupCombine())
					{
						EditorGUILayout.Space();
						GUILayout.Label(GC_GroupCombined);
					}
					else
					{
						TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnInspector(this);
					}
				}
			}
			else if (selectedMainArea == 1)
			{
				DrawMapTools();
			}

			GUILayout.Space(20);

			if (GUI.changed)
			{
				GUI.changed = false;
				plyEdUtil.SetDirty(map);
			}
		}

		protected void Update()
		{
			if (map == null || buildingCache) return;

			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.Update(this);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region map tools and layers

		private void DrawMapTools()
		{
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_RecreateMap, plyEdGUI.Styles.Button)) RecreateMap();
			if (GUILayout.Button(GC_CombineMap, plyEdGUI.Styles.Button)) CombineMap();
			if (GUILayout.Button(GC_ReplaceTileSet, plyEdGUI.Styles.Button)) DuplicateMap();

			GUILayout.Space(20);
			EditorGUIUtility.labelWidth = 65;
			EditorGUILayout.TextField(GC_MapIdent, map.ident);
			EditorGUILayout.Space();

#if DEBUG
			EditorGUILayout.Space();
			GUILayout.Label("Debug", EditorStyles.largeLabel);
			EditorGUI.indentLevel++;

			EditorGUI.BeginChangeCheck();
			TileEdGlobal.debugGridNumbers = EditorGUILayout.Toggle("Grid Numbers", TileEdGlobal.debugGridNumbers);
			if (EditorGUI.EndChangeCheck()) EditorPrefs.SetBool("TileEd.debugGridNumbers", TileEdGlobal.debugGridNumbers);

			EditorGUI.indentLevel--;
			EditorGUILayout.Space();
#endif
		}

		private void DrawLayers()
		{
			if (TileEdGlobal.layersDocked)
			{
				GUILayout.Space(1);
				TileEd_TileLayers.DoGUI();
			}

			DrawGroupsTools();

			//if (groupListOps == null)
			//{
			//	groupListOps = new plyEdGUI.ListOps()
			//	{
			//		useMenuStyleToolbar = false,
			//		canAdd = true,
			//		canRemove = true,
			//		canDuplicate = true,
			//		canChangePosition = true,
			//		onDrawHeader = OnDrawGroupListHeader,
			//		onAction = OnGroupListAction,
			//		onDrawElement = OnDrawGroupListEle,
			//		extraButtons = new plyEdGUI.ListOpsExtraToolbarButton[]
			//		{
			//			new plyEdGUI.ListOpsExtraToolbarButton()
			//			{
			//				label = new GUIContent(Ico._rename, "Edit Selected"),
			//				callback = () => TileEd_MapGroupPropsWindow.ShowWiz(group, OnEditGroupListEle),
			//			},
			//		}
			//	};
			//}

			////if (plyEdGUI.List<TileEdMapGroup>(ref activeGroupIdx, map.groups, ref scroll, groupListOps, GUILayout.MaxHeight(150), GUILayout.MinHeight(100)) == 1)
			//if (plyEdGUI.List<TileEdMapGroup>(ref activeGroupIdx, map.groups, ref scroll, groupListOps, GUILayout.Height(TileEdGlobal.layersHeight)) == 1)
			//{
			//	if (TileEdGlobal.seperateGridHeights == false && group != null)
			//	{
			//		map.groups[activeGroupIdx].gridYPos = group.gridYPos;
			//	}

			//	group = map.groups[activeGroupIdx];

			//	if (TileEdGlobal.activeTileEdToolIdx >= 0)
			//	{
			//		TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnGroupChanged();
			//	}

			//	grid.gridPosDirty = true;
			//	SceneView.RepaintAll();
			//}

			//DrawGroupsTools();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region map groups (tile layers)

		private void DrawGroupsTools()
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				group.gridYPos = plyEdGUI.IntStepField(GC_YPos, group.gridYPos, 1);
				if (EditorGUI.EndChangeCheck()) TileEd.grid.gridPosDirty = true;

				GUILayout.Space(2);
				if (plyEdGUI.ToggleButton(group.showPreview, group.showPreview ? GC_TilePreviewVisible : GC_TilePreviewHidden, plyEdGUI.Styles.ToolbarButtonNoHLight))
				{
					group.showPreview = !group.showPreview;
					grid.OnPreviewToggle();
				}

				GUILayout.Space(3);
				EditorGUIUtility.labelWidth = 20;
				group.brushSize = plyEdGUI.IntStepField(GC_Brush[(int)grid.cursorMode], group.brushSize, 1, plyEdGUI.EdFieldState.Readonly, 1, 5);

				GUILayout.Label(GC_Mode[(int)grid.cursorMode], plyEdGUI.Styles.Label);
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
		}

		//private void OnDrawGroupListHeader()
		//{
		//	//GUILayout.Label(GC_GroupListHead, plyEdGUI.Styles.Label);
		//}

		//private int OnGroupListAction(plyEdGUI.ListOps.ListAction act)
		//{
		//	if (act == plyEdGUI.ListOps.ListAction.DoAdd)
		//	{
		//		map.groups.Add(new TileEdMapGroup() { name = plyEdUtil.GetUniqueString<TileEdMapGroup>(map.groups, "TileLayer "), ident = map.GenerateGroupIdent() });
		//		plyEdUtil.SetDirty(map);
		//		return -1;
		//	}

		//	else if (act == plyEdGUI.ListOps.ListAction.DoRemoveSelected)
		//	{
		//		if (map.groups.Count > 1)
		//		{
		//			if (EditorUtility.DisplayDialog("TileEd", "All map data related to this Tile Layer will be deleted, including placed tiles. This action can't be undone. Are you sure you want to continue?", "Yes", "Cancel"))
		//			{
		//				// notify all editor tools that this group is being deleted
		//				for (int i = 0; i < TileEdGlobal.editors.Count; i++)
		//				{
		//					TileEdGlobal.editors[i].ed.OnDeletingGroup(map.groups[activeGroupIdx]);
		//				}

		//				map.groups.RemoveAt(activeGroupIdx);
		//				plyEdUtil.SetDirty(map);
		//				EditorSceneManager.MarkAllScenesDirty();
		//				return -1;
		//			}
		//		}
		//		else
		//		{
		//			EditorUtility.DisplayDialog("TileEd", "You can't delete this Tile Layer. There must be at least one Tile Layer.", "OK");
		//		}
		//	}

		//	else if (act == plyEdGUI.ListOps.ListAction.DoDuplicateSelected)
		//	{
		//		if (group.combined)
		//		{
		//			EditorUtility.DisplayDialog("TileEd", "Can't duplicate a Tile Layer which is combined.", "OK");
		//			return -2;
		//		}

		//		// create new group
		//		TileEdMapGroup source = group;
		//		TileEdMapGroup target = source.Copy();
		//		target.name = target.name + " (copy)";
		//		target.ident = map.GenerateGroupIdent(); // must have unique ident
		//		map.groups.Add(target);

		//		// notify all tools to make a duplication of the source group into target group
		//		for (int i = 0; i < TileEdGlobal.editors.Count; i++)
		//		{
		//			TileEdGlobal.editors[i].ed.OnDuplicatedGroup(target);
		//		}

		//		// save
		//		plyEdUtil.SetDirty(map);
		//		EditorSceneManager.MarkAllScenesDirty();
		//		return -1;
		//	}

		//	return -2;
		//}

		//private void OnDrawGroupListEle(Rect rect, int idx, bool selected)
		//{
		//	if (Event.current.type == EventType.Repaint)
		//	{
		//		plyEdGUI.Styles.ListElement.Draw(rect, selected, selected, selected, true);
		//	}

		//	Rect r = rect;
		//	r.x += 5;
		//	r.width = 20;
		//	if (GUI.Button(r, map.groups[idx].visible ? GC_Visible : GC_Hidden, TileEdGUI.Styles.ButtonInList))
		//	{
		//		map.groups[idx].visible = !map.groups[idx].visible;
		//		plyEdUtil.SetDirty(map);
		//		SetGroupVisible(map.groups[idx].ident, map.groups[idx].visible);
		//	}

		//	r.x += 25;
		//	if (map.groups[idx].combined)
		//	{
		//		if (GUI.Button(r, GC_Combined, TileEdGUI.Styles.ButtonInList))
		//		{
		//			RecreateGroup(map.groups[idx]);
		//		}
		//	}
		//	else
		//	{
		//		if (GUI.Button(r, GC_RecreateGroup, TileEdGUI.Styles.ButtonInList))
		//		{
		//			RecreateGroup(map.groups[idx]);
		//		}
		//	}

		//	listGC.text = Ico._scale + map.groups[idx].tileSize + " " + Ico._swap_vert + map.groups[idx].tileHeight;
		//	Vector2 sz = plyEdGUI.Styles.ListElement.CalcSize(listGC);
		//	sz.x += 10;

		//	r.x += 25;
		//	r.width = rect.width - (sz.x + 55);
		//	GUI.Label(r, map.groups[idx].name, plyEdGUI.Styles.ListElement);

		//	r.x = rect.xMax - sz.x;
		//	r.width = sz.x;
		//	GUI.Label(r, listGC, plyEdGUI.Styles.ListElement);
		//}

		//private void OnEditGroupListEle(TileEd_MapGroupPropsWindow wiz)
		//{
		//	if (!string.IsNullOrEmpty(wiz.groupName)) group.name = wiz.groupName;
		//	if (wiz.tileSize != 0.0f) group.tileSize = wiz.tileSize;
		//	if (wiz.tileHeight != 0.0f) group.tileHeight = wiz.tileHeight;
		//	plyEdUtil.SetDirty(map);
		//	wiz.Close();
		//}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region workers

		//private void SetGroupVisible(int groupIdent, bool visible)
		//{
		//	// tell all tools that the group visibility changed
		//	for (int i = 0; i < TileEdGlobal.editors.Count; i++)
		//	{
		//		TileEdGlobal.editors[i].ed.OnGroupVisibiliyChanged(groupIdent, visible);
		//	}
		//}

		//private void RecreateGroup(TileEdMapGroup group)
		//{
		//	if (EditorUtility.DisplayDialog("TileEd", "All the objects of this group will be removed from the scene and then recreated from the TileEd Map Data. This action can't be undone. Are you sure?", "Yes", "Cancel"))
		//	{
		//		// make group visible
		//		group.visible = true;
		//		group.combined = false;
		//		SetGroupVisible(group.ident, true);

		//		// let tools recreate the group
		//		for (int i = 0; i < TileEdGlobal.editors.Count; i++)
		//		{
		//			TileEdGlobal.editors[i].ed.RecreateGroup(group);
		//		}

		//		// mark scene dirty since this change can't be undone
		//		plyEdUtil.SetDirty(map);
		//		EditorSceneManager.MarkAllScenesDirty();
		//	}
		//}

		private void RecreateMap(bool forced = false)
		{
			// recreates the map from TileEd data
			if (forced || EditorUtility.DisplayDialog("TileEd", "All the objects of this map will be removed from the scene and then recreated from the TileEd Map Data. This action can't be undone. Are you sure?", "Yes", "Cancel"))
			{
				// close any open tool
				TileEdGlobal.activeTileEdToolIdx = -1;

				// delete all child objects of the map
				for (int i = mapTr.childCount - 1; i >= 0; i--)
				{   // do not delete props?
					if (TileEdGlobal.recreateIgnoreProps && mapTr.GetChild(i).gameObject.name == "Props") continue;
					Object.DestroyImmediate(mapTr.GetChild(i).gameObject);
				}

				// make all groups visible
				for (int i = 0; i < map.groups.Count; i++)
				{
					map.groups[i].visible = true;
					map.groups[i].combined = false;
				}

				// let tools add scene objects
				for (int i = 0; i < TileEdGlobal.editors.Count; i++)
				{
					TileEdGlobal.editors[i].ed.RecreateMap();
				}

				// mark scene dirty since this change can't be undone
				plyEdUtil.SetDirty(map);
				EditorSceneManager.MarkAllScenesDirty();
			}
		}

		private void CombineMap()
		{
			if (EditorUtility.DisplayDialog("TileEd", "Tiles will now be combined. You will not be able to edit tiles in Tile Layers that are combined. This can be undone by using the Recreate tool. This might take a while depending on the size of the map. Are you sure you want to continue?", "Yes", "Cancel"))
			{
				TileEd_CombineOptionsWindow.ShowWiz(_CombineMap);
			}
		}

		private void _CombineMap(TileEd_CombineOptionsWindow wiz)
		{
			bool doUv2 = wiz.GenerateUV2;
			UnwrapParam unwrapParam = wiz.GenerateUV2WithUnwrapParam;
			wiz.Close();

			// close any open tool
			TileEdGlobal.activeTileEdToolIdx = -1;

			for (int grpIdx = 0; grpIdx < map.groups.Count; grpIdx++)
			{
				if (map.groups[grpIdx].combined == false)
				{
					map.groups[grpIdx].visible = true;
					map.groups[grpIdx].combined = true;

					// call tools to perform combines of group
					for (int i = 0; i < TileEdGlobal.editors.Count; i++)
					{
						TileEdGlobal.editors[i].ed.CombineGroup(map.groups[grpIdx], doUv2, unwrapParam);
					}
				}
			}

			// mark scene dirty since this change can't be undone
			plyEdUtil.SetDirty(map);
			EditorSceneManager.MarkAllScenesDirty();

		}

		private void CombineActiveGroup()
		{
			EditorUtility.DisplayDialog("TileEd", "TODO: Mesh Combine", "OK");
			return;

			//if (group.combined)
			//{
			//	EditorUtility.DisplayDialog("TileEd", "The Tile Layer is already combined.", "OK");
			//	return;
			//}

			//if (EditorUtility.DisplayDialog("TileEd", "Tiles will now be combined into blocks of meshes. You will not be able to edit tiles in Tile Layers that are combined. Are you sure?", "Yes", "Cancel"))
			//{
			//	// close any open tool
			//	TileEdGlobal.activeTileEdToolIdx = -1;

			//	group.visible = true;
			//	group.combined = true;

			//	// call tools to perform combines of group
			//	for (int i = 0; i < TileEdGlobal.editors.Count; i++)
			//	{
			//		TileEdGlobal.editors[i].ed.CombineGroup(group);
			//	}

			//	// mark scene dirty since this change can't be undone
			//	EditorApplication.MarkSceneDirty();
			//	plyEdUtil.SetDirty(map);
			//}
		}

		private void DuplicateMap()
		{
			TileEdGlobal.activeTileEdToolIdx = -1; // close any open tool
			if (EditorUtility.DisplayDialog("TileEd", "Would you like to make a duplicate of this map asset and create a new TileEd map object in the scene with a reference to the new asset file? You would normally do this if you want to make changes to the map without affecting the original. If you do not do this and paint tiles in the new map and then go back to the old one and do a Recreate the old one will look like the new one since they share a map asset file", "Yes", "No"))
			{
				// make a copy of the map asset. the action will cause the new map to be selected to I need to set a flag
				// which can be checked to see if the inspector was activated on a duplicated map and should continue
				// to the next step, ChooseTileSetReplacements()
				wasMapDuplication = true;
				TileEdGlobal.CreateNewMap(map);
			}
			else
			{
				TileEdSetsMappingWindow.Show_TileEdSetsMappingWindow(OnChooseTileSetReplacements, false);
			}
		}

		private void OnChooseTileSetReplacements(TileEdSetsMappingWindow win)
		{
			if (win.wasCancel)
			{
				if (win.forceRecreate) RecreateMap(true);
				return;
			}

			EditorUtility.DisplayProgressBar("TileEd", "Replacing Tile and Prop Sets", 0f);
			for (int setsIdx = 0; setsIdx < win.sets.Count; setsIdx++)
			{
				List<TileEd_Ed_Base.TileSetInfo> set = win.sets[setsIdx];
				int[] mapping = win.setsMapping[setsIdx];

				float progress = 0;
				float step = 1f / set.Count;
				for (int i = 0; i < set.Count; i++)
				{
					EditorUtility.DisplayProgressBar("TileEd", "Replacing Tile and Prop Sets", progress);
					progress += step;
					if (mapping[i] == i) continue;

					Debug.Log("Replace " + set[i].setName + " with " + set[mapping[i]].setName);

					TileEd_Ed_Base ted = TileEdGlobal.GetEdByToolIdent(set[i].toolIdent);
					if (ted == null) continue;

					ted.ReplaceTilesInMap(set[i], set[mapping[i]]);
				}
			}

			EditorUtility.ClearProgressBar();
			win.Close();
			RecreateMap(true);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region scene view

		protected void OnSceneGUI()
		{
			if (group == null || map == null || EditorApplication.isPlayingOrWillChangePlaymode) return;

			SceneView sceneView = SceneView.currentDrawingSceneView;

			// disable the unity scene tools and prevent the selection rectangle and paint grid
			if (TileEdGlobal.edModeOn)
			{
				Tools.pivotMode = PivotMode.Pivot;
				Tools.pivotRotation = PivotRotation.Local;
				Tools.current = Tool.None;
				HandleUtility.AddDefaultControl(GUIUtility.GetControlID(FocusType.Passive));

				if (TileEdGlobal.activeTileEdToolIdx >= 0)
				{
					grid.Render(sceneView, (false == TileEdGlobal.mouseWasOverPalette));
					TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnSceneView(sceneView);
				}
			}

			// Handle docked palette
			if (TileEdGlobal.paletteDocked)
			{
				Handles.BeginGUI(); 
				{
					TileEd_PalettePanel.RenderDockedUI(sceneView);
				}
				Handles.EndGUI();
			}

			// Handle grid events after docked palette
			if (TileEdGlobal.edModeOn && TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				grid.HandleEvents(sceneView);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region sort order helpers

		private static System.Func<string[]> Invoke_SortingLayerNames;
		private static System.Func<int[]> Invoke_sortingLayerUniqueIDs;
		private static System.Func<int, int> Invoke_GetSortingLayerUniqueID;
		private static System.Func<int, string> Invoke_GetSortingLayerName;
		private static System.Func<int, string> Invoke_GetSortingLayerNameFromUniqueID;

		public static void GetSortingLayerNames(ref GUIContent[] names)
		{
			if (Invoke_SortingLayerNames == null)
			{
				PropertyInfo prop = typeof(UnityEditorInternal.InternalEditorUtility).GetProperty("sortingLayerNames", BindingFlags.Static | BindingFlags.NonPublic);
				MethodInfo method = prop.GetGetMethod(true);
				Invoke_SortingLayerNames = (System.Func<string[]>)System.Delegate.CreateDelegate(typeof(System.Func<string[]>), method);
			}
			string[] nms = Invoke_SortingLayerNames();

			if (names.Length != nms.Length) names = new GUIContent[nms.Length];

			for (int i = 0; i < names.Length; i++)
			{
				if (names[i] == null) names[i] = new GUIContent(nms[i]);
				else names[i].text = nms[i];
			}
		}

		public static int GetSortingLayerUniqueID(int idx)
		{
			if (Invoke_GetSortingLayerUniqueID == null)
			{
				MethodInfo method = typeof(UnityEditorInternal.InternalEditorUtility).GetMethod("GetSortingLayerUniqueID", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(int) }, null);
				Invoke_GetSortingLayerUniqueID = (System.Func<int, int>)System.Delegate.CreateDelegate(typeof(System.Func<int, int>), method);
			}
			return Invoke_GetSortingLayerUniqueID(idx);
		}

		public static string GetSortingLayerName(int idx)
		{
			if (Invoke_GetSortingLayerName == null)
			{
				MethodInfo method = typeof(UnityEditorInternal.InternalEditorUtility).GetMethod("GetSortingLayerName", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(int) }, null);
				Invoke_GetSortingLayerName = (System.Func<int, string>)System.Delegate.CreateDelegate(typeof(System.Func<int, string>), method);
			}
			return Invoke_GetSortingLayerName(idx);
		}

		public static string GetSortingLayerNameFromUniqueID(int id)
		{
			if (Invoke_GetSortingLayerNameFromUniqueID == null)
			{
				MethodInfo method = typeof(UnityEditorInternal.InternalEditorUtility).GetMethod("GetSortingLayerNameFromUniqueID", (BindingFlags.Static | BindingFlags.NonPublic), null, new System.Type[] { typeof(int) }, null);
				Invoke_GetSortingLayerNameFromUniqueID = (System.Func<int, string>)System.Delegate.CreateDelegate(typeof(System.Func<int, string>), method);
			}
			return Invoke_GetSortingLayerNameFromUniqueID(id);
		}

		public static int GetSortingLayerIdxFromUniqueId(int id)
		{
			if (Invoke_sortingLayerUniqueIDs == null)
			{
				PropertyInfo prop = typeof(UnityEditorInternal.InternalEditorUtility).GetProperty("sortingLayerUniqueIDs", BindingFlags.Static | BindingFlags.NonPublic);
				MethodInfo method = prop.GetGetMethod(true);
				Invoke_sortingLayerUniqueIDs = (System.Func<int[]>)System.Delegate.CreateDelegate(typeof(System.Func<int[]>), method);
			}
			int[] ids = Invoke_sortingLayerUniqueIDs();

			for (int i = 0; i < ids.Length; i++) if (ids[i] == id) return i;
			return 0;
		}

		public static void SetObjectSortOrder(GameObject go, int layerId, int order)
		{
			string name = GetSortingLayerNameFromUniqueID(layerId);
			Renderer[] rens = go.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < rens.Length; i++)
			{
				rens[i].sortingLayerName = name;
				rens[i].sortingLayerID = layerId;
				rens[i].sortingOrder = order;
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
	}
}
