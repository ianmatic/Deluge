﻿using UnityEngine;
using plyLib;
using System.Collections.Generic;

namespace TileEd
{
	[System.Serializable]
	public class TileEdTemplate
	{
		public string name;
		public string guid;
		public int toolIdent;		// tool that this template belongs to
		public GameObject prefab;	// preview prefab for this template
		public Texture2D texture;	// preview texture
		public List<TileEdMapTile> tiles = new List<TileEdMapTile>();

		public TileEdTemplate Copy()
		{
			TileEdTemplate t = new TileEdTemplate();
			t.name = this.name;
			t.guid = this.guid;
			t.toolIdent = this.toolIdent;
			t.prefab = this.prefab;
			t.texture = this.texture;
			for (int i = 0; i < this.tiles.Count; i++) t.tiles.Add(this.tiles[i].Copy());

			return t;
		}

	}
}
