﻿using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using plyLib;
using plyLibEditor;
using System.Collections.Generic;

namespace TileEd
{
	// keeps data related to a tile/object that is selected in the grid
	public class TileEdSelected
	{
		public TileEdMapGroup group;
		public TileEdMapTile tile;
		public IntVector3 gridPos;
		public GameObject markerGo;
		public GameObject mainGo;

		public static int ListContains(List<TileEdSelected> list, IntVector3 gridPos)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].gridPos == gridPos) return i;
			}
			return -1;
		}

		public static int ListContains(List<TileEdSelected> list, TileEdMapTile tile)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].tile == tile) return i;
			}
			return -1;
		}

		public static List<int> AllAtGridPos(List<TileEdSelected> list, TileEdMapGroup group, IntVector3 gridPos)
		{
			List<int> res = new List<int>();
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].group == group && list[i].gridPos == gridPos) res.Add(i);
			}
			return res;
		}

	}

}
