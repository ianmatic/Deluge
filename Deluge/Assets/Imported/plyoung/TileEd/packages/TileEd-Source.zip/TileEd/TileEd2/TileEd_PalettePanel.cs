﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_PalettePanel : EditorWindow
    {
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		private static readonly GUIContent GC_EditOn = new GUIContent(Ico._radio_button_checked, "Toggle TileEd mode on/ off.");
		private static readonly GUIContent GC_EditOff = new GUIContent(Ico._radio_button_unchecked, "Toggle TileEd mode on/ off.");
		private static readonly GUIContent GC_PanelUndock = new GUIContent(Ico._undock, "Undock panel");
		private static readonly GUIContent GC_PanelLayout = new GUIContent(Ico._rotate, "Change layout");
		private static readonly GUIContent GC_PreviewSize = new GUIContent(Ico._scale, "Change preview/ icon size");
		private static readonly GUIContent GC_Settings = new GUIContent(Ico._settings, "Open Settings");

		private static readonly int[] PreviewSizes = { 64, 128 };

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public static bool hasLoadingPreviews { get; set; }
		public static TileEd_PalettePanel win { get; private set; }

		private static int previewSizeIdx = -1;
		private static int paletteSize = 0;

		private static GUIContent[] editorLabels = null;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region system

		public static void Show_Window()
		{
			win = EditorWindow.GetWindow<TileEd_PalettePanel>("Palette");
			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_palette" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			win.titleContent = new GUIContent("Palette", icon);
		}

		protected void OnEnable()
		{
			win = this;
			TileEdGlobal.paletteDocked = false;
			EditorPrefs.SetBool("TileEd.PalettePanel.Docked", TileEdGlobal.paletteDocked);
			Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_palette" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			titleContent = new GUIContent("Palette", icon);
		}

		protected void OnDestroy()
		{
			win = null;
			TileEdGlobal.paletteDocked = true;
			EditorPrefs.SetBool("TileEd.PalettePanel.Docked", TileEdGlobal.paletteDocked);
		}

		protected void OnFocus()
		{
			wantsMouseMove = true;
		}

		protected void OnLostFocus()
		{
			wantsMouseMove = false;
		}

		protected void OnSelectionChange()
		{
			Repaint();
		}

		protected void OnInspectorUpdate()
		{ // 10 fps
			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				if (TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.hasLoadingPalettePreviews && AssetPreview.IsLoadingAssetPreviews())
				{
					Repaint();
				}
			}
		}

		//protected void Update()
		//{ // 100 fps
		//	if (TileEdGlobal.activeTileEdToolIdx >= 0)
		//	{
		//		if (TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.hasLoadingPalettePreviews && AssetPreview.IsLoadingAssetPreviews())
		//		{
		//			Repaint();
		//		}
		//	}
		//}

		public static void DoRepaint()
		{
			if (win != null) win.Repaint();
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region GUI

		private static void InitGUI()
		{
			if (previewSizeIdx == -1)
			{
				previewSizeIdx = 0;
				for (int i = 0; i < PreviewSizes.Length; i++) if (PreviewSizes[i] == TileEdGlobal.palettePreviewSize) { previewSizeIdx = i; break; }
				TileEdGlobal.palettePreviewSize = PreviewSizes[previewSizeIdx];
				EditorPrefs.SetInt("TileEd.PalettePanel.PreviewSize", TileEdGlobal.palettePreviewSize);
				CalcPaletteSize();
			}

			//if (!TileEdGlobal.paletteDocked && win.titleContent.image == null)
			//{
			//	Texture2D icon = plyEdGUI.LoadTextureResource("TileEd.res.ico_palette" + (EditorGUIUtility.isProSkin ? "_p" : "") + ".png", typeof(TileEdGlobal).Assembly);
			//	win.titleContent = new GUIContent("Palette", icon);
			//}
		}

		protected void OnGUI()
		{
			TileEdGlobal.mouseWasOverPalette = false; // reset since it does not apply when this panel not docked in scene view

			if (TileEd.Instance == null || TileEd.Instance.map == null || EditorApplication.isPlayingOrWillChangePlaymode)
			{
				GUILayout.Label("No TileEd Map selected or play mode active.", EditorStyles.wordWrappedMiniLabel);
				return;
			}

			if (TileEd.Instance.buildingCache)
			{
				Repaint();
				return;
			}

			InitGUI();
			RenderToolbar();

			if (TileEdGlobal.edModeOn)
			{
				RenderMainUI();
			}
		}

		public static void RenderDockedUI(SceneView sceneView)
		{
			if (TileEd.Instance.buildingCache)
			{
				sceneView.Repaint();
				return;
			}

			InitGUI();

			bool mouseOverPalette = false;
			Event ev = Event.current;
			Rect r = new Rect(0, sceneView.position.height - 35, sceneView.position.width, 20);
			GUILayout.BeginArea(r);
			RenderToolbar();
			GUILayout.EndArea();

			if ((ev.type == EventType.MouseMove || ev.type == EventType.MouseDown || ev.type == EventType.MouseUp || ev.type == EventType.MouseDrag) && r.Contains(ev.mousePosition))
			{
				mouseOverPalette = true;
				if (ev.type != EventType.MouseMove) ev.Use();
			}

			if (TileEdGlobal.edModeOn)
			{
				if (TileEdGlobal.paletteLayout == 0)
				{
					r = new Rect(0, sceneView.position.height - (paletteSize + 35), sceneView.position.width, paletteSize);
					GUILayout.BeginArea(r);
				}
				else
				{
					r = new Rect(0, 0, paletteSize, sceneView.position.height - 35);
					GUILayout.BeginArea(r);
				}

				RenderMainUI();
				GUILayout.EndArea();

				if (mouseOverPalette == false && (ev.type == EventType.MouseMove || ev.type == EventType.MouseDown || ev.type == EventType.MouseUp || ev.type == EventType.MouseDrag) && r.Contains(ev.mousePosition))
				{
					mouseOverPalette = true;
					if (ev.type != EventType.MouseMove) ev.Use();
				}
			}

			if (mouseOverPalette != TileEdGlobal.mouseWasOverPalette && ev.type == EventType.MouseMove)
			{
				TileEdGlobal.mouseWasOverPalette = mouseOverPalette;
				sceneView.Repaint();
			}
		}

		private static void RenderToolbar()
		{
			Rect toolbarRect = EditorGUILayout.BeginHorizontal(TileEdGlobal.edModeOn ? plyEdGUI.Styles.Toolbar : GUIStyle.none);
			{
				if (GUILayout.Button(GC_Settings, plyEdGUI.Styles.ToolbarButton))
				{
					TileEd_Settings.Show_Window();
				}

				if (plyEdGUI.ToggleButton(TileEdGlobal.edModeOn, TileEdGlobal.edModeOn ? GC_EditOn : GC_EditOff, plyEdGUI.Styles.ToolbarButton))
				{
					TileEdGlobal.ToggleEdModeOnOff();
				}

				if (TileEdGlobal.edModeOn)
				{
					if (TileEdGlobal.paletteDocked)
					{
						GUILayout.Space(20);
						for (int i = 0; i < TileEdGlobal.editors.Count; i++)
						{
							if (plyEdGUI.ToggleButton(TileEdGlobal.activeTileEdToolIdx == i, TileEdGlobal.editors[i].label, plyEdGUI.Styles.ToolbarButton))
							{
								if (TileEdGlobal.activeTileEdToolIdx == i) TileEdGlobal.activeTileEdToolIdx = -1; // toggle off
								else TileEdGlobal.activeTileEdToolIdx = i; // toggle on
							}
						}
					}
					else
					{
						// when not docked the window could be resized so small that all tools does 
						// not fit in the toolbar. check if should rather show drop-down

						if (Event.current.type == EventType.Repaint)
						{
							float width = 100f; // 100 = the other buttons and spacing
							for (int i = 0; i < TileEdGlobal.editors.Count; i++) width += plyEdGUI.Styles.ToolbarButton.CalcSize(TileEdGlobal.editors[i].label).x;
							if (width >= toolbarRect.width)
							{
								editorLabels = new GUIContent[TileEdGlobal.editors.Count];
								for (int i = 0; i < TileEdGlobal.editors.Count; i++) editorLabels[i] = TileEdGlobal.editors[i].label;
							}
							else editorLabels = null;
						}

						if (editorLabels != null)
						{
							GUILayout.Space(2);
							TileEdGlobal.activeTileEdToolIdx = EditorGUILayout.Popup(TileEdGlobal.activeTileEdToolIdx, editorLabels);
						}
						else
						{
							GUILayout.Space(20);
							for (int i = 0; i < TileEdGlobal.editors.Count; i++)
							{
								if (plyEdGUI.ToggleButton(TileEdGlobal.activeTileEdToolIdx == i, TileEdGlobal.editors[i].label, plyEdGUI.Styles.ToolbarButton))
								{
									if (TileEdGlobal.activeTileEdToolIdx == i) TileEdGlobal.activeTileEdToolIdx = -1; // toggle off
									else TileEdGlobal.activeTileEdToolIdx = i; // toggle on
								}
							}
						}
					}

				}

				GUILayout.FlexibleSpace();

				if (TileEdGlobal.edModeOn)
				{
					if (GUILayout.Button(GC_PreviewSize, plyEdGUI.Styles.ToolbarButton))
					{
						previewSizeIdx++;
						if (previewSizeIdx >= PreviewSizes.Length) previewSizeIdx = 0;
						TileEdGlobal.palettePreviewSize = PreviewSizes[previewSizeIdx];
						EditorPrefs.SetInt("TileEd.PalettePanel.PreviewSize", TileEdGlobal.palettePreviewSize);
						CalcPaletteSize();
					}

					if (TileEdGlobal.paletteDocked)
					{
						if (GUILayout.Button(GC_PanelLayout, plyEdGUI.Styles.ToolbarButton))
						{
							TileEdGlobal.paletteLayout = TileEdGlobal.paletteLayout == 0 ? 1 : 0;
							EditorPrefs.SetInt("TileEd.PalettePanel.Layout", TileEdGlobal.paletteLayout);
							CalcPaletteSize();
						}

						if (GUILayout.Button(GC_PanelUndock, plyEdGUI.Styles.ToolbarButton))
						{
							TileEdGlobal.paletteDocked = false;
							EditorPrefs.SetBool("TileEd.PalettePanel.Docked", TileEdGlobal.paletteDocked);
							TileEd_PalettePanel.Show_Window();
						}
					}					
				}
			}
			EditorGUILayout.EndHorizontal();
		}

		private static void RenderMainUI()
		{
			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnPaletteGUI();
			}
		}

		private static void CalcPaletteSize()
		{
			paletteSize = TileEdGlobal.palettePreviewSize + 7;

			if (TileEdGlobal.paletteLayout == 0)
			{
				// add space for the tile-set name toolbar
				paletteSize += 14;
			}
			//else
			//{	// for smallest preview make the vertical bar wider so two tiles are shown next to each other
			//	if (TileEd.palettePreviewSize == 32) paletteSize += 37;
			//}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
