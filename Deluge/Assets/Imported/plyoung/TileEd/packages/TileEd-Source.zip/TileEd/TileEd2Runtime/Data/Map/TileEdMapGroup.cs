﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdMapGroup
	{
		/// <summary> Unique identifier for this group within the map.
		/// this is the same as the name (number) used for the GameObject
		/// that represents this group in the scene within each TileEd
		/// tool (Tiles and Props) </summary>
		public int ident;

		/// <summary> This is the name shown in the inspector and can be changed by the user. </summary>
		public string name;

		/// <summary> Is this group visible? </summary>
		public bool visible = true;

		/// <summary> Is this group's Tiles combined? Note that Props are never combined. </summary>
		public bool combined = false;

		/// <summary> The size of a tile in the grid for this group. </summary>
		public float tileSize = 1f;

		/// <summary> The height of a tile in the grid for this group. </summary>
		public float tileHeight = 1f;

		// editor helpers
		public int gridYPos = 0;		// Current height/y-pos of grid for this group
		public int brushSize = 1;		// Current brush size for this group
		public bool showPreview = true; // Should the tile preview be shown in scene while painting?

		// the tile data (this list contains ALL tiles. A tile can be a Tile, Prop or 
		// any other map object that other tools might define)
		[SerializeField] private List<TileEdMapTile> tiles = new List<TileEdMapTile>();
		[System.NonSerialized] private Dictionary<IntVector3, TileEdMapTile> tileCache = new Dictionary<IntVector3, TileEdMapTile>();

		// used by the mesh combine tools.
		[SerializeField] public List<string> combinedMeshNames = new List<string>();

		/// <summary> If true (default) then grid cells are aligned so that centre of tile is in centre of world,
		/// else the lower left corner of a cell is in the centre. Aligning to corner can make it easier to align
		/// tile when you regularly use different tile sizes in the map.</summary>
		public bool centreTiles = true;

		/// <summary> The number of tiles (and props - they are all stored in same list) in this group </summary>
		public int Count { get { return tiles.Count; } }

		/// <summary> Use to access a specific tile (or props - they are all stored in same list) in 
		/// the list of tiles of this group </summary>
		public TileEdMapTile this[int i] { get { return tiles[i]; } }

		// ------------------------------------------------------------------------------------------------------------

		// create a copy
		public TileEdMapGroup Copy()
		{
			TileEdMapGroup g = new TileEdMapGroup();
			g.ident = this.ident;
			g.name = this.name;
			g.visible = this.visible;
			g.combined = false;
			g.tileSize = this.tileSize;
			g.tileHeight = this.tileHeight;
			g.gridYPos = this.gridYPos;
			g.brushSize = this.brushSize;
			g.showPreview = this.showPreview;
			for (int i = 0; i < this.tiles.Count; i++) g.tiles.Add(this.tiles[i].Copy());
			g.combinedMeshNames = new List<string>();
			g.centreTiles = this.centreTiles;
			return g;
		}

		public override string ToString()
		{
			return name;
		}

		// only Tool 1 (the tile painting tool) can have tiles cached since other tools have objects that share grid position
		public void BuildCache()
		{
			tileCache.Clear();
			for (int i = 0; i < tiles.Count; i++)
			{
				//if (tiles[i].toolIdent != TileEd_Ed_Tiles.TOOL_IDENT) continue;
				if (tiles[i].toolIdent != 1) continue;

				// try-catch just in case there is a duplicate entry from corrupt map data
				try
				{
					tileCache.Add(tiles[i].gridPos, tiles[i]);
				} catch
				{
					//Debug.LogError("[tileCache] gridPos entry exist: " + tiles[i].gridPos + " => " + tileCache[tiles[i].gridPos]);
				}
			}
		}

		/// <summary> Add a tile to the group. Note, this does nothing in the scene. It is up to you to create
		/// the representing GameObject in the scene and under the correct GameObject hierarchy. </summary>
		public void AddTile(TileEdMapTile tile)
		{
			if (tile.toolIdent == 1) //if (tile.toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)				
			{
				// try-catch just in case there is a duplicate entry from corrupt map data
				/*try {*/tileCache.Add(tile.gridPos, tile); /*} catch { }*/
			}

			tiles.Add(tile);
		}

		/// <summary> Removes a tile from the group. Note that no GameObjects are removed from the scene.
		/// It is up to you to remove any associated GameObject. </summary>
		public void RemoveTile(TileEdMapTile tile)
		{
			if (tile.toolIdent == 1) //if (tile.toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				/*try {*/tileCache.Remove(tile.gridPos); /*} catch { }*/
			}

			tiles.Remove(tile);
		}

		/// <summary> Removes a tile from the group. Note that no GameObjects are removed from the scene.
		/// It is up to you to remove any associated GameObject. Idx is an index into the tile list. </summary>
		public void RemoveTile(int idx)
		{
			if (tiles[idx].toolIdent == 1) //if (tiles[idx].toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				/*try {*/tileCache.Remove(tiles[idx].gridPos); /*} catch { }*/
			}

			tiles.RemoveAt(idx);
		}

		/// <summary> Removes all tiles of the specific tool (toolIdent) from the group. 
		/// No GameObjects are removed by this. TileEd includes two tools and their IDs
		/// can be found via TileEd_Ed_Tiles.TOOL_IDENT and TileEd_Ed_Props.TOOL_IDENT </summary>
		public void RemoveAllTiles(int toolIdent)
		{
			if (toolIdent == 1) //if (toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				tileCache.Clear();
			}

			for (int i = tiles.Count - 1; i >= 0; i--)
			{
				if (tiles[i].toolIdent == toolIdent) tiles.RemoveAt(i);
			}
		}

		/// <summary> Get the tile at grid position (pos) for the specific TilEd tool.
		/// TileEd includes two tools and their IDs can be found via 
		/// TileEd_Ed_Tiles.TOOL_IDENT and TileEd_Ed_Props.TOOL_IDENT </summary>
		public TileEdMapTile GetTile(int toolIdent, IntVector3 pos)
		{
			if (toolIdent == 1) //if (toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				TileEdMapTile t = null;
				if (tileCache.TryGetValue(pos, out t))
				{
					if (pos != t.gridPos) Debug.LogError("GetTile cache error. Returned wrong tile: " + pos.ToString() + " != " + t.gridPos.ToString());
				}
				return t;				
			}

			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].toolIdent == toolIdent && tiles[i].gridPos == pos)
				{
					return tiles[i];
				}
			}

			return null;
		}

		/// <summary> Mainly used by Props tool to find a specific prop by comparing
		/// the "val" with the tile's extraData[dataIdx]. This is necessary since props
		/// share grid positions so the GetTile() method would not work so well. </summary>
		public TileEdMapTile GetTileByExtraData(int toolIdent, string val, int dataIdx)
		{
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].toolIdent == toolIdent && tiles[i].extraData.Length > dataIdx && tiles[i].extraData[dataIdx] == val)
				{
					return tiles[i];
				}
			}
			return null;
		}

		/// <summary> Get all tiles which are sharing the same position. Only really valid for Props 
		/// since Tiles should never share a grid position within the same Tile Layer/ Group </summary>
		public List<TileEdMapTile> GetTiles(int toolIdent, IntVector3 pos)
		{
			List<TileEdMapTile> res = new List<TileEdMapTile>();
			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].toolIdent == toolIdent && tiles[i].gridPos == pos)
				{
					 res.Add(tiles[i]);
				}
			}
			return res;
		}

		/// <summary> Get all tiles which are sharing the same position. Only really valid for Props 
		/// since Tiles should never share a grid position within the same Tile Layer/ Group </summary>
		public TileEdMapTile[] GetTiles(int toolIdent, IntVector3[] pos)
		{
			TileEdMapTile[] res = new TileEdMapTile[pos.Length];

			if (toolIdent == 1) //if (toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				for (int j = 0; j < pos.Length; j++)
				{
					tileCache.TryGetValue(pos[j], out res[j]);
				}
				return res;
			}

			else
			{
				int setCheck = 0;
				for (int i = 0; i < tiles.Count; i++)
				{
					for (int j = 0; j < pos.Length; j++)
					{
						if (tiles[i].toolIdent == toolIdent && tiles[i].gridPos == pos[j])
						{
							res[j] = tiles[i];
							setCheck++; // if setCheck is same as res length then all tiles were found, no need to continue
							if (setCheck == res.Length) return res;
						}
					}
				}
			}

			return res;
		}
		 
		/// <summary> Get all tiles at XZ, ignoring the Y position of the tile. This means a list is returned 
		/// of all the tiles on the same plane, above and below. Auto tiles uses this to find what tiles
		/// to remove below or above. Note that only the 1st 2 above and below are returned for Tiles 
		/// for performance reasons since this method is used often while painting auto-tiles.
		/// For other tools (like Props) all above and below are returned. </summary>
		public List<TileEdMapTile> GetTilesXZ(int toolIdent, IntVector3 pos, int depthAbove, int depthBelow)
		{
			List<TileEdMapTile> res = new List<TileEdMapTile>();

			if (toolIdent == 1) //if (toolIdent == TileEd_Ed_Tiles.TOOL_IDENT)
			{
				if (tileCache == null) return res;

				// check only for few above and below
				int min = pos.y - (depthBelow < 0 ? 0 : depthBelow);
				int max = pos.y + (depthAbove < 0 ? 0 : depthAbove);
				for (int y = min; y <= max; y++)
				{
					pos.y = y;
					TileEdMapTile t;
					if (!tileCache.TryGetValue(pos, out t)) continue;
					res.Add(t);
				}
			}

			else
			{
				for (int i = 0; i < tiles.Count; i++)
				{
					if (tiles[i].toolIdent == toolIdent && tiles[i].gridPos.x == pos.x && tiles[i].gridPos.z == pos.z)
					{
						res.Add(tiles[i]);
					}
				}
			}

			return res;
		}

		/// <summary> Runs through all tiles in this group and calculates the min and max grid positions
		/// occupied by the tiles. An array, with the min value 1st and max value 2nd, is returned. </summary>
		public IntVector3[] GetMinMaxGridPosition()
		{
			IntVector3[] res = new IntVector3[] { new IntVector3(0, 0, 0), new IntVector3(0, 0, 0) };

			for (int i = 0; i < tiles.Count; i++)
			{
				if (tiles[i].gridPos.x < res[0].x) res[0].x = tiles[i].gridPos.x;
				if (tiles[i].gridPos.y < res[0].y) res[0].y = tiles[i].gridPos.y;
				if (tiles[i].gridPos.z < res[0].z) res[0].z = tiles[i].gridPos.z;
				if (tiles[i].gridPos.x > res[1].x) res[1].x = tiles[i].gridPos.x;
				if (tiles[i].gridPos.y > res[1].y) res[1].y = tiles[i].gridPos.y;
				if (tiles[i].gridPos.z > res[1].z) res[1].z = tiles[i].gridPos.z;
			}

			return res;
		}

		/// <summary> This will return a grid position when given a world position relative to Tile Size and 
		/// Height settings of this group. It assumes the map object is at 0x0x0 so you need to adjust for 
		/// that if needed in the 'pos' arg. </summary>
		public IntVector3 WorldPosToGridPos(Vector3 worldPos)
		{
			if (centreTiles == false)
			{
				float offs = tileSize / 2f;
				worldPos.x += offs;
				worldPos.z += offs;
			}

			// snap position to grid world positions
			worldPos.x = tileSize * Mathf.Round(worldPos.x / tileSize);
			worldPos.y = tileHeight * Mathf.Round(worldPos.x / tileHeight);
			worldPos.z = tileSize * Mathf.Round(worldPos.z / tileSize);

			// return grid position
			return new IntVector3()
			{
				x = Mathf.RoundToInt(worldPos.x / tileSize),
				y = Mathf.RoundToInt(worldPos.y / tileHeight),
				z = Mathf.RoundToInt(worldPos.z / tileSize)
			};

		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
