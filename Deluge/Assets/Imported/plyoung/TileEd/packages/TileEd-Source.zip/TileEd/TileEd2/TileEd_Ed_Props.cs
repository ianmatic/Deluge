﻿using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;
using plyLibEditor.CustomRaycast;

namespace TileEd
{
	public class TileEd_Ed_Props : TileEd_Ed_Base
    {
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public const int TOOL_IDENT = 2;
		private const string ASSET_NAME = "Props.asset";
		private const string TMPLT_NAME = "PropTemplates.asset";
		private const string ROOT_NAME = "Props";
		private const string PATH = "Props/";

		// these are used with TileEdMapTile.data[] array
		private const int _TileSetIdent = 0;		// PropSet ident (PropSet that prop is in)
		public const int  _TileIdent = 1;			// Prop ident (in tile set)
		private const int _TileRotation = 2;		// Rotation of prop
		private const int _TileFabIdx = 3;			// Index into Prop's prefab array
		private const int _MaxTileProperties = 5;

		// index into TileEdMapTile.extraData[] array
		private const int _eData_Ident = 0;
		private const int _eData_Rotation = 1;	// custom rotation (entry can be empty if not used)
		private const int _eData_Scale = 2;		// custom scaling (entry can be empty if not used)

		private static readonly int[] RotOps = { 180,90,45,30,15,10,5 };

		private static readonly GUIContent GC_DropArea = new GUIContent("Drop props here or press =>");
		private static readonly GUIContent GC_SetTag = new GUIContent("Tag", "If not set then the Tag set in the prefab will be used as is");
		private static readonly GUIContent GC_SetLayer = new GUIContent("Layer", "If not set then the Layer set in the prefab will be used as is");
		private static readonly GUIContent GC_SetStatic = new GUIContent("Static", "If not set then the Static Flags set in the prefab will be used as is");
		private static readonly GUIContent GC_SetNavArea = new GUIContent("NavArea", "Set the navigation area to be used");
		private static readonly GUIContent GC_SetSort = new GUIContent("Sort", "Set the sorting layer and order");
		private static readonly GUIContent GC_ClearProp = new GUIContent(Ico._remove, "Remove prefab from this prop");
		private static readonly GUIContent GC_CustomThumb = new GUIContent(Ico._stop, "Select a custom thumbnail image for this prop");
		private static readonly GUIContent GC_AddRandomProp = new GUIContent(Ico._add, "Add random prop prefab option");
		private static readonly GUIContent GC_Wait = new GUIContent(Ico._wait);
		private static readonly GUIContent GC_OpenPropSettingsPopup = new GUIContent(Ico._chevron_down, "Show prop settings");
		private static readonly GUIContent GC_Up = new GUIContent(Ico._chevron_up);
		private static readonly GUIContent GC_Down = new GUIContent(Ico._chevron_down);
		private static readonly GUIContent GC_Rotation = new GUIContent(Ico._rotate_right + "Rot", "Change prop rotation [Alt+ScrollWheel]");
		private static readonly GUIContent GC_RotStep = new GUIContent("±", "Increment to use when changing the current rotation");
		private static readonly GUIContent GC_EraseAll = new GUIContent(Ico._delete + " Remove All", "Remove all Props from selected Tile Layer");
		private static readonly GUIContent GC_RandomRotOn = new GUIContent(Ico._random_on, "Random Rotation of prop is on");
		private static readonly GUIContent GC_RandomRotOff = new GUIContent(Ico._random_off, "Random Rotation of prop is off");
		private static readonly GUIContent GC_RandomFabOn = new GUIContent(Ico._random_on, "Random prop prefab selection is on, using the selected rotation stepping value");
		private static readonly GUIContent GC_RandomFabOff = new GUIContent(Ico._random_off, "Random prop prefab selection is off");
		private static readonly GUIContent GC_RandomFabAllOn = new GUIContent(Ico._grid, "Choose a random prop prefab for each prop in the brush. Only when random is on.");
		private static readonly GUIContent GC_RandomFabAllOff = new GUIContent(Ico._grid_off, "Choose one random prop to represent all props in the brush. Only when Random is on.");
		private static readonly GUIContent GC_SelectionHead = new GUIContent(Ico._marquee + " Selection");
		private static readonly GUIContent GC_Copy = new GUIContent(Ico._copy + " Copy", "Copy the selection");
		private static readonly GUIContent GC_Cut = new GUIContent(Ico._cut + " Cut", "Cut the selection");
		private static readonly GUIContent GC_Erase = new GUIContent(Ico._eraser + " Erase", "Erase the selection");
		private static readonly GUIContent GC_CopyBufferHead = new GUIContent(Ico._memory + " Copy Buffer");
		private static readonly GUIContent GC_TemplatesHead = new GUIContent(Ico._cube + " Templates");
		private static readonly GUIContent GC_CreateTemplate = new GUIContent("Save to Template");
		private static readonly GUIContent GC_NoTemplates = new GUIContent("No Templates saved");
		private static readonly GUIContent GC_DelTmpl = new GUIContent(Ico._remove, "Delete Template");
		private static readonly GUIContent GC_Position = new GUIContent(Ico._offset + "Pos", "Change prop's position offset stepping within the tile area. This is only available when placing single props. If the brush size is bigger than one then this option is only useful if random is on");
		private static readonly GUIContent[] GC_PosOps = new GUIContent[] { new GUIContent("Center"), new GUIContent("½ Tile"), new GUIContent("⅓ Tile"), new GUIContent("¼ Tile"), new GUIContent("Free") };
		private static readonly GUIContent GC_RandomPosOn = new GUIContent(Ico._random_on, "Random Position offset within tile area of prop is on");
		private static readonly GUIContent GC_RandomPosOff = new GUIContent(Ico._random_off, "Random Position offset within tile area is off");
		private static readonly GUIContent GC_Fab = new GUIContent(Ico._cube + "Fab", "Should a random prefab be chosen when there are more than one available for the prop? With a brush size bigger than one you may also specify what the chance is of a prop being placed in a tile position the brush is over.");
		private static readonly GUIContent GC_Height = new GUIContent(Ico._swap_vert + "Y", "How should the prop's Y position be determined? [Ctrl+Alt+ScrollWheel] The Collider and Object options only works properly in single prop placement and not when the brush size is bigger than 1");
		private static readonly GUIContent[] GC_HeightOps = new GUIContent[] { new GUIContent("Grid"), new GUIContent("Colliders"), new GUIContent("Objects"), new GUIContent("Custom") };
		private static readonly GUIContent GC_Scale = new GUIContent(Ico._scale + "Size", "What kind of scaling should be applied to the placed prop");
		private static readonly GUIContent[] GC_ScaleOps = new GUIContent[] { new GUIContent("None"), new GUIContent("Random") };
		private static readonly GUIContent[] GC_Tools = new GUIContent[] { new GUIContent(Ico._brush, "[Q] Normal TileEd paint mode"), new GUIContent(Ico._move, "[W] Tool used to adjust the offset position of a placed prop"), new GUIContent(Ico._rotate, "[E] Tool used to adjust the rotation of a placed prop"), new GUIContent(Ico._scale, "[R] Tool used to adjust the scale of a placed prop") };

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public class PlacedPropInfo
		{
			/// <summary> the tile object that was placed in the scene </summary>
			public GameObject go;
			/// <summary> data saved in the TileEd map </summary>
			public TileEdMapTile tile;
			/// <summary> tile-group/ tile-layer this tile was placed under </summary>
			public TileEdMapGroup group;
		}

		/// <summary> Called after a tile was placed in the scene </summary>
		public static event System.Action<PlacedPropInfo> onPlacedProp = null;

		private TileEdPropSetsAsset asset;
		private TileEdTemplatesAsset tmplAsset;
		private plyEdGUI.ListOps listOps;
		private int tileSetIdx = -2;
		private int currTileIdx = -1;
		private static Vector2[] scroll = { Vector2.zero, Vector2.zero, Vector2.zero }; // 0: sets list, 1: settings tiles, 2: palette
		private int dragDropTarget = -2;		// -2:none, -1:main drop area, else index of an tile
		private int dragDropSubTarget = -2;		// -2:none, else index of an existing tile
		private float lastInspectorWidth = 0.0f;

		private int activeTool = 0;
		private Transform parentTr = null;		// the root of this tool within the active map/tool/group
		private int tileRotation = 0;
		private int tileRotStep = 45;
		private bool canRandomFab = true;
		private bool canRandomFabAll = true;
		private bool canRandomRotate = false;
		private int currRotOp = 3;
		private int currPosOp = 0; // 0:"Center", 1:"½ Tile", 2:"⅓ Tile", 3:"¼ Tile", 4:"Free"
		private int currHeightOp = 0;
		private float customHeightOffs = 0.0f;
		private bool canRandomPos = false;
		private int currScaleOp = 0;
		private float[] scaleMinMax = { 0.5f, 1.5f };
		private float[] minMaxPlace = { 100f, 100f }; // percentage
		private GameObject lastPickedForNonColl = null;
		private Bounds pickedBounds = new Bounds(Vector3.zero, new Vector3(1000, 1000, 1000));
		private TileEdProp propWaitCustomThumb = null;

		private bool wasClickOnSelected = false;
		private List<TileEdSelected> selection = new List<TileEdSelected>();
		private TileEdTemplate copyBuffer = new TileEdTemplate() { toolIdent = TOOL_IDENT };
		private GUIContent GC_CopyBuffer = new GUIContent(Ico._wait, "Click to enter paste mode");

		private plyListPopupWindow rotOpsPopup = null;
		private TileEd_Ed_Props_SettingsPopup propSettingsPopup = new TileEd_Ed_Props_SettingsPopup();

		private static bool def_setTag = false;
		private static string def_tag = "Untagged";
		private static bool def_setLayer = false;
		private static int def_layer = 0;
		private static bool def_setSort = false;
		private static int def_sortLayerNameIdx = 0;
		private static int def_sortOrder = 0;
		private static bool def_setStaticFlags = false;
		private static StaticEditorFlags def_staticFlags = (StaticEditorFlags)(-1);
		private static bool def_setNavArea = false;
		private static int def_navAreaNamesIdx = 1;

		private GUIContent[] GC_NavAreas = new GUIContent[] { new GUIContent("Walkable"), new GUIContent("Not Walkable") };
		private GUIContent[] GC_SortNames = new GUIContent[0];

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region settings

		public override int ToolIdent()
		{
			return TOOL_IDENT;
		}

		public override List<TileSetInfo> GetTileSets()
		{			
			List<TileSetInfo> res = new List<TileSetInfo>();
			if (LoadAsset())
			{
				for (int i = 0; i < asset.tileSets.Count; i++)
				{
					res.Add(new TileSetInfo() { toolIdent = TOOL_IDENT, setIdent = asset.tileSets[i].ident, setName = asset.tileSets[i].name });
				}
			}
			return res;
		}

		public override void OnSettingsFocus(EditorWindow ed)
		{
			string[] names = GameObjectUtility.GetNavMeshAreaNames();
			GC_NavAreas = new GUIContent[names.Length];
			for (int i = 0; i < names.Length; i++) GC_NavAreas[i] = new GUIContent(names[i]);
		}

		public override void OnSettingsGUI(EditorWindow ed)
		{
			base.OnSettingsGUI(ed);
			TileEdGUI.LoadResources();
			if (!LoadAsset()) return;

			if (listOps == null)
			{
				listOps = new plyEdGUI.ListOps()
				{
					emptyMsg = "Click [+] to add\na new Prop Set",
					canDuplicate = false,
					onAction = OnListAction,
					extraButtons = new plyEdGUI.ListOpsExtraToolbarButton[]
					{
						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._rename, "Rename Prop-Set"),
							callback = () => { plyTextInputWiz.ShowWiz("Rename Prop Set", null, asset.tileSets[tileSetIdx].name, DoRenamePropSet, null); },
							enabled = () => { return (tileSetIdx >= 0); },
							//shortcut = KeyCode.F2
						},
						new plyEdGUI.ListOpsExtraToolbarButton()
						{
							label = new GUIContent(Ico._help_c, "Open Documentation"),
							callback = () => { Application.OpenURL(TileEdGlobal.URL_DOCS); },
							//shortcut = KeyCode.F1
						}
					},
				};
			}

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.List<TileEdPropSet>(ref tileSetIdx, asset.tileSets, ref scroll[0], listOps, GUILayout.Width(150)) == 1)
				{
					dragDropTarget = -2; dragDropSubTarget = -2;
					scroll[1] = Vector2.zero;
				}

				Rect r = EditorGUILayout.BeginVertical();
				{
					if (tileSetIdx >= 0)
					{
						DrawPropSetSettings();
					}
					else
					{
						EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
						GUILayout.FlexibleSpace();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				plyEdUtil.SetDirty(asset);
			}
		}

		private int OnListAction(plyEdGUI.ListOps.ListAction act)
		{
			if (act == plyEdGUI.ListOps.ListAction.DoAdd)
			{
				string nm = plyEdUtil.GetUniqueString<TileEdPropSet>(asset.tileSets, "Prop Set ");
				plyTextInputWiz.ShowWiz("New Prop Set", null, nm, DoAddPropSet, null);
				return -2;
			}

			else if (act == plyEdGUI.ListOps.ListAction.DoRemoveSelected)
			{
				if (EditorUtility.DisplayDialog("Delete Prop Set", "This action can't be undone. Are you sure?", "Yes", "Cancel"))
				{
					asset.tileSets.RemoveAt(tileSetIdx);
					plyEdUtil.SetDirty(asset);
					return -1;
				}
				else return -2;
			}

			plyEdUtil.SetDirty(asset);
			return -2;
		}

		private void DoAddPropSet(plyTextInputWiz wiz)
		{
			string nm = wiz.text;
			wiz.Close();

			if (!string.IsNullOrEmpty(nm))
			{
				TileEdPropSet set = new TileEdPropSet();
				set.ident = asset.GeneratePropSetIdent();
				set.name = nm;

				asset.tileSets.Add(set);
				tileSetIdx = asset.tileSets.Count - 1;
				asset.GC_PropSets = null; // reset so that the list gets refreshed
				plyEdUtil.SetDirty(asset);
				settingsEd.Repaint();
			}
		}

		private void DoRenamePropSet(plyTextInputWiz wiz)
		{
			string nm = wiz.text;
			wiz.Close();

			if (tileSetIdx >= 0 && !string.IsNullOrEmpty(nm))
			{
				asset.tileSets[tileSetIdx].name = nm;
				asset.GC_PropSets = null; // reset so that the list gets refreshed
				plyEdUtil.SetDirty(asset);
				settingsEd.Repaint();
			}
		}

		private void DrawPropSetSettings()
		{
			Event ev = Event.current;
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(5);

			// allocate preview space
			int count = 1;
			for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++) count += asset.tileSets[tileSetIdx].tiles[i].prefab.Length;
			TileEdGlobal.PreviewAlloc(count, 0);

			Rect dropRect = GUILayoutUtility.GetRect(10, 85, TileEdGUI.Styles.DragDropBox, GUILayout.ExpandWidth(true));
			GUI.Box(dropRect, GC_DropArea, TileEdGUI.Styles.DragDropBox);

			Rect br = new Rect(dropRect.x + 3, dropRect.y + 3, 75, 16);
			def_setNavArea = EditorGUI.ToggleLeft(br, GC_SetNavArea, def_setNavArea);
			if (def_setNavArea) { br.x += 75; br.width = 100; def_navAreaNamesIdx = EditorGUI.Popup(br, def_navAreaNamesIdx, GC_NavAreas); br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setStaticFlags = EditorGUI.ToggleLeft(br, GC_SetStatic, def_setStaticFlags);
			if (def_setStaticFlags) { br.x += 75; br.width = 100; def_staticFlags = (StaticEditorFlags)EditorGUI.EnumFlagsField(br, def_staticFlags);br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setLayer = EditorGUI.ToggleLeft(br, GC_SetLayer, def_setLayer);
			if (def_setLayer) { br.x += 75; br.width = 100; def_layer = EditorGUI.LayerField(br, def_layer);br.x -= 75; br.width = 75; }
			br.y += br.height;
			def_setSort = EditorGUI.ToggleLeft(br, GC_SetSort, def_setSort);
			if (def_setSort)
			{
				br.x += 75; br.width = 80;
				TileEd.GetSortingLayerNames(ref GC_SortNames);
				def_sortLayerNameIdx = EditorGUI.Popup(br, def_sortLayerNameIdx, GC_SortNames);

				br.x += 80; br.width = 20;
				def_sortOrder = EditorGUI.IntField(br, def_sortOrder);
				br.x -= 155; br.width = 75;
			}
			br.y += br.height;
			def_setTag = EditorGUI.ToggleLeft(br, GC_SetTag, def_setTag);
			if (def_setTag) { br.x += 75; br.width = 100; def_tag = EditorGUI.TagField(br, def_tag); br.x -= 75; br.width = 75; }

			br = new Rect(dropRect.xMax - 55, dropRect.y + 17, 50, 50);
			if (GUI.Button(br, TileEdGUI.GC_AddButtonIcon, TileEdGUI.Styles.AddButtonIcon))
			{
				EditorGUIUtility.ShowObjectPicker<GameObject>(null, false, null, 0);
			}

			if (ev.type == EventType.DragUpdated && dropRect.Contains(ev.mousePosition))
			{
				dragDropTarget = -1; dragDropSubTarget = -2;
				DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
				ev.Use();
			}

			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
			{
				int settingsMaxX = (int)((Screen.width - 155) / 138);
				if (settingsMaxX < 1) settingsMaxX = 1;
				int cntX = 0;
				int rem = -1;
				bool open = false;
				for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++)
				{
					if (cntX == 0) { open = true; EditorGUILayout.BeginHorizontal(); }
					if (DrawPropSettings(ev, i, GUIContent.none, null, asset.tileSets[tileSetIdx].tiles[i]))
					{
						rem = i;
					}

					cntX++;
					if (cntX == settingsMaxX) { cntX = 0; GUILayout.FlexibleSpace(); EditorGUILayout.EndHorizontal(); open = false; }
				}

				if (open) { GUILayout.FlexibleSpace(); EditorGUILayout.EndHorizontal(); }

				if (rem >= 0)
				{
					asset.tileSets[tileSetIdx].tiles.RemoveAt(rem);
					plyEdUtil.SetDirty(asset);
				}

			}
			EditorGUILayout.Space();
			EditorGUILayout.EndScrollView();

			if (ev.type == EventType.ExecuteCommand && ev.commandName == "ObjectSelectorClosed")
			{	// add tile via the blue [+] button on drop area
				Object obj = EditorGUIUtility.GetObjectPickerObject();
				if (obj != null) AddPropToTileSet(new Object[] { obj });
				ev.Use();
			}

			if (ev.type == EventType.DragExited)
			{
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.DragPerform && dragDropTarget >= -1)
			{
				DragAndDrop.AcceptDrag();
				ev.Use();
				if (DragAndDrop.objectReferences.Length > 0)
				{
					if (dragDropTarget == -1) AddPropToTileSet(DragAndDrop.objectReferences);
					else if (dragDropTarget >= 0 && dragDropTarget < asset.tileSets[tileSetIdx].tiles.Count)
					{
						GameObject go = DragAndDrop.objectReferences[0] as GameObject;
						if (go == null)
						{
							Debug.LogWarning("The object could not be used since it is not a prefab: " + DragAndDrop.objectReferences[0].name, DragAndDrop.objectReferences[0]);
						}
						else
						{
							asset.tileSets[tileSetIdx].tiles[dragDropTarget].prefab[0] = go;
							plyEdUtil.SetDirty(asset);
						}
					}
				}
				dragDropTarget = -2; dragDropSubTarget = -2;
			}
		}

		private void AddPropToTileSet(Object[] objs)
		{
			for (int i = 0; i < objs.Length; i++)
			{
				GameObject go = objs[i] as GameObject;
				if (go == null)
				{
					Debug.LogWarning("The object could not be added since it is not a prefab: " + objs[i].name, objs[i]);
					continue;
				}

				if (false == asset.tileSets[tileSetIdx].ContainsPrefab(0, go))
				{
					TileEdProp t = new TileEdProp();
					t.ident = asset.GeneratePropIdent();
					t.prefab[0] = go;

					t.setTag = def_setTag;
					t.tag = def_tag;
					t.setLayer = def_setLayer;
					t.layer = def_layer;
					t.setStaticFlags = def_setStaticFlags;
					t.staticFlags = (int)def_staticFlags;
					t.setNavArea = def_setNavArea;
					t.navArea = GameObjectUtility.GetNavMeshAreaFromName(GC_NavAreas[def_navAreaNamesIdx].text);
					t.setSort = def_setSort;
					t.sortOrder = def_sortOrder;
					t.sortLayerId = TileEd.GetSortingLayerUniqueID(def_sortLayerNameIdx);

					asset.tileSets[tileSetIdx].tiles.Add(t);
				}
			}

			plyEdUtil.SetDirty(asset);
		}

		private bool DrawPropSettings(Event ev, int idx, GUIContent label, Texture2D icon, TileEdProp prop)
		{
			bool didRemoveFab0 = false;
			Rect r, br = new Rect(0, 0, 16, 16);
			EditorGUILayout.BeginVertical();
			{
				Rect rr = EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.Width(128));
				{
					if (icon != null)
					{
						EditorGUILayout.BeginHorizontal();
						{
							r = GUILayoutUtility.GetRect(32, 32, GUILayout.Width(32), GUILayout.Height(32));
							GUI.DrawTexture(r, icon);
							EditorGUILayout.BeginVertical();
							GUILayout.Label(label, TileEdGUI.Styles.TileHeading);
							prop.prefab[0] = (GameObject)EditorGUILayout.ObjectField(prop.prefab[0], typeof(GameObject), false);
							EditorGUILayout.EndVertical();
						}
						EditorGUILayout.EndHorizontal();
					}
					else
					{
						prop.prefab[0] = (GameObject)EditorGUILayout.ObjectField(prop.prefab[0], typeof(GameObject), false);
					}

					r = GUILayoutUtility.GetRect(128, 130, GUILayout.Width(128), GUILayout.Height(130));
					r.y += 2; r.height = 128;

					if (ev.type == EventType.Repaint)
					{
						if (prop.prefab[0] != null)
						{
							Texture2D tex = prop.customThumb == null ? AssetPreview.GetAssetPreview(prop.prefab[0]) : prop.customThumb;
							if (tex == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
							else GUI.Box(r, tex, TileEdGUI.Styles.TilePreview);
						}
						else
						{
							GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TilePreview);
						}
					}

					br.x = r.xMax - 16; br.y = r.y;
					if (GUI.Button(br, GC_ClearProp, plyEdGUI.Styles.Button))
					{
						if (EditorUtility.DisplayDialog("Remove Prop", "Are you sure you want to remove this prop from the set? This action can't be undone.", "Yes", "Cancel"))
						{
							didRemoveFab0 = true;
							prop.prefab[0] = null;
							plyEdUtil.SetDirty(asset);
						}
					}

					br.x = br.x - 17;
					if (GUI.Button(br, GC_CustomThumb, plyEdGUI.Styles.Button))
					{
						propWaitCustomThumb = prop;
						EditorGUIUtility.ShowObjectPicker<Texture2D>(prop.customThumb, false, null, 1);
					}

					br.x = br.x - 17;
					if (GUI.Button(br, GC_OpenPropSettingsPopup, plyEdGUI.Styles.Button))
					{
						propSettingsPopup.asset = asset;
						propSettingsPopup.tile = prop;
						PopupWindow.Show(br, propSettingsPopup);
					}

					if (prop.prefab[0] != null && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
					{
						EditorGUIUtility.PingObject(prop.prefab[0]);
						ev.Use();
					}

					if (ev.type == EventType.DragUpdated && r.Contains(ev.mousePosition))
					{
						dragDropTarget = idx; dragDropSubTarget = -2;
						DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
						ev.Use();
					}

					// draw the "random" tiles, if any
					GUILayoutUtility.GetRect(1, 3, GUILayout.Width(1), GUILayout.Height(3));
					if (prop.prefab.Length > 1)
					{
						int rem = -1;
						for (int i = 1; i < prop.prefab.Length; i++)
						{
							prop.prefab[i] = (GameObject)EditorGUILayout.ObjectField(prop.prefab[i], typeof(GameObject), false, GUILayout.Width(100));
							r = GUILayoutUtility.GetRect(100, 100, GUILayout.Width(100), GUILayout.Height(100));
							r.x = rr.x + 3;
							if (ev.type == EventType.Repaint)
							{
								if (prop.prefab[i] != null)
								{
									Texture2D tex = AssetPreview.GetAssetPreview(prop.prefab[i]);
									if (tex == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
									else GUI.Box(r, tex, TileEdGUI.Styles.TilePreview);
								}
								else
								{
									GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TilePreview);
								}
							}
							GUILayout.Space(3);

							br.x = r.xMax - 16; br.y = r.y;
							if (GUI.Button(br, GC_ClearProp, plyEdGUI.Styles.Button)) rem = i;

							if (prop.prefab[i] != null && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
							{
								EditorGUIUtility.PingObject(prop.prefab[i]);
								ev.Use();
							}

							if (ev.type == EventType.DragUpdated && r.Contains(ev.mousePosition))
							{
								dragDropTarget = idx; dragDropSubTarget = i;
								DragAndDrop.visualMode = DragAndDropVisualMode.Generic;
								ev.Use();
							}
						}

						if (rem >= 1)
						{
							ArrayUtility.RemoveAt(ref prop.prefab, rem);
							plyEdUtil.SetDirty(asset);
						}
					}

					if (GUILayout.Button(GC_AddRandomProp, plyEdGUI.Styles.MiniButton, GUILayout.Width(25)))
					{
						ArrayUtility.Add(ref prop.prefab, null);
						plyEdUtil.SetDirty(asset);
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndVertical();

			if (ev.type == EventType.DragExited)
			{
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.DragPerform && dragDropTarget == idx)
			{
				DragAndDrop.AcceptDrag();
				ev.Use();
				if (DragAndDrop.objectReferences.Length > 0)
				{
					GameObject go = DragAndDrop.objectReferences[0] as GameObject;
					if (go == null)
					{
						Debug.LogWarning("The object could not be used since it is not a prefab: " + DragAndDrop.objectReferences[0].name, DragAndDrop.objectReferences[0]);
					}
					else
					{
						if (dragDropSubTarget >= 1) prop.prefab[dragDropSubTarget] = go;
						else prop.prefab[0] = go;
						plyEdUtil.SetDirty(asset);
					}
				}
				dragDropTarget = -2; dragDropSubTarget = -2;
			}

			if (ev.type == EventType.ExecuteCommand && ev.commandName == "ObjectSelectorClosed" && 
				EditorGUIUtility.GetObjectPickerControlID() == 1)
			{
				if (propWaitCustomThumb != null)
				{
					propWaitCustomThumb.customThumb = EditorGUIUtility.GetObjectPickerObject() as Texture2D;
					plyEdUtil.SetDirty(asset);
				}

				propWaitCustomThumb = null;
				ev.Use();
			}

			return didRemoveFab0;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region palette

		public override string PaletteName()
		{
			return "Props";
		}

		public override int PaletteOrder()
		{
			return 2;
		}

		public override void OnPalleteFocus()
		{
			if (!LoadAsset()) return;

			ClearSelection();
			ClearPasteMode();
			OnMapChanged();

			if (tileSetIdx >= 0 && tileSetIdx < asset.tileSets.Count)
			{
				if (currTileIdx >= 0 && currTileIdx < asset.tileSets[tileSetIdx].tiles.Count)
				{
					TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
				}
				else
				{
					scroll[2] = Vector2.zero;
					ClearCurrTile();
				}
			}
			else
			{
				tileSetIdx = -1;
				ClearCurrTile();
				scroll[2] = Vector2.zero;
			}
		}

		public override void OnPalleteLooseFocus()
		{
			ClearSelection();
			ClearPasteMode();
			parentTr = null;
			TileEd.grid.UpdatePreviewObject(null, 0f);
		}

		public override void OnPaletteGUI()
		{
			if (asset.tileSets.Count == 0) return;

			if (tileSetIdx < 0) tileSetIdx = 0;
			if (!TileEdGlobal.paletteDocked) GUILayout.Space(5);

			int prev = tileSetIdx;
			if (TileEdGlobal.paletteLayout == 0 || !TileEdGlobal.paletteDocked)
			{
				EditorGUILayout.BeginHorizontal();
				{
					tileSetIdx = EditorGUILayout.Popup(tileSetIdx, asset.GC_PropSets);
					for (int i = 0; i < asset.tileSets.Count; i++)
					{
						if (GUILayout.Toggle(tileSetIdx == i, asset.tileSets[i].name, TileEdGUI.Styles.PaletteTab))
						{
							tileSetIdx = i;
						}
					}
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
			}
			else
			{
				tileSetIdx = EditorGUILayout.Popup(tileSetIdx, asset.GC_PropSets);
			}

			if (prev != tileSetIdx)
			{
				ClearPasteMode(); // just in case in paste mode
				ClearSelection(); // in case selection mode was on

				scroll[2] = Vector2.zero;
				ClearCurrTile();

				TileEd_PalettePanel.DoRepaint();
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}

			Event ev = Event.current;
			HandleGridEvents(ev);
			if (ev.type == EventType.Repaint)
			{
				hasLoadingPalettePreviews = false;
			}

			Rect mainRect = EditorGUILayout.BeginVertical(TileEdGlobal.paletteLayout == 0 || !TileEdGlobal.paletteDocked ? TileEdGUI.Styles.BoxTopBorder : TileEdGUI.Styles.BoxRightBorder, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndVertical();

			if (asset.tileSets[tileSetIdx].tiles.Count > 0)
			{
				TileEdGlobal.PreviewAlloc(asset.tileSets[tileSetIdx].tiles.Count + 1, 0);

				mainRect.y += 1;
				int sz = (TileEdGlobal.palettePreviewSize + 2);
				int maxW = (int)mainRect.width - 5;
				int maxX = maxW / sz;
				if (maxX < 1) maxX = 1;

				Rect r = new Rect(0, 0, 5 + (sz * maxX), (asset.tileSets[tileSetIdx].tiles.Count / maxX) * sz + sz + 10);

				if (ev.type == EventType.ScrollWheel && mainRect.Contains(ev.mousePosition))
				{
					scroll[2].y += (ev.delta.y > 0 ? sz : -sz);
					ev.Use();
				}

				Rect u_R = new Rect(mainRect.xMax - 20, mainRect.yMax - 40, 20, 18);
				if (!TileEdGlobal.paletteDocked) { u_R.y = 40; u_R.x -= 2; }
				Rect d_R = u_R; d_R.y += 18;

				if (ev.type == EventType.MouseDown && ev.button == 0)
				{
					if (u_R.Contains(ev.mousePosition))
					{
						scroll[2].y -= sz;
						ev.Use();
					}
					else if (d_R.Contains(ev.mousePosition))
					{
						scroll[2].y += sz;
						ev.Use();
					}
				}

				// draw tiles
				scroll[2] = GUI.BeginScrollView(mainRect, scroll[2], r, false, false, GUIStyle.none, GUIStyle.none);
				{
					if (currTileIdx >= asset.tileSets[tileSetIdx].tiles.Count)
					{
						ClearCurrTile();
					}

					int rem = -1;
					Rect starR = new Rect(0, 0, 20, 20);
					r = new Rect(5, 2, TileEdGlobal.palettePreviewSize, TileEdGlobal.palettePreviewSize);

					for (int i = 0; i < asset.tileSets[tileSetIdx].tiles.Count; i++)
					{
						if (asset.tileSets[tileSetIdx].tiles[i] == null) continue;
						if (asset.tileSets[tileSetIdx].tiles[i].prefab[0] == null)
						{
							if (currTileIdx == i)
							{
								ClearCurrTile();
								TileEd_PalettePanel.DoRepaint();
							}
							continue;
						}

						if (DrawTileOnPalette(currTileIdx == i, ev, asset.tileSets[tileSetIdx].tiles[i], r, starR))
						{
							currTileIdx = i;
							TileEd.grid.UpdatePreviewObject(asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[0], tileRotation);
							TileEd_PalettePanel.DoRepaint();
							plyEdUtil.RepaintInspector(typeof(TileEd));
						}

						r.x += sz;
						if (r.xMax > maxW) { r.x = 5; r.y += sz; }

					}

					if (rem >= 0)
					{
						asset.tileSets[tileSetIdx].tiles.RemoveAt(rem);
						plyEdUtil.SetDirty(asset);
					}
				}
				GUI.EndScrollView();

				if (ev.type == EventType.Repaint)
				{
					plyEdGUI.Styles.Button.Draw(u_R, GC_Up, false, false, false, false);
					plyEdGUI.Styles.Button.Draw(d_R, GC_Down, false, false, false, false);
				}
			}
		}

		private bool DrawTileOnPalette(bool selected, Event ev, TileEdProp prop, Rect r, Rect starR)
		{
			if (ev.type == EventType.Repaint)
			{
				if (prop.prefab != null && prop.prefab.Length > 0 && prop.prefab[0] != null)
				{
					Texture2D tex = prop.customThumb == null ? AssetPreview.GetAssetPreview(prop.prefab[0]) : prop.customThumb;
					if (tex == null)
					{
						hasLoadingPalettePreviews = true;
						GUI.Box(r, GC_Wait, TileEdGUI.Styles.TileBox);
					}
					else GUI.Box(r, tex, TileEdGUI.Styles.TileBox);
				}
				else GUI.Box(r, GUIContent.none, TileEdGUI.Styles.TileBox);

				if (selected) TileEdGUI.Styles.TileSelected.Draw(r, false, false, false, false);
			}

			if (ev.button == 0 && ev.type == EventType.MouseDown && r.Contains(ev.mousePosition))
			{
				ClearPasteMode(); // just in case in paste mode
				ClearSelection(); // in case selection mode was on
				ev.Use();
				return true;
			}

			return false;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region inspector

		public override void OnInspector(Editor inspectorEd)
		{
			HandleGridEvents(Event.current); // Events

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				tileRotation = plyEdGUI.IntStepField(GC_Rotation, tileRotation, tileRotStep, plyEdGUI.EdFieldState.Normal, 0, 360, true);
				if (EditorGUI.EndChangeCheck()) TileEd.grid.UpdatePreviewObjectRotation(tileRotation);

				EditorGUIUtility.labelWidth = 15;
				EditorGUI.BeginChangeCheck();
				tileRotStep = EditorGUILayout.IntField(GC_RotStep, tileRotStep, plyEdGUI.Styles.ToolbarTextField, GUILayout.Width(45));
				if (EditorGUI.EndChangeCheck()) 
				{
					EditorPrefs.SetInt("TileEd.Props.tileRotStep", tileRotStep);
					tileRotation = 0; TileEd.grid.UpdatePreviewObjectRotation(tileRotation);
					UpdateRotOp();
				}

				Rect rect = GUILayoutUtility.GetRect(plyEdGUI.GC_DropDownIcon, plyEdGUI.Styles.Label);
				if (GUI.Button(rect, plyEdGUI.GC_DropDownIcon, plyEdGUI.Styles.Label))
				{
					if (rotOpsPopup == null)
					{
						rotOpsPopup = new plyListPopupWindow(
								() => { return currRotOp; },
								(int v) => { currRotOp = v; if (currRotOp > 0) { tileRotStep = RotOps[currRotOp - 1]; EditorPrefs.SetInt("TileEd.Props.tileRotStep", tileRotStep); tileRotation = 0; TileEd.grid.UpdatePreviewObjectRotation(tileRotation); } },
								new GUIContent[] { new GUIContent("custom"), new GUIContent("180"), new GUIContent("90"), new GUIContent("45"), new GUIContent("30"), new GUIContent("15"), new GUIContent("10"), new GUIContent("5") }
						);
					}
					PopupWindow.Show(rect, rotOpsPopup);
				}

				EditorGUIUtility.labelWidth = 0;
				if (plyEdGUI.ToggleButton(canRandomRotate, canRandomRotate ? GC_RandomRotOn : GC_RandomRotOff, plyEdGUI.Styles.ToolbarButton))
				{
					canRandomRotate = !canRandomRotate;
					EditorPrefs.SetBool("TileEd.Props.canRandomRotate", canRandomRotate);
				}
				
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				currPosOp = plyEdGUI.ToolbarPopup(GC_Position, currPosOp, GC_PosOps, GUILayout.Width(59));
				if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.Props.currPosOp", currPosOp);

				if (plyEdGUI.ToggleButton(canRandomPos, canRandomPos ? GC_RandomPosOn : GC_RandomPosOff, plyEdGUI.Styles.ToolbarButton))
				{
					canRandomPos = !canRandomPos;
					EditorPrefs.SetBool("TileEd.Props.canRandomPos", canRandomPos);
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				currHeightOp = plyEdGUI.ToolbarPopup(GC_Height, currHeightOp, GC_HeightOps, GUILayout.Width(59));
				if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.Props.currHeightOp", currHeightOp);

				if (currHeightOp == 3)
				{
					EditorGUI.BeginChangeCheck();
					customHeightOffs = EditorGUILayout.FloatField(customHeightOffs, EditorStyles.toolbarTextField, GUILayout.Width(30));
					if (EditorGUI.EndChangeCheck()) EditorPrefs.SetFloat("TileEd.Props.customHeightOffs", customHeightOffs);
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				EditorGUIUtility.labelWidth = 45;
				EditorGUI.BeginChangeCheck();
				currScaleOp = plyEdGUI.ToolbarPopup(GC_Scale, currScaleOp, GC_ScaleOps, GUILayout.Width(59));
				if (EditorGUI.EndChangeCheck()) EditorPrefs.SetInt("TileEd.Props.currScaleOp", currScaleOp);

				if (currScaleOp == 1)
				{
					EditorGUI.BeginChangeCheck();
					EditorGUILayout.MinMaxSlider(ref scaleMinMax[0], ref scaleMinMax[1], 0.1f, 3f);
					scaleMinMax[0] = EditorGUILayout.FloatField(scaleMinMax[0], plyEdGUI.Styles.ToolbarTextFieldNoMargin, GUILayout.Width(25));
					scaleMinMax[1] = EditorGUILayout.FloatField(scaleMinMax[1], plyEdGUI.Styles.ToolbarTextFieldNoMargin, GUILayout.Width(25));
					if (EditorGUI.EndChangeCheck())
					{
						EditorPrefs.SetFloat("TileEd.Props.scaleMinMax0", scaleMinMax[0]);
						EditorPrefs.SetFloat("TileEd.Props.scaleMinMax1", scaleMinMax[1]);
					}
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				GUILayout.Label(GC_Fab, plyEdGUI.Styles.Label, GUILayout.Width(41));

				if (plyEdGUI.ToggleButton(canRandomFab, canRandomFab ? GC_RandomFabOn : GC_RandomFabOff, plyEdGUI.Styles.ToolbarButton))
				{
					canRandomFab = !canRandomFab;
					EditorPrefs.SetBool("TileEd.Props.canRandomFab", canRandomFab);
				}
				if (canRandomFab)
				{
					if (plyEdGUI.ToggleButton(canRandomFabAll, canRandomFabAll ? GC_RandomFabAllOn : GC_RandomFabAllOff, plyEdGUI.Styles.ToolbarButton))
					{
						canRandomFabAll = !canRandomFabAll;
						EditorPrefs.SetBool("TileEd.Props.canRandomFabAll", canRandomFabAll);
					}
				}
				if (TileEd.Instance.group.brushSize > 1)
				{
					EditorGUI.BeginChangeCheck();
					EditorGUILayout.MinMaxSlider(ref minMaxPlace[0], ref minMaxPlace[1], 0f, 100f);
					minMaxPlace[0] = EditorGUILayout.FloatField(minMaxPlace[0], plyEdGUI.Styles.ToolbarTextFieldNoMargin, GUILayout.Width(25));
					minMaxPlace[1] = EditorGUILayout.FloatField(minMaxPlace[1], plyEdGUI.Styles.ToolbarTextFieldNoMargin, GUILayout.Width(25));
					if (EditorGUI.EndChangeCheck())
					{
						EditorPrefs.SetFloat("TileEd.Props.minMaxPlace0", minMaxPlace[0]);
						EditorPrefs.SetFloat("TileEd.Props.minMaxPlace1", minMaxPlace[1]);
					}
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			GUILayout.Space(2);
			EditorGUILayout.BeginHorizontal(plyEdGUI.Styles.Toolbar);
			{
				if (plyEdGUI.ToggleButton(activeTool == 0, GC_Tools[0], plyEdGUI.Styles.ToolbarButton)) { activeTool = 0; ClearPasteMode(); }
				if (plyEdGUI.ToggleButton(activeTool == 1, GC_Tools[1], plyEdGUI.Styles.ToolbarButton)) { activeTool = 1; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); }
				if (plyEdGUI.ToggleButton(activeTool == 2, GC_Tools[2], plyEdGUI.Styles.ToolbarButton)) { activeTool = 2; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); }
				if (plyEdGUI.ToggleButton(activeTool == 3, GC_Tools[3], plyEdGUI.Styles.ToolbarButton)) { activeTool = 3; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); }

				GUILayout.Space(5);
				if (GUILayout.Button(GC_EraseAll, plyEdGUI.Styles.ToolbarButton))
				{
					if (EditorUtility.DisplayDialog("TileEd", "Remove all Tiles from active Tile Layer. This action can't be undone. Are you sure?", "Yes", "Cancel"))
					{
						activeTool = 0;
						ClearSelection();
						EraseAllTilesFromActiveGroup();
					}
				}

				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();

			// Selection (copy/cut/remove)
			if (selection.Count > 0)
			{
				EditorGUILayout.Space();
				GUILayout.Label(GC_SelectionHead, plyEdGUI.Styles.LargeLabel);
				EditorGUILayout.BeginHorizontal();
				{
					if (GUILayout.Button(GC_Copy, plyEdGUI.Styles.ButtonLeft)) CopySelection(true);
					if (GUILayout.Button(GC_Cut, plyEdGUI.Styles.ButtonMid)) CutSelection();
					if (GUILayout.Button(GC_Erase, plyEdGUI.Styles.ButtonRight)) DeleteSelection();
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();
			}

			// Copy Buffer
			if (copyBuffer.tiles.Count > 0)
			{
				EditorGUILayout.Space();
				GUILayout.Label(GC_CopyBufferHead, plyEdGUI.Styles.LargeLabel);

				if (copyBuffer.texture == null)
				{
					copyBuffer.texture = AssetPreview.GetAssetPreview(copyBuffer.prefab);
				}

				if (copyBuffer.texture != null)
				{
					GC_CopyBuffer.text = null;
					GC_CopyBuffer.image = copyBuffer.texture;
				}
				else
				{
					GC_CopyBuffer.text = Ico._wait;
					GC_CopyBuffer.image = null;
				}

				if (GUILayout.Button(GC_CopyBuffer, TileEdGUI.Styles.TilePreview, GUILayout.Width(100), GUILayout.Height(100)))
				{
					EnterPasteMode();
				}

				if (GUILayout.Button(GC_CreateTemplate, plyEdGUI.Styles.MiniButton, GUILayout.Width(100)))
				{
					CreateNewTemplate();
				}
			}

			// Templates
			TemplatesInspector();
		}

		public override void Update(Editor inspectorEd)
		{
			if (copyBuffer.tiles.Count > 0 && AssetPreview.IsLoadingAssetPreviews())
			{
				inspectorEd.Repaint();
			}
		}

		//public override void DoCacheMap()
		//{
		//	// can't cache props since they can share grid positions
		//	buildingCache = false;
		//}

		public override void OnMapChanged()
		{
			OnGroupChanged();
		}

		public override void OnGroupChanged()
		{
			ClearSelection();
			activeTool = 0;
			parentTr = null;
			if (TileEd.Instance != null && TileEd.Instance.map != null && TileEd.Instance.mapTr != null)
			{
				// find the Tool's main object, else create one
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr == null)
				{
					GameObject go = new GameObject(ROOT_NAME);
					tr = go.transform;
					tr.parent = TileEd.Instance.mapTr;
				}

				// now find the group object, or create one
				string groupIdent = TileEd.Instance.group.ident.ToString();
				parentTr = tr.Find(groupIdent);
				if (parentTr == null)
				{
					GameObject go = new GameObject(groupIdent);
					parentTr = go.transform;
					parentTr.parent = tr;
					EditorSceneManager.MarkAllScenesDirty();
				}
			}
		}

		public override void OnGroupVisibiliyChanged(int groupIdent, bool visible)
		{
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null) return; // no point to continue if the tool has not done anything yet

			// find the group root, if any exist
			string nm = groupIdent.ToString();
			for (int i = 0; i < topRoot.childCount; i++)
			{
				Transform tr = topRoot.GetChild(i);
				if (tr.name == nm)
				{
					tr.gameObject.SetActive(visible);
					return;
				}
			}
		}

		public override void OnDeletingGroup(TileEdMapGroup group)
		{
			// remove the game object that were placed by this tool
			// by simply deleting the whole group
			parentTr = null; // also, reset this just in case

			if (TileEd.Instance.map != null && TileEd.Instance.mapTr != null)
			{
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr != null)
				{
					tr = tr.Find(group.ident.ToString());
					if (tr != null)
					{
						Object.DestroyImmediate(tr.gameObject);
					}
				}
			}

			// remove meshes related to this group
			plyEdUtil.CheckPath(TileEdGlobal.MESH_PATH + "Props/");
			string s = TOOL_IDENT.ToString();
			for (int i = 0; i < group.combinedMeshNames.Count; i++)
			{
				if (group.combinedMeshNames[i].StartsWith(s))
				{
					AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + "Props/" + group.combinedMeshNames[i] + ".asset");
				}
			}
		}

		public override void OnDuplicatedGroup(TileEdMapGroup group)
		{
			RecreateGroup(group, false);
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region map and group manipulation

		public override void RecreateMap()
		{
			if (TileEdGlobal.recreateIgnoreProps) return;

			ClearSelection();
			activeTool = 0;

			// make sure this tool's asset is loaded
			if (!LoadAsset()) return;
			plyEdUtil.CheckPath(TileEdGlobal.MESH_PATH + "Props/");

			// setup a few things
			string s = TOOL_IDENT.ToString();
			GameObject go;
			parentTr = null;
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null)
			{
				go = new GameObject(ROOT_NAME);
				topRoot = go.transform;
				topRoot.parent = TileEd.Instance.mapTr;
			}

			ClearUndo();

			// recreate the tiles in the various groups
			for (int grpIdx = 0; grpIdx < TileEd.Instance.map.groups.Count; grpIdx++)
			{
				TileEdMapGroup group = TileEd.Instance.map.groups[grpIdx];
				Transform tr = null;

				// first delete the mesh assets
				for (int i = 0; i < group.combinedMeshNames.Count; i++)
				{
					if (group.combinedMeshNames[i].StartsWith(s))
					{
						AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + "Props/" + group.combinedMeshNames[i] + ".asset");
					}
				}

				for (int tileIdx = 0; tileIdx < group.Count; tileIdx++)
				{
					if (group[tileIdx].toolIdent == TOOL_IDENT)
					{
						// find the tile in tiles asset
						TileEdPropSet tileSet = asset.FindTileSet(group[tileIdx].data[_TileSetIdent]);
						if (tileSet == null)
						{
							Debug.LogWarning("[Tiles] Could not find Tile Set for tiles used in map. You probably deleted the Tile Set after having placed tiles from it in the scene.");
							continue;
						}

						TileEdProp tile = tileSet.FindTile(group[tileIdx].data[_TileIdent]);
						if (tileSet == null)
						{
							Debug.LogWarning("[Tiles] Could not find Tile for the tile used in map. You probably deleted the Tile from The Tile Set after having placed the tile from it in the scene.");
							continue;
						}

						int fabIdx = group[tileIdx].data[_TileFabIdx];
						if (tile.prefab[fabIdx] == null)
						{
							Debug.LogWarning("[Tiles] The tile prefab is null. You probably deleted the prefab without updating the Tile Set.");
							continue;
						}

						// create root object for group in the tool's root
						if (tr == null)
						{
							tr = topRoot.Find(group.ident.ToString());
							if (tr == null)
							{
								go = new GameObject(group.ident.ToString());
								tr = go.transform;
								tr.parent = topRoot;
							}
						}

						Vector3? rotation = null;
						Vector3? scale = null;
						if (string.IsNullOrEmpty(group[tileIdx].extraData[_eData_Rotation]) == false) rotation = plyUtil.DecodeVector3(group[tileIdx].extraData[_eData_Rotation], Vector3.zero);
						if (string.IsNullOrEmpty(group[tileIdx].extraData[_eData_Scale]) == false) scale = plyUtil.DecodeVector3(group[tileIdx].extraData[_eData_Scale], Vector3.zero);

						// create the object in scene
						CreateTileObject(false, group[tileIdx].extraData[_eData_Ident], tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], group[tileIdx].offsPos, rotation, scale, tile, group.tileSize, group.tileHeight);
					}
				}
			}
		}

		public override void RecreateGroup(TileEdMapGroup group, bool fromMain)
		{
			if (fromMain && TileEdGlobal.recreateIgnoreProps) return;

			ClearSelection();
			activeTool = 0;

			// make sure this tool's asset is loaded
			if (!LoadAsset()) return;

			// setup a few things
			string s = TOOL_IDENT.ToString();
			GameObject go;
			parentTr = null;
			Transform topRoot = TileEd.Instance.mapTr.Find(ROOT_NAME);
			if (topRoot == null)
			{
				go = new GameObject(ROOT_NAME);
				topRoot = go.transform;
				topRoot.parent = TileEd.Instance.mapTr;
			}

			// delete the mesh assets
			for (int i = 0; i < group.combinedMeshNames.Count; i++)
			{
				if (group.combinedMeshNames[i].StartsWith(s))
				{
					AssetDatabase.DeleteAsset(TileEdGlobal.MESH_PATH + "Props/" + group.combinedMeshNames[i] + ".asset");
				}
			}

			// delete old group root and all child objects (tiles)
			Transform tr = topRoot.Find(group.ident.ToString());
			if (tr != null)
			{
				Object.DestroyImmediate(tr.gameObject);
			}

			ClearUndo();

			// create new group root
			go = new GameObject(group.ident.ToString());
			tr = go.transform;
			tr.parent = topRoot;
			List<int> rem = new List<int>();

			for (int tileIdx = 0; tileIdx < group.Count; tileIdx++)
			{
				if (group[tileIdx].toolIdent == TOOL_IDENT)
				{
					// find the tile in tiles asset
					TileEdPropSet tileSet = asset.FindTileSet(group[tileIdx].data[_TileSetIdent]);
					if (tileSet == null)
					{
						Debug.LogWarning("[Tiles] Could not find Tile Set for tiles used in map. You probably deleted the Tile Set after having placed tiles from it in the scene. The tile will be removed from the TileEd Map Data.");
						rem.Add(tileIdx);
						continue;
					}

					TileEdProp tile = tileSet.FindTile(group[tileIdx].data[_TileIdent]);
					if (tile == null)
					{
						Debug.LogWarning("[Tiles] Could not find Tile for the tile used in map. You probably deleted the Tile from The Tile Set after having placed the tile from it in the scene. The tile will be removed from the TileEd Map Data.");
						rem.Add(tileIdx);
						continue;
					}

					int fabIdx = group[tileIdx].data[_TileFabIdx];
					if (tile.prefab[fabIdx] == null)
					{
						Debug.LogWarning("[Tiles] The tile prefab is null. You probably deleted the prefab without updating the Tile Set. The tile will not be removed from the TileEd Data. You can go to the Tile Set's settings and add a new prefab over the empty tile to fix it. You can also remove it completely and then choose the Tile Layer or Map recreate option to have the tile removed from the TileEd map data.");
						continue;
					}

					Vector3? rotation = null;
					Vector3? scale = null;
					if (string.IsNullOrEmpty(group[tileIdx].extraData[_eData_Rotation]) == false) rotation = plyUtil.DecodeVector3(group[tileIdx].extraData[_eData_Rotation], Vector3.zero);
					if (string.IsNullOrEmpty(group[tileIdx].extraData[_eData_Scale]) == false) scale = plyUtil.DecodeVector3(group[tileIdx].extraData[_eData_Scale], Vector3.zero);

					// create the object in scene
					CreateTileObject(false, group[tileIdx].extraData[_eData_Ident], tr, tile.prefab[fabIdx], group[tileIdx].gridPos, group[tileIdx].data[_TileRotation], group[tileIdx].offsPos, rotation, scale, tile, group.tileSize, group.tileHeight);
				}
			}

			if (rem.Count > 0)
			{
				for (int i = rem.Count - 1; i >= 0; i--)
				{
					//group.tiles.RemoveAt(rem[i]);
					group.RemoveTile(rem[i]);
				}

				plyEdUtil.SetDirty(TileEd.Instance.map);
				EditorSceneManager.MarkAllScenesDirty();
			}

		}

		public override void ReplaceTilesInMap(TileSetInfo oldSetNfo, TileSetInfo newSetNfo)
		{
			TileEdPropSet oldSet = asset.FindTileSet(oldSetNfo.setIdent);
			TileEdPropSet newSet = asset.FindTileSet(newSetNfo.setIdent);
			if (oldSet == null) { Debug.LogError("[ReplaceTilesInMap] Could not find the old PropSet"); return; }
			if (newSet == null) { Debug.LogError("[ReplaceTilesInMap] Could not find the new PropSet"); return; }

			for (int grpIdx = 0; grpIdx < TileEd.Instance.map.groups.Count; grpIdx++)
			{
				TileEdMapGroup group = TileEd.Instance.map.groups[grpIdx];
				for (int tIdx = 0; tIdx < group.Count; tIdx++)
				{
					if (group[tIdx].toolIdent != TOOL_IDENT) continue;
					if (group[tIdx].data[_TileSetIdent] != oldSet.ident) continue;

					// find the idx of the tile in the set since it must be matched to tile in same position of new set
					int oldTileIdent = group[tIdx].data[_TileIdent];
					int tileIdxInSet = -1;
					for (int i = 0; i < oldSet.tiles.Count; i++)
					{
						if (oldSet.tiles[i].ident == oldTileIdent) { tileIdxInSet = i; break; } 
					}

					if (tileIdxInSet < 0 || tileIdxInSet >= newSet.tiles.Count) continue;
					TileEdProp t = newSet.tiles[tileIdxInSet];

					// if there is no fab at idx then use the one at 0 (or ignore if none there either)
					int tileFabIdx = group[tIdx].data[_TileFabIdx];
					if (tileFabIdx >= t.prefab.Length || t.prefab[tileFabIdx] == null)
					{
						tileFabIdx = 0;
						if (t.prefab[0] == null) continue;
					}

					group[tIdx].data[_TileSetIdent] = newSet.ident;
					group[tIdx].data[_TileIdent] = t.ident;
					group[tIdx].data[_TileFabIdx] = tileFabIdx;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region events

		public override void HandleGridEvents(Event ev)
		{
			if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.Q) { ev.Use(); activeTool = 0; ClearPasteMode(); plyEdUtil.RepaintInspector(typeof(TileEd)); return; }

			if (selection.Count > 0)
			{
				if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.W) { ev.Use(); activeTool = 1; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); plyEdUtil.RepaintInspector(typeof(TileEd)); return; }
				if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.E) { ev.Use(); activeTool = 2; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); plyEdUtil.RepaintInspector(typeof(TileEd)); return; }
				if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.R) { ev.Use(); activeTool = 3; ClearCurrTile(); ClearPasteMode(); ClearSelection(true); plyEdUtil.RepaintInspector(typeof(TileEd)); return; }
			}

			// right-click clear selection/ pasting
			if ((TileEd.grid.cursorMode == TileEdCursorMode.Paste || selection.Count > 0) &&
				((ev.type == EventType.MouseDown && ev.button == 1) || (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.Escape)))
			{
				ClearSelection();
				ClearPasteMode();
				ev.Use();
				return;
			}

			if ((currTileIdx >= 0 || TileEd.grid.cursorMode == TileEdCursorMode.Paste) && ev.type == EventType.ScrollWheel && ev.modifiers == (EventModifiers.Control | EventModifiers.Alt))
			{
				currHeightOp = 3;
				customHeightOffs += (ev.delta.y > 0.0f ? -0.1f : 0.1f);
				TileEd.grid.UpdatePreviewObjectYPos(customHeightOffs);
				plyEdUtil.RepaintInspector(typeof(TileEd));
				ev.Use();
				return;
			}

			if (selection.Count > 0)
			{
				if (ev.type == EventType.ValidateCommand)
				{
					switch (ev.commandName)
					{
						case "Duplicate":
						case "Cut":
						case "Copy":
						case "Delete":
						case "SoftDelete": ev.Use(); return;
					}
				}

				else if (ev.type == EventType.ExecuteCommand)
				{
					switch (ev.commandName)
					{
						case "Duplicate": { DuplicateSelection(); ev.Use(); } return;
						case "Cut": { CutSelection(); ev.Use(); } return;
						case "Copy": { CopySelection(true); ev.Use(); } return;
						case "Delete":
						case "SoftDelete": { DeleteSelection(); ev.Use(); } return;
					}
				}

				else if (ev.type == EventType.KeyDown && ev.keyCode == KeyCode.Delete)
				{
					DeleteSelection();
					ev.Use();
					return;
				}
			}

			if (copyBuffer.tiles.Count > 0)
			{
				if (ev.type == EventType.ValidateCommand)
				{
					if (ev.commandName == "Paste")
					{
						ev.Use();
					}
				}

				else if (ev.type == EventType.ExecuteCommand)
				{
					if (ev.commandName == "Paste")
					{
						EnterPasteMode();
						ev.Use();
					}
				}
			}

			// check if should clear selected tile
			if (ev.type == EventType.KeyUp && ev.keyCode == KeyCode.Escape)
			{
				if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
				{
					ev.Use();
					ClearPasteMode();
				}

				else if (currTileIdx >= 0)
				{
					ev.Use();
					ClearCurrTile();
				}
			}

			// check if should rotate tile
			if (ev.modifiers == EventModifiers.Alt && ev.type == EventType.ScrollWheel)
			{
				tileRotation = ClampTileRotation(tileRotation + (ev.delta.y > 0.0f ? +tileRotStep : -tileRotStep));
				ev.Use();

				TileEd.grid.UpdatePreviewObjectRotation(tileRotation);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region grid

		public override bool CanShowCursor()
		{
			return (activeTool == 0); // do not show grid cursor while in prop move/rotate/scale mode
		}

		public override Vector3 PreviewPosition(Vector3 previewPos, Vector3 mouseWorldPos, Vector3 gridWorldPos, IntVector3 gridPos)
		{
			if (canRandomPos) return previewPos;
			return CalcPropPos(mouseWorldPos, gridWorldPos, gridPos);
		}

		public override void OnGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag, Vector3 mouseWorldPos)
		{
			if (parentTr == null)
			{	// should not really happen, but just in case
				OnMapChanged();
				if (parentTr == null) return;
			}

			// **** mark tile(s)
			if (cursorMode == TileEdCursorMode.Mark)
			{
				activeTool = 0;
				ClearPasteMode(); // just in case in paste mode
				if (isDrag == false) wasClickOnSelected = false;

				for (int i = 0; i < gridPos.Length; i++)
				{
					List<int> ids = TileEdSelected.AllAtGridPos(selection, TileEd.Instance.group, gridPos[i]);
					if (ids.Count > 0)
					{
						if (wasClickOnSelected || !isDrag)
						{
							// remove from selection
							wasClickOnSelected = true;

							for (int idx = ids.Count - 1; idx >= 0; idx--)
							{
								TileEdGUI.RemoveSelectionMarker(selection[ids[idx]].markerGo);
								selection.RemoveAt(ids[idx]);
							}
						}
						continue;
					}

					// if the click was on an existing selected tile then any drag will 
					// only be valid when over selected tiles to remove them from selection
					// a new click-drag must be started on an unselected tile to continue
					// the selection action and adding tiles to selection
					if (wasClickOnSelected) continue;

					List<TileEdMapTile> tiles = TileEd.Instance.group.GetTiles(TOOL_IDENT, gridPos[i]);
					if (tiles.Count > 0) // check if there is at least one prop on this tile spot, else do not bother to look for 'em via FindChild()
					{
						// mark all props in same tile spot
						string s = gridPos[i].ToString();
						for (int trIdx = 0; trIdx < parentTr.childCount; trIdx++)
						{
							Transform tileTr = parentTr.GetChild(trIdx);
							if (tileTr.name == s)
							{
								plyIdent id = tileTr.GetComponent<plyIdent>();
								if (id == null || id.i_ident != TOOL_IDENT) continue;

								TileEdMapTile found = null;
								for (int k =0; k < tiles.Count; k++)
								{
									if (tiles[k].extraData[_eData_Ident] == id.s_ident) { found = tiles[k]; break; }
								}

								if (found != null)
								{
									GameObject goMarker = TileEdGUI.AddSelectionMarker(tileTr.gameObject);
									selection.Add(new TileEdSelected()
									{
										//groupIdent = TileEd.Instance.group.ident,
										group = TileEd.Instance.group,
										tile = found,
										gridPos = gridPos[i],
										markerGo = goMarker,
										mainGo = tileTr.gameObject,
									});
								}
							}
						}
					}
				}
			}

			// **** paste tile(s)
			else if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
			{
				activeTool = 0;
				PasteFromCopyBuffer();
			}

			// **** place or delete tile(s)
			else
			{
				ClearPasteMode(); // just in case in paste mode

				if (cursorMode == TileEdCursorMode.Normal && (currTileIdx < 0 || tileSetIdx < 0))
				{
					GameObject go = HandleUtility.PickGameObject(Event.current.mousePosition, true);
					if (go != null)
					{	
						// select/ unselect the object if it is a prop in the active tile layer
						// likely to be prop if it has plyStringIdent
						plyIdent id = go.GetComponent<plyIdent>();
						if (id != null && id.i_ident == TOOL_IDENT)
						{
							// find the tile
							TileEdMapTile t = TileEd.Instance.group.GetTileByExtraData(TOOL_IDENT, id.s_ident, 0);
							if (t != null)
							{
								int idx = TileEdSelected.ListContains(selection, t);
								if (idx >= 0)
								{
									TileEdGUI.RemoveSelectionMarker(selection[idx].markerGo);
									selection.RemoveAt(idx);
								}
								else
								{
									if (activeTool > 0) ClearSelection(); // can only select one at a time if not in normal pain mode
									GameObject goMarker = TileEdGUI.AddSelectionMarker(go);
									selection.Add(new TileEdSelected()
									{
										//groupIdent = TileEd.Instance.group.ident,
										group = TileEd.Instance.group,
										tile = t,
										gridPos = t.gridPos,
										markerGo = goMarker,
										mainGo = go,
									});
								}
							}
						}
					}
					return;
				}

				ClearSelection(); // just in case previous action was a selection

				HandleSimpleTileGridClick(gridPos, cursorMode, isDrag, mouseWorldPos);
			}
		}

		private void HandleSimpleTileGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag, Vector3 mouseWorldPos)
		{
			bool startedUndo = isDrag; // allow new undo group only if mouse went down, not during a mouse drag

			// **** place a tile(s)
			if (cursorMode == TileEdCursorMode.Normal)
			{
				bool[] doPlace = null;
				if (gridPos.Length > 1 && minMaxPlace[0] < 100.0f)
				{	// calculate on which tiles to actually place props when random placement chance is on
					int maxTiles = Mathf.Clamp(Mathf.RoundToInt(gridPos.Length * Random.Range(minMaxPlace[0], minMaxPlace[1]) / 100f), 0, gridPos.Length);
					if (maxTiles < gridPos.Length)
					{
						doPlace = new bool[gridPos.Length];
						while (maxTiles > 0)
						{
							int chosen = Random.Range(0, gridPos.Length);
							if (doPlace[chosen] == false)
							{
								doPlace[chosen] = true;
								maxTiles--;
							}
						}
					}
				}

				int tRot = tileRotation; // so as not to change tileRotation if random is on
				int chosenFabIdx = 0;
				if (canRandomFab && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
				{
					chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
					if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
				}

				for (int i = 0; i < gridPos.Length; i++)
				{
					if (doPlace != null && doPlace[i] == false) continue;

					if (canRandomRotate) tRot = ClampTileRotation(Random.Range(0, 360 / tileRotStep) * tileRotStep);

					if (canRandomFabAll && asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length > 1)
					{
						chosenFabIdx = Random.Range(0, asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab.Length);
						if (asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx] == null) chosenFabIdx = 0;
					}

					GameObject fab = asset.tileSets[tileSetIdx].tiles[currTileIdx].prefab[chosenFabIdx];
					if (fab == null) continue;

					if (!startedUndo)
					{
						Undo.IncrementCurrentGroup();
						Undo.SetCurrentGroupName("Paint Prop(s)");
						startedUndo = true;
						Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "");
					}

					// calculate offset
					Vector3 gridWorldPos = new Vector3(gridPos[i].x * TileEd.Instance.group.tileSize, gridPos[i].y * TileEd.Instance.group.tileHeight, gridPos[i].z * TileEd.Instance.group.tileSize);
					if (gridPos.Length > 1) mouseWorldPos = gridWorldPos; // else the props end up all at center tile
					if (canRandomPos) 
					{
						float ht = TileEd.Instance.group.tileSize / 2f;
						mouseWorldPos.x = mouseWorldPos.x + Random.Range(-ht, ht);
						mouseWorldPos.z = mouseWorldPos.z + Random.Range(-ht, ht);
					}
					Vector3 offs = CalcPropPos(mouseWorldPos, gridWorldPos, gridPos[i]) - gridWorldPos;

					// calculate custom rotation if any
					Vector3? rotation = null;

					// calculate custom scale if any
					Vector3? scale = null;
					if (currScaleOp == 1)
					{	// can select a random uniform scale
						float f = Random.Range(scaleMinMax[0], scaleMinMax[1]);
						scale = fab.transform.localScale * f;
					}

					// add tile to asset
					CreateTile(fab, gridPos[i], tRot, offs, rotation, scale, asset.tileSets[tileSetIdx], asset.tileSets[tileSetIdx].tiles[currTileIdx], chosenFabIdx);

				}

				if (startedUndo)
				{
					plyEdUtil.SetDirty(TileEd.Instance.map);
				}
			}

			// **** delete tile(s)
			else if (cursorMode == TileEdCursorMode.Delete)
			{
				activeTool = 0;
				for (int i = 0; i < gridPos.Length; i++)
				{
					// get all the props that are sharing this tile position
					List<TileEdMapTile> tiles = TileEd.Instance.group.GetTiles(TOOL_IDENT, gridPos[i]);
					if (tiles.Count > 0)
					{
						if (!startedUndo)
						{
							Undo.IncrementCurrentGroup();
							Undo.SetCurrentGroupName("Remove Prop(s)");
							startedUndo = true;
							Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "");
						}

						// remove from asset
						for (int k = 0; k < tiles.Count; k++)
						{
							//TileEd.Instance.group.tiles.Remove(tiles[k]);
							TileEd.Instance.group.RemoveTile(tiles[k]);
						}

						// remove from scene (continue looking for one till none with same name is returned)
						bool done = false;
						while (!done)
						{
							Transform tileTr = parentTr.Find(gridPos[i].ToString());
							if (tileTr != null) Undo.DestroyObjectImmediate(tileTr.gameObject);
							else done = true;
						}
					}
				}

				if (startedUndo)
				{
					plyEdUtil.SetDirty(TileEd.Instance.map);
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region sceneView

		public override void OnSceneView(SceneView sceneView)
		{
			if (activeTool > 0 && selection.Count > 0)
			{
				if (selection[0].markerGo == null || selection[0].mainGo == null)
				{
					ClearSelection();
					return;
				}

				// *** position
				if (activeTool == 1)
				{
					Vector3 p1 = selection[0].mainGo.transform.position;
					Vector3 p2 = Handles.PositionHandle(p1, selection[0].mainGo.transform.rotation);
					if (p2 != p1)
					{
						Undo.SetCurrentGroupName("Move Prop");
						Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, null);
						Undo.RecordObject(selection[0].mainGo.transform, null);
						Undo.RecordObject(selection[0].markerGo.transform, null);

						selection[0].mainGo.transform.position = p2;
						selection[0].markerGo.transform.position = p2;

						selection[0].tile.offsPos += (p2 - p1);

						plyEdUtil.SetDirty(selection[0].mainGo.transform);
						plyEdUtil.SetDirty(TileEd.Instance.map);
					}
				}

				//***  rotation
				else if (activeTool == 2)
				{
					Quaternion q1 = selection[0].mainGo.transform.rotation;
					Quaternion q2 = Handles.RotationHandle(q1, selection[0].mainGo.transform.position);
					if (q1 != q2)
					{
						Undo.SetCurrentGroupName("Rotate Prop");
						Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, null);
						Undo.RecordObject(selection[0].mainGo.transform, null);
						Undo.RecordObject(selection[0].markerGo.transform, null);

						selection[0].mainGo.transform.rotation = q2;
						selection[0].markerGo.transform.rotation = q2;

						selection[0].tile.extraData[_eData_Rotation] = plyUtil.EncodeVector3(q2.eulerAngles);

						plyEdUtil.SetDirty(selection[0].mainGo.transform);
						plyEdUtil.SetDirty(TileEd.Instance.map);
					}
				}

				// *** scale
				else if (activeTool == 3)
				{
					Vector3 p = selection[0].mainGo.transform.position;
					Vector3 s1 = selection[0].mainGo.transform.localScale;
					Vector3 s2 = Handles.ScaleHandle(s1, p, selection[0].mainGo.transform.rotation, HandleUtility.GetHandleSize(p));
					if (s1 != s2)
					{
						Undo.SetCurrentGroupName("Scale Prop");
						Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, null);
						Undo.RecordObject(selection[0].mainGo.transform, null);
						Undo.RecordObject(selection[0].markerGo.transform, null);

						selection[0].mainGo.transform.localScale = s2;
						selection[0].markerGo.transform.localScale = s2;

						selection[0].tile.extraData[_eData_Scale] = plyUtil.EncodeVector3(s2);

						plyEdUtil.SetDirty(selection[0].mainGo.transform);
						plyEdUtil.SetDirty(TileEd.Instance.map);
					}
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region selection tools and copy buffer

		private void ClearSelection(bool upToFirst = false)
		{
			wasClickOnSelected = false;
			if (selection.Count > 0)
			{
				if (upToFirst)
				{
					if (selection.Count == 1) return;
					for (int i = selection.Count - 1; i > 0; i--)
					{
						TileEdGUI.RemoveSelectionMarker(selection[i].markerGo);
						selection.RemoveAt(i);
					}
				}
				else
				{
					selection.Clear();
					TileEdGUI.ClearSelectionMarkers();
				}

				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		private void ClearCopyBuffer()
		{
			if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
			{
				TileEd.grid.cursorMode = TileEdCursorMode.Normal;
				TileEd.grid.UpdatePreviewObject(null, 0);
			}

			GC_CopyBuffer.text = Ico._wait;
			GC_CopyBuffer.image = null;
			copyBuffer.texture = null; // do not call DestroyImmediate() on this one
			if (copyBuffer.prefab != null) Object.DestroyImmediate(copyBuffer.prefab, true);
			copyBuffer.tiles.Clear();
		}

		private void CutSelection()
		{
			CopySelection(false);
			DeleteSelection();
		}

		private void DuplicateSelection()
		{
			CopySelection(true);
			EnterPasteMode();
		}

		private void CopySelection(bool doClearSel)
		{
			// destroy old buffer data
			ClearCopyBuffer();

			// create the template
			IntVector3 offs = new IntVector3(999999, 999999, 999999);
			for (int i = 0; i < selection.Count; i++)
			{
				if (selection[i].tile == null)
				{
					Debug.LogWarning("[Props CopySelection] Unexpected null in selection");
					continue;
				}

				copyBuffer.tiles.Add(selection[i].tile.Copy());
				
				if (selection[i].gridPos.x < offs.x) offs.x = selection[i].gridPos.x;
				if (selection[i].gridPos.y < offs.y) offs.y = selection[i].gridPos.y;
				if (selection[i].gridPos.z < offs.z) offs.z = selection[i].gridPos.z;
			}

			if (doClearSel) ClearSelection();

			// create the preview prefab
			if (copyBuffer.tiles.Count > 0)
			{
				GameObject templatePreviewGo = new GameObject("copy_buffer_preview");
				templatePreviewGo.hideFlags = HideFlags.HideAndDontSave;

				for (int i = 0; i < copyBuffer.tiles.Count; i++)
				{
					copyBuffer.tiles[i].gridPos -= offs;

					TileEdPropSet tset = asset.FindTileSet(copyBuffer.tiles[i].data[_TileSetIdent]);
					if (tset == null) continue;
					TileEdProp t = tset.FindTile(copyBuffer.tiles[i].data[_TileIdent]);
					int fabIdx = copyBuffer.tiles[i].data[_TileFabIdx];
					if (t == null || t.prefab[fabIdx] == null) continue;

					GameObject go = GameObject.Instantiate(t.prefab[fabIdx]);
					go.hideFlags = HideFlags.HideAndDontSave;
					go.name = copyBuffer.tiles[i].gridPos.ToString();
					go.transform.parent = templatePreviewGo.transform;
					go.transform.position = copyBuffer.tiles[i].offsPos + new Vector3(
						copyBuffer.tiles[i].gridPos.x * TileEd.Instance.group.tileSize,
						copyBuffer.tiles[i].gridPos.y * TileEd.Instance.group.tileHeight,
						copyBuffer.tiles[i].gridPos.z * TileEd.Instance.group.tileSize);

					Vector3 rotation = new Vector3(0f, copyBuffer.tiles[i].data[_TileRotation], 0f);
					if (string.IsNullOrEmpty(copyBuffer.tiles[i].extraData[_eData_Rotation]) == false) rotation = plyUtil.DecodeVector3(copyBuffer.tiles[i].extraData[_eData_Rotation], rotation);
					go.transform.rotation = Quaternion.Euler(rotation);

					if (string.IsNullOrEmpty(copyBuffer.tiles[i].extraData[_eData_Scale]) == false) go.transform.localScale = plyUtil.DecodeVector3(copyBuffer.tiles[i].extraData[_eData_Scale], go.transform.localScale);

					plyEdUtil.HideWireframes(go);
					plyEdUtil.SetStaticEditorFlagsRecursive(go, 0, 1);
				}

				plyEdUtil.CheckPath(TileEdGlobal.TEMP_PATH);
				copyBuffer.prefab = plyEdUtil.CreatePrefabFromPrefab(templatePreviewGo, TileEdGlobal.TEMP_PATH + "copy_buffer_preview.prefab");
				Object.DestroyImmediate(templatePreviewGo);
			}

			plyEdUtil.RepaintInspector(typeof(TileEd));
		}

		private void DeleteSelection()
		{
			bool startedUndo = false;
			int undoId = -1;
			for (int i = 0; i < selection.Count; i++)
			{
				if (!startedUndo)
				{
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Remove Prop(s)");
					startedUndo = true;
					undoId = Undo.GetCurrentGroup();
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "");
				}

				// remove from asset
				//selection[i].group.tiles.Remove(selection[i].tile);
				selection[i].group.RemoveTile(selection[i].tile);

				// remove from scene
				if (selection[i].mainGo != null) Undo.DestroyObjectImmediate(selection[i].mainGo);
			}

			// I needed to record each tile deletion separately else Unity will not record the deleted tile's data
			// now all those steps need to be combined into one here
			if (startedUndo)
			{
				//Undo.CollapseUndoOperations(undoId);
				plyEdUtil.SetDirty(TileEd.Instance.map);
			}

			ClearSelection();
		}

		private void EnterPasteMode()
		{
			if (copyBuffer.tiles.Count > 0)
			{
				ClearSelection();
				ClearCurrTile();
				TileEd.grid.cursorMode = TileEdCursorMode.Paste;
				TileEd.grid.UpdatePreviewObject(copyBuffer.prefab, tileRotation);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		private void ClearPasteMode()
		{
			TileEd.grid.ClearPasteMode();
		}

		private void PasteFromCopyBuffer()
		{
			if (copyBuffer.tiles.Count == 0) return;
			int undoId = -1;
			bool startedUndo = false;
			Quaternion r = Quaternion.Euler(0f, tileRotation, 0f);
			Vector3 mainPos = CalcPropPos(TileEd.grid.mouseWorldPos, TileEd.grid.gridWorldPos, TileEd.grid.gridPos);
			Vector3 mainOffs = mainPos - TileEd.grid.gridWorldPos;

			for (int i = 0; i < copyBuffer.tiles.Count; i++)
			{
				TileEdMapTile placeTile = copyBuffer.tiles[i];
				
				int[] data = new int[placeTile.data.Length];
				for (int dIdx = 0; dIdx < data.Length; dIdx++) data[dIdx] = placeTile.data[dIdx];
				data[_TileRotation] = ClampTileRotation(placeTile.data[_TileRotation] + tileRotation);

				TileEdPropSet tset = asset.FindTileSet(data[_TileSetIdent]);
				if (tset == null) continue;
				TileEdProp t = tset.FindTile(data[_TileIdent]);
				if (t == null || t.prefab[data[_TileFabIdx]] == null) continue;

				if (!startedUndo)
				{
					Undo.IncrementCurrentGroup();
					Undo.SetCurrentGroupName("Paste Prop(s)");
					startedUndo = true;
					undoId = Undo.GetCurrentGroup();
					Undo.RegisterCompleteObjectUndo(TileEd.Instance.map, "");
				}

				// calculate prop position
				IntVector3 gridPos = TileEd.grid.gridPos + placeTile.gridPos;
				Vector3 offs = placeTile.offsPos;
				Vector3 gridWorldPos = new Vector3(gridPos.x * TileEd.Instance.group.tileSize, gridPos.y * TileEd.Instance.group.tileHeight, gridPos.z * TileEd.Instance.group.tileSize);
				Vector3 mouseWorldPos = gridWorldPos + offs + mainOffs;
				mouseWorldPos = r * (mouseWorldPos - mainPos) + mainPos;
				gridWorldPos = new Vector3()
				{
					x = TileEd.Instance.group.tileSize * Mathf.Round(mouseWorldPos.x / TileEd.Instance.group.tileSize),
					y = 0f,
					z = TileEd.Instance.group.tileSize * Mathf.Round(mouseWorldPos.z / TileEd.Instance.group.tileSize)
				};
				gridPos = new IntVector3()
				{
					x = Mathf.RoundToInt(gridWorldPos.x / TileEd.Instance.group.tileSize),
					y = TileEd.Instance.group.gridYPos,
					z = Mathf.RoundToInt(gridWorldPos.z / TileEd.Instance.group.tileSize)
				};
				offs = mouseWorldPos - gridWorldPos;

				// get custom rotation and scale
				Vector3? rotation = null;
				Vector3? scale = null;
				if (string.IsNullOrEmpty(placeTile.extraData[_eData_Rotation]) == false) rotation = plyUtil.DecodeVector3(placeTile.extraData[_eData_Rotation], Vector3.zero);
				if (string.IsNullOrEmpty(placeTile.extraData[_eData_Scale]) == false) scale = plyUtil.DecodeVector3(placeTile.extraData[_eData_Scale], Vector3.zero);

				// add tile to asset
				CreateTile(t.prefab[data[_TileFabIdx]], gridPos, data[_TileRotation], offs, rotation, scale, tset, t, data[_TileFabIdx]);
			}

			if (startedUndo)
			{
				//Undo.CollapseUndoOperations(undoId);
				plyEdUtil.SetDirty(TileEd.Instance.map);
			}

		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region helpers

		private bool LoadAsset()
		{
			canRandomRotate = EditorPrefs.GetBool("TileEd.Props.canRandomRotate", canRandomRotate);
			canRandomFab = EditorPrefs.GetBool("TileEd.Props.canRandomFab", canRandomFab);
			canRandomFabAll = EditorPrefs.GetBool("TileEd.Props.canRandomFabAll", canRandomFabAll);
			canRandomPos = EditorPrefs.GetBool("TileEd.Props.canRandomPos", canRandomPos);
			tileRotStep = EditorPrefs.GetInt("TileEd.Props.tileRotStep", tileRotStep);
			currPosOp = EditorPrefs.GetInt("TileEd.Props.currPosOp", currPosOp);
			currHeightOp = EditorPrefs.GetInt("TileEd.Props.currHeightOp", currHeightOp);
			customHeightOffs = EditorPrefs.GetFloat("TileEd.Props.customHeightOffs", customHeightOffs);
			currScaleOp = EditorPrefs.GetInt("TileEd.Props.currScaleOp", currScaleOp);
			scaleMinMax[0] = EditorPrefs.GetFloat("TileEd.Props.scaleMinMax0", scaleMinMax[0]);
			scaleMinMax[1] = EditorPrefs.GetFloat("TileEd.Props.scaleMinMax1", scaleMinMax[1]);
			minMaxPlace[0] = EditorPrefs.GetFloat("TileEd.Props.minMaxPlace0", minMaxPlace[0]);
			minMaxPlace[1] = EditorPrefs.GetFloat("TileEd.Props.minMaxPlace1", minMaxPlace[1]);

			UpdateRotOp();

			if (asset == null)
			{
				plyEdUtil.CheckPath(TileEdGlobal.DATA_PATH);
				asset = plyEdUtil.LoadOrCreateAsset<TileEdPropSetsAsset>(TileEdGlobal.DATA_PATH + ASSET_NAME);
				if (asset == null)
				{
					GUILayout.Label("Error: Could not load the Props asset.");
					return false;
				}
			}

			if (tmplAsset == null)
			{
				plyEdUtil.CheckPath(TileEdGlobal.DATA_PATH);
				tmplAsset = plyEdUtil.LoadOrCreateAsset<TileEdTemplatesAsset>(TileEdGlobal.DATA_PATH + TMPLT_NAME);
				if (tmplAsset == null)
				{
					GUILayout.Label("Error: Could not load the Tile Templates asset.");
					return false;
				}
			}

			return true;
		}

		private void UpdateRotOp()
		{
			currRotOp = 0;
			for (int i = 0; i < RotOps.Length; i++)
			{
				if (RotOps[i] == tileRotStep) { currRotOp = i + 1; break; }
			}
		}

		private void EraseAllTilesFromActiveGroup()
		{
			ClearUndo();

			if (parentTr == null && TileEd.Instance.group != null)
			{	// it might happen that this is null
				Transform tr = TileEd.Instance.mapTr.Find(ROOT_NAME);
				if (tr == null) return;
				string groupIdent = TileEd.Instance.group.ident.ToString();
				parentTr = tr.Find(groupIdent);
				if (parentTr == null) return;
			}

			if (parentTr.childCount > 0)
			{
				//// remove from asset
				//for (int i = TileEd.Instance.group.Count - 1; i >= 0; i--)
				//{
				//	if (TileEd.Instance.group[i].toolIdent == TOOL_IDENT)
				//	{
				//		TileEd.Instance.group.tiles.RemoveAt(i);
				//	}
				//}

				TileEd.Instance.group.RemoveAllTiles(TOOL_IDENT);

				// remove from scene
				for (int i = parentTr.childCount - 1; i >= 0; i--)
				{
					Object.DestroyImmediate(parentTr.GetChild(i).gameObject);
				}

				plyEdUtil.SetDirty(TileEd.Instance.map);
			}
		}

		private void ClearUndo()
		{
			Undo.ClearUndo(TileEd.Instance.map);
		}

		private void ClearCurrTile()
		{
			currTileIdx = -1;
			TileEd.grid.UpdatePreviewObject(null, 0f);
			TileEd_PalettePanel.DoRepaint();
		}

		private int ClampTileRotation(int rot)
		{
			if (rot < 0) rot += 360;
			else if (rot >= 360) rot -= 360;
			return rot;
		}

		private Vector3 CalcPropPos(Vector3 mouseWorldPos, Vector3 gridWorldPos, IntVector3 gridPos)
		{
			Vector3 pos = gridWorldPos;

			// currPosOp = 0:"Centre", 1:"½ Tile", 2:"⅓ Tile", 3:"¼ Tile", 4:"Free"
			if (currPosOp == 4)
			{
				pos = mouseWorldPos;
			}

			else if (currPosOp == 0)
			{
				if (TileEd.Instance.group.centreTiles == false)
				{
					float offs = -TileEd.Instance.group.tileSize / 2f;
					pos += new Vector3(offs, 0f, offs);
				}
			}

			else if (currPosOp > 0)
			{
				float sz = 0.5f;
				if (currPosOp == 2) sz = 0.33f;
				else if (currPosOp == 3) sz = 0.25f;
				sz = TileEd.Instance.group.tileSize * sz;
				pos = new Vector3(sz * Mathf.Round(mouseWorldPos.x / sz), gridWorldPos.y, sz * Mathf.Round(mouseWorldPos.z / sz));
			}

			if (currHeightOp == 1)
			{	// check against colliders
				Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
				RaycastHit hit;
				if (Physics.Raycast(ray, out hit))
				{
					pos = hit.point;
					TileEd.grid.gridWorldPos = TileEd.grid.mouseWorldPos = pos;
					TileEd.grid.RecalcCalcGridPos();
				}
			}
			else if (currHeightOp == 2)
			{	// check against all objects, even those without colliders
				// start by asking Unity what is near the mouse cursor and check only against that
				GameObject go = HandleUtility.PickGameObject(Event.current.mousePosition, true);
				if (go != null)
				{
					if (lastPickedForNonColl != go)
					{
						lastPickedForNonColl = go;
						APAObjectDictionary.singleton.Init(pickedBounds, go);
					}
					Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
					APARaycastHit hit;
					if (APARaycast.Raycast(ray, out hit))
					{
						pos = hit.point;
						TileEd.grid.gridWorldPos = TileEd.grid.mouseWorldPos = pos;
						TileEd.grid.RecalcCalcGridPos();
					}				
				}

				//Bounds bounds = new Bounds(Vector3.zero, new Vector3(1000, 1000, 1000));
				//APAObjectDictionary.singleton.Init(bounds);
				//Ray ray = HandleUtility.GUIPointToWorldRay(ev.mousePosition);
				//APARaycastHit hit;
				//if (APARaycast.Raycast(ray, out hit))
				//{
				//	pos = hit.point;
				//	TileEd.grid.gridWorldPos = TileEd.grid.mouseWorldPos = pos;
				//	TileEd.grid.RecalcCalcGridPos();
				//}
			}
			else if (currHeightOp == 3)
			{
				pos.y = customHeightOffs;
			}

			return pos;
		}


		private void TemplatesInspector()
		{
			EditorGUILayout.Space();
			Event ev = Event.current;
			if (ev.type == EventType.Repaint) lastInspectorWidth = GUILayoutUtility.GetLastRect().width;
			else if (lastInspectorWidth == 0.0f) lastInspectorWidth = Screen.width - 19;

			GUILayout.Label(GC_TemplatesHead, plyEdGUI.Styles.LargeLabel);
			EditorGUILayout.Space();

			if (tmplAsset.templates.Count == 0)
			{
				GUILayout.Label(GC_NoTemplates);
				return;
			}

			TileEdGlobal.PreviewAlloc(0, tmplAsset.templates.Count + 1);
			//AssetPreview.SetPreviewTextureCacheSize(tmplAsset.templates.Count + 1);

			Rect refRect = GUILayoutUtility.GetRect(0, 5, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(false), GUILayout.Height(5));
			refRect.width = lastInspectorWidth;

			int sz = (TileEdGlobal.templatesPreviewSize + 5);

			float allocW = Mathf.Clamp(Mathf.FloorToInt(refRect.width / sz), 1, tmplAsset.templates.Count);
			GUILayoutUtility.GetRect(sz, Mathf.CeilToInt(tmplAsset.templates.Count / allocW) * sz);

			int rem = -1, sel = -1, forced = -1;
			Rect r = new Rect(refRect.x, refRect.y, TileEdGlobal.templatesPreviewSize, TileEdGlobal.templatesPreviewSize);
			Rect br = new Rect(0, 0, 16, 16);

			for (int i = 0; i < tmplAsset.templates.Count; i++)
			{
				if (tmplAsset.templates[i] == null || tmplAsset.templates[i].prefab == null)
				{	// found broken template
					forced = i;
					continue;
				}

				if (ev.type == EventType.Repaint)
				{
					if (tmplAsset.templates[i].texture == null)
					{
						tmplAsset.templates[i].texture = AssetPreview.GetAssetPreview(tmplAsset.templates[i].prefab);
						if (tmplAsset.templates[i].texture != null)
						{
							tmplAsset.templates[i].texture = plyEdUtil.SavePNG(tmplAsset.templates[i].texture, TileEdGlobal.FABS_PATH + PATH + tmplAsset.templates[i].guid + ".png");
							plyEdUtil.SetDirty(tmplAsset);
						}
					}

					if (tmplAsset.templates[i].texture == null) GUI.Box(r, GC_Wait, TileEdGUI.Styles.TilePreview);
					else GUI.Box(r, tmplAsset.templates[i].texture, TileEdGUI.Styles.TilePreview);
				}

				br.x = r.xMax - 16; br.y = r.y;
				if (GUI.Button(br, GC_DelTmpl, plyEdGUI.Styles.Button))
				{
					rem = i;
				}
				else if (ev.type == EventType.MouseDown && ev.button == 0 && r.Contains(ev.mousePosition))
				{
					sel = i;
					ev.Use();
				}

				r.x += sz;
				if (r.xMax > refRect.xMax)
				{
					r.x = refRect.x;
					r.y += sz;
				}
			}

			if (rem >= 0 || forced >= 0)
			{
				if (forced >= 0)
				{
					if (tmplAsset.templates[forced].texture != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[forced].texture));
					if (tmplAsset.templates[forced].prefab != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[forced].prefab));

					tmplAsset.templates.RemoveAt(forced);
					plyEdUtil.SetDirty(tmplAsset);
					AssetDatabase.Refresh();
				}
				else if (EditorUtility.DisplayDialog("TileEd", "Remove the template. Are you sure?", "Yes", "Cancel"))
				{
					if (tmplAsset.templates[rem].texture != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[rem].texture));
					if (tmplAsset.templates[rem].prefab != null) AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(tmplAsset.templates[rem].prefab));

					tmplAsset.templates.RemoveAt(rem);
					plyEdUtil.SetDirty(tmplAsset);
					AssetDatabase.Refresh();
				}
			}
			else if (sel >= 0)
			{
				ActivateTemplate(tmplAsset.templates[sel]);
			}

		}

		private void CreateNewTemplate()
		{
			plyEdUtil.CheckPath(TileEdGlobal.FABS_PATH);
			plyEdUtil.CheckPath(TileEdGlobal.FABS_PATH + PATH);

			TileEdTemplate t = copyBuffer.Copy();
			t.name = "Template " + (tmplAsset.templates.Count + 1).ToString();
			t.guid = "";

			// generate a unique name for the preview prefab
			bool done = false;
			while (!done)
			{
				t.guid = System.Guid.NewGuid().ToString("N");
				string path = plyEdUtil.ProjectFullPath + TileEdGlobal.FABS_PATH + PATH + t.guid + ".prefab";
				if (false == System.IO.File.Exists(path)) done = true;
			}

			// create preview texture (if available now)
			if (copyBuffer.texture == null) copyBuffer.texture = AssetPreview.GetAssetPreview(copyBuffer.prefab);
			if (copyBuffer.texture != null) t.texture = plyEdUtil.SavePNG(copyBuffer.texture, TileEdGlobal.FABS_PATH + PATH + t.guid + ".png");

			// create the preview prefab by making a copy of the copy buffer's
			t.prefab = plyEdUtil.CreatePrefabFromPrefab(copyBuffer.prefab, TileEdGlobal.FABS_PATH + PATH + t.guid + ".prefab");

			// update template asset
			tmplAsset.templates.Add(t);
			plyEdUtil.SetDirty(tmplAsset);
		}

		private void ActivateTemplate(TileEdTemplate tmpl)
		{
			ClearCopyBuffer();
			AssetDatabase.Refresh();

			plyEdUtil.CheckPath(TileEdGlobal.TEMP_PATH);
			copyBuffer = tmpl.Copy();
			copyBuffer.texture = null;
			copyBuffer.prefab = plyEdUtil.CreatePrefabFromPrefab(tmpl.prefab, TileEdGlobal.TEMP_PATH + "copy_buffer_preview.prefab");
			copyBuffer.prefab.name = "copy_buffer_preview";
			plyEdUtil.SetDirty(copyBuffer.prefab);

			EnterPasteMode();
		}


		private TileEdMapTile CreateTile(GameObject fab, IntVector3 pos, int tileRot, Vector3 offs, Vector3? rot, Vector3? scale, TileEdPropSet propSet, TileEdProp prop, int fabIdx)
		{
			string ident = System.Guid.NewGuid().ToString("N");
			TileEdMapTile newTile = new TileEdMapTile()
			{
				toolIdent = TOOL_IDENT,
				gridPos = pos,
				data = new int[_MaxTileProperties],
				offsPos = offs,
				extraData = new string[] 
				{ 
					ident,
					rot == null ? null : plyUtil.EncodeVector3(rot.Value),
					scale == null ? null : plyUtil.EncodeVector3(scale.Value),
				}
			};

			newTile.data[_TileSetIdent] = propSet.ident;
			newTile.data[_TileIdent] = prop.ident;
			newTile.data[_TileRotation] = tileRot;
			newTile.data[_TileFabIdx] = fabIdx;
			newTile.meta = prop.meta;

			//TileEd.Instance.group.tiles.Add(newTile);
			TileEd.Instance.group.AddTile(newTile);

			// create the tile in scene
			GameObject go = CreateTileObject(true, ident, parentTr, fab, pos, tileRot, offs, rot, scale, prop, TileEd.Instance.group.tileSize, TileEd.Instance.group.tileHeight);

			if (onPlacedProp != null)
			{
				onPlacedProp.Invoke(new PlacedPropInfo()
				{
					go = go,
					tile = newTile,
					group = TileEd.Instance.group
				});
			}

			return newTile;
		}

		private GameObject CreateTileObject(bool canUndo, string ident, Transform parent, GameObject fab, IntVector3 pos, int tileRot, Vector3 offs, Vector3? rot, Vector3? scale, TileEdProp prop, float tileSize, float tileHeight)
		{
			GameObject go = PrefabUtility.InstantiatePrefab(fab) as GameObject;
			if (canUndo) Undo.RegisterCreatedObjectUndo(go, "");
			go.name = pos.ToString();
			go.transform.parent = parent;
			go.transform.position = new Vector3(pos.x * tileSize, pos.y * tileHeight, pos.z * tileSize) + offs;
			go.transform.rotation = Quaternion.Euler(rot ?? new Vector3(0f, tileRot, 0f));
			if (scale != null) go.transform.localScale = scale.Value;
			plyEdUtil.HideWireframes(go);

			plyIdent id = go.AddComponent<plyIdent>();
			id.i_ident = TOOL_IDENT;
			id.s_ident = ident;
			plyEdUtil.SetDirty(id);
			plyEdUtil.SetDirty(go);

			if (prop.setTag) plyEdUtil.SetTagRecursive(go, prop.tag);
			if (prop.setLayer) plyEdUtil.SetLayerRecursive(go, prop.layer);
			if (prop.setSort) TileEd.SetObjectSortOrder(go, prop.sortLayerId, prop.sortOrder);
			if (prop.setStaticFlags && prop.setNavArea) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)prop.staticFlags, prop.navArea);
			else if (prop.setStaticFlags) plyEdUtil.SetStaticEditorFlagsRecursive(go, (StaticEditorFlags)prop.staticFlags);
			else if (prop.setNavArea) plyEdUtil.SetNavAreaRecursive(go, prop.navArea);

			return go;
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
