﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_PivotEditorWindow : EditorWindow
    {
		private GameObject sel = null;
		private MeshFilter mf = null;
		private Vector3 pos = Vector3.zero;
		private Vector3 rot = Vector3.zero;
		private Vector3 pPos = Vector3.zero;
		private Vector3 pRot = Vector3.zero;

		private static readonly GUIContent GC_DoSelect = new GUIContent("Select a GameObject in the Hierarchy that has a Mesh Filter component. You may also select a Prefab from the Project panel but it will easier to see what you are changing if the object is in the hierarchy and visible in the scene.");
		private static readonly GUIContent GC_Pos = new GUIContent("Position");
		private static readonly GUIContent GC_Rot = new GUIContent("Rotation");
		private static readonly GUIContent GC_Info1 = new GUIContent("Make sure that the tool handle is set to Pivot Local so that it is easier to see the pivot's real position and rotation in relation to the mesh.");
		private static readonly GUIContent GC_Info2 = new GUIContent("For auto-tiles the Blue (Z) axis should point in same direction as the wall's face and the Green (Y) axis should point upward.");

		private static Texture2D Img_PivotInfo1 = null;
		private static Texture2D Img_PivotInfo2 = null;

		public static void Show_PivotEditorWindow()
		{
			EditorWindow.GetWindow<TileEd_PivotEditorWindow>("Pivot Editor");
			Tools.pivotMode = PivotMode.Pivot;
			Tools.pivotRotation = PivotRotation.Local;
			Tools.current = Tool.Move;
		}

		protected void OnSelectionChange()
		{
			Repaint();
		}

		protected void OnGUI()
		{
			if (Img_PivotInfo1 == null)
			{
				Img_PivotInfo1 = plyEdGUI.LoadTextureResource("TileEd.res.pivot_info1.png", typeof(TileEdGUI).Assembly);
				Img_PivotInfo2 = plyEdGUI.LoadTextureResource("TileEd.res.pivot_info2.png", typeof(TileEdGUI).Assembly);
			}

			if (sel != Selection.activeGameObject)
			{
				mf = null;
				sel = Selection.activeGameObject;
				pos = rot = Vector3.zero;
				pPos = pRot = Vector3.zero;

				if (sel != null)
				{
					mf = sel.GetComponent<MeshFilter>();
					if (mf != null)
					{
						Tools.pivotMode = PivotMode.Pivot;
						Tools.pivotRotation = PivotRotation.Local;
						Tools.current = Tool.Move;
					}
				}
			}

			if (mf == null)
			{
				GUILayout.Label(GC_DoSelect, EditorStyles.wordWrappedLabel);
			}

			else
			{
				pos = EditorGUILayout.Vector3Field(GC_Pos, pos);
				rot = EditorGUILayout.Vector3Field(GC_Rot, rot);

				EditorGUILayout.Space();
				GUILayout.Label(GC_Info1, EditorStyles.wordWrappedLabel);
				Rect r = GUILayoutUtility.GetRect(327, 33, GUILayout.Width(327), GUILayout.Height(33), GUILayout.ExpandWidth(false));
				r.x += 5;
				GUI.DrawTexture(r, Img_PivotInfo1);
				EditorGUILayout.Space();
				GUILayout.Label(GC_Info2, EditorStyles.wordWrappedLabel);
				r = GUILayoutUtility.GetRect(150, 150, GUILayout.Width(150), GUILayout.Height(150), GUILayout.ExpandWidth(false));
				r.x += 5;
				GUI.DrawTexture(r, Img_PivotInfo2);
				EditorGUILayout.Space();

				if (pos != pPos) UpdatePivotPosition();
				if (rot != pRot) UpdatePivotRotation();
			}
		}

		private void UpdatePivotPosition()
		{
			Vector3 p = pos - pPos;
			pPos = pos;

			Vector3[] oldVerts = mf.sharedMesh.vertices;
			Vector3[] newVerst = new Vector3[oldVerts.Length];

			for (int i = 0; i < oldVerts.Length; i++) newVerst[i] = oldVerts[i] + p;

			mf.sharedMesh.vertices = newVerst;
			plyEdUtil.SetDirty(mf);
			plyEdUtil.SetDirty(mf.gameObject);
		}

		private void UpdatePivotRotation()
		{
			Quaternion q = Quaternion.Euler(rot - pRot);
			pRot = rot;

			Vector3[] oldVerts = mf.sharedMesh.vertices;
			Vector3[] newVerst = new Vector3[oldVerts.Length];

			Vector3[] oldNormals = mf.sharedMesh.normals;
			Vector3[] newNormals = new Vector3[oldNormals.Length];

			for (int i = 0; i < oldVerts.Length; i++)
			{
				newVerst[i] = q * oldVerts[i];
				newNormals[i] = q * oldNormals[i];

				//newVerst[i] = new Vector3((oldVerts[i].x * Mathf.Cos(Mathf.Deg2Rad * r.y) + oldVerts[i].z * Mathf.Sin(Mathf.Deg2Rad * r.y)) * (r.y != 0 ? 1 : 0) + /*Y*/
				//							 oldVerts[i].x * (r.x != 0 ? 1 : 0) +                                                                                      /*X*/
				//							 (oldVerts[i].x * Mathf.Cos(Mathf.Deg2Rad * r.z) + oldVerts[i].y * Mathf.Sin(Mathf.Deg2Rad * r.z)) * (r.z != 0 ? 1 : 0)   /*Z*/,

				//							 oldVerts[i].y * (r.y != 0 ? 1 : 0) +                                                                                      /*Y*/
				//							 (oldVerts[i].y * Mathf.Cos(Mathf.Deg2Rad * r.x) + oldVerts[i].z * Mathf.Sin(Mathf.Deg2Rad * r.x)) * (r.x != 0 ? 1 : 0) + /*X*/
				//							 (-oldVerts[i].x * Mathf.Sin(Mathf.Deg2Rad * r.z) + oldVerts[i].y * Mathf.Cos(Mathf.Deg2Rad * r.z)) * (r.z != 0 ? 1 : 0)  /*Z*/,

				//							 (-oldVerts[i].x * Mathf.Sin(Mathf.Deg2Rad * r.y) + oldVerts[i].z * Mathf.Cos(Mathf.Deg2Rad * r.y)) * (r.y != 0 ? 1 : 0) + /*Y*/
				//							 (-oldVerts[i].y * Mathf.Sin(Mathf.Deg2Rad * r.x) + oldVerts[i].z * Mathf.Cos(Mathf.Deg2Rad * r.x)) * (r.x != 0 ? 1 : 0) + /*X*/
				//							 oldVerts[i].z * (r.z != 0 ? 1 : 0));                                                                                       /*Z*/

				//newNormals[i] = new Vector3((oldNormals[i].x * Mathf.Cos(Mathf.Deg2Rad * r.y) + oldNormals[i].z * Mathf.Sin(Mathf.Deg2Rad * r.y)) * (r.y != 0 ? 1 : 0) + /*Y*/
				//							 oldNormals[i].x * (r.x != 0 ? 1 : 0) +                                                                                    /*X*/
				//							 (oldNormals[i].x * Mathf.Cos(Mathf.Deg2Rad * r.z) + oldNormals[i].y * Mathf.Sin(Mathf.Deg2Rad * r.z)) * (r.z != 0 ? 1 : 0)  /*Z*/,

				//							 oldNormals[i].y * (r.y != 0 ? 1 : 0) +                                                                                     /*Y*/
				//							 (oldNormals[i].y * Mathf.Cos(Mathf.Deg2Rad * r.x) + oldNormals[i].z * Mathf.Sin(Mathf.Deg2Rad * r.x)) * (r.x != 0 ? 1 : 0) + /*X*/
				//							 (-oldNormals[i].x * Mathf.Sin(Mathf.Deg2Rad * r.z) + oldNormals[i].y * Mathf.Cos(Mathf.Deg2Rad * r.z)) * (r.z != 0 ? 1 : 0)  /*Z*/,

				//							 (-oldNormals[i].x * Mathf.Sin(Mathf.Deg2Rad * r.y) + oldNormals[i].z * Mathf.Cos(Mathf.Deg2Rad * r.y)) * (r.y != 0 ? 1 : 0) + /*Y*/
				//							 (-oldNormals[i].y * Mathf.Sin(Mathf.Deg2Rad * r.x) + oldNormals[i].z * Mathf.Cos(Mathf.Deg2Rad * r.x)) * (r.x != 0 ? 1 : 0) + /*X*/
				//							 oldNormals[i].z * (r.z != 0 ? 1 : 0));                                                                                      /*Z*/
			}

			mf.sharedMesh.vertices = newVerst;
			mf.sharedMesh.normals = newNormals;

			plyEdUtil.SetDirty(mf);
			plyEdUtil.SetDirty(mf.gameObject);
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
