﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	[System.Serializable]
	public class TileEdTile
	{
		public int ident;								// this ident is unique among tiles of same and different tile-sets
		public GameObject[] prefab = new GameObject[1]; // 0: is the main, any additional are for random model selection
		public int tileIdx = -1;						// -1: not set if this is a transition, else idx of tile into set's list of tiles. this is used to quickly check if tile is solid, or wall/corner and has no meaning for extra simple tiles and transition tiles
		public int transitionIdx = -1;					// -1: not used as transition, else index into transitions list (this help with quicker lookups during painting so that long searches for this info is not needed)
		public int targetTransSet = -1;					// the ident of TileSet this is creating a transition with, else the Set that holds this tile if not a transition (this helps with quick lookups during painting so that long searches for this info is not needed)
		public int isRotating = 0;						// in rotating tiles set? 0:no, 1:yes

		public bool setTag = false;
		public string tag = "Untagged";

		public bool setLayer = false;
		public int layer = 0;

		public bool setStaticFlags = false;
		public int staticFlags = -1; //public StaticEditorFlags staticFlags = (StaticEditorFlags)(-1);

		public bool setNavArea = false;
		public int navArea = 1;

		public bool setSort = false;
		public int sortLayerId = 0;
		public int sortOrder = 0;

		public Texture2D customThumb;
		public string meta; // extra data that can be associated with this tile

		// ------------------------------------------------------------------------------------------------------------
    }
}
