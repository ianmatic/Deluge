﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLib;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_Ed_Base
    {
		public class TileSetInfo
		{
			public int toolIdent;
			public int setIdent;
			public string setName;
		}

		public bool hasLoadingPalettePreviews = false;
		public bool buildingCache = false;
		protected EditorWindow settingsEd;

		// ------------------------------------------------------------------------------------------------------------
		#region settings

		public virtual int ToolIdent()
		{
			return 0;
		}

		// called by whatever needs to know what kind of tile sets exist
		public virtual List<TileSetInfo> GetTileSets()
		{
			return new List<TileSetInfo>(0);
		}

		// render the settings for the tool
		public virtual void OnSettingsGUI(EditorWindow ed)
		{
			this.settingsEd = ed;
		}

		// called whenever settings window receives Focus or this settings area becomes visible (tab for it was clicked)
		public virtual void OnSettingsFocus(EditorWindow ed)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region palette

		public virtual string PaletteName()
		{
			return "-error-";
		}

		public virtual int PaletteOrder()
		{
			return 9999;
		}

		// the tool received focus in the palette
		public virtual void OnPalleteFocus()
		{
		}

		// the tool lost focus in the palette
		public virtual void OnPalleteLooseFocus()
		{
		}

		// render the tool's palette gui
		public virtual void OnPaletteGUI()
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region inspector

		// called when selected map object changed
		public virtual void DoCacheMap()
		{
			buildingCache = false;
		}

		public virtual void DoCacheLoopUpdate()
		{
			buildingCache = false;
		}

		// called when selected map object changed or when the tool activated in palette/ inspector
		// this is not the one to use to check if the actively selected map has changed. use OnMapOpened
		public virtual void OnMapChanged()
		{
		}

		// called when selected group changed
		public virtual void OnGroupChanged()
		{
		}

		// called before the selected map group will be deleted
		// the will likely want to remove the scene objects it created
		public virtual void OnDeletingGroup(TileEdMapGroup group)
		{
		}

		// called when a group was duplicated. all map data is in group
		// the tool simply needs to spawn the scene objects needed
		public virtual void OnDuplicatedGroup(TileEdMapGroup group)
		{
		}

		// called when group visibility changes
		public virtual void OnGroupVisibiliyChanged(int groupIdent, bool visible)
		{
		}

		// render the tool's inspector
		public virtual void OnInspector(Editor inspectorEd)
		{
		}

		// inspector update. this is called from OnGUI()!
		public virtual void Update(Editor inspectorEd)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region map and group manipulation

		// return true if the tool can combine meshes
		public virtual bool CanGroupCombine()
		{
			return false;
		}

		// called when the group tiles should be combined
		// only simple and auto tile tools support this
		public virtual void CombineGroup(TileEdMapGroup group, bool doUv2, UnwrapParam unwrapParam)
		{
		}

		// called when map should be recreated from the TileEd data/ map asset
		// the old tile objects will be removed from the scene by the time this is called
		public virtual void RecreateMap()
		{
		}

		// called when group should be recreated from the TileEd data/ map asset
		// the old tile objects needs to be removed by this function
		public virtual void RecreateGroup(TileEdMapGroup group, bool fromMain)
		{
		}

		public virtual void ReplaceTilesInMap(TileSetInfo oldSet, TileSetInfo newSet)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region grid

		public virtual Vector3 PreviewPosition(Vector3 previewPos, Vector3 mouseWorldPos, Vector3 gridWorldPos, IntVector3 gridPos)
		{
			return previewPos;
		}

		public virtual bool CanShowCursor()
		{
			return true;
		}

		public virtual TileEd_Grid.CursorStyle WantedDeleteCursorStyle()
		{
			return TileEd_Grid.CursorStyle.Delete;
		}

		// called before grid will start handling events. this is a good place to
		// handle events which would be missed while the palette was not docked
		// in the scene view and thus has no focus
		public virtual void HandleGridEvents(Event ev)
		{
		}

		// user clicked on grid while the tool is active. A list of grid positions
		// are passed since a brush can be 1 or more tiles big
		public virtual void OnGridClick(IntVector3[] gridPos, TileEdCursorMode cursorMode, bool isDrag, Vector3 mouseWorldPos)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region sceneView

		// called when scene view is rendered, after grid has rendered
		public virtual void OnSceneView(SceneView sceneView)
		{
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
