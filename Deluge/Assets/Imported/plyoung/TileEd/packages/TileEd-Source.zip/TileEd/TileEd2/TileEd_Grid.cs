﻿//#define DEBUG

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyLibEditor;
using plyLib;

namespace TileEd
{
	public class TileEd_Grid
	{
		// ------------------------------------------------------------------------------------------------------------
		#region defs

		public enum CursorStyle { Delete, Sculpting };

		private const string PREVIEW_OBJ_NAME = "TileEd2_PreviewObject";
		private static readonly GUIContent GC_GroupNotVisible = new GUIContent("TileEd: Can't paint on Tile Layer that is not visible");
		private static readonly GUIContent GC_GroupCombined = new GUIContent("TileEd: Can't paint on Tile Layer that is combined");

		public static readonly IntVector3[] Direction = new IntVector3[] 
		{ 
			// sides
			new IntVector3(  0,  0, +1 ), // top
			new IntVector3( +1,  0,  0 ), // right
			new IntVector3(  0,  0, -1 ), // bottom
			new IntVector3( -1,  0,  0 ), // left

			// corners
			new IntVector3( +1,  0, +1 ), // top-right
			new IntVector3( +1,  0, -1 ), // bottom-right
			new IntVector3( -1,  0, -1 ), // bottom-left
			new IntVector3( -1,  0, +1 ), // top-left
		};

		public const int Dir_Top = 0;
		public const int Dir_Right = 1;
		public const int Dir_Bottom = 2;
		public const int Dir_Left = 3;
		public const int Dir_TopRight = 4;
		public const int Dir_BottomRight = 5;
		public const int Dir_BottomLeft = 6;
		public const int Dir_TopLeft = 7;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region vars

		public TileEdCursorMode cursorMode = TileEdCursorMode.Normal;
		public bool gridPosDirty = false;

		public Vector3 mouseWorldPos = Vector3.zero;
		public Vector3 gridWorldPos = Vector3.zero;
		public IntVector3 gridPos;
		public Transform previewObj { get { return previewTr; } }

		private const float GridExpand = 1000f;
		private static readonly Vector3 PreviewOffset = new Vector3(0f, 0.01f, 0f);
		private static readonly int[] PlaneTriangles = new int[] { 0, 1, 2, 2, 1, 3 };
		private static readonly Vector3[] PlaneNormals = new Vector3[] { Vector3.up, Vector3.up, Vector3.up, Vector3.up };

		private SceneView sceneView;
		private Plane plane = new Plane(Vector3.up, Vector3.zero);
		private float lastPlaneY = 0f;
		private bool gridVisible = false;
		private GameObject previewFab = null;
		private Transform previewTr = null;
		private IntVector3 lastClickPos;
		private CursorStyle lastDeleteCursorStyle = CursorStyle.Delete;

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region pub

		public void Render(SceneView sceneView, bool gridMustBeVisible)
		{
			if (!TileEd.Instance.group.visible)
			{
				gridMustBeVisible = false;
				ShowMessage(GC_GroupNotVisible, sceneView);
			}
			else if (TileEd.Instance.group.combined && TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.CanGroupCombine())
			{
				gridMustBeVisible = false;
				ShowMessage(GC_GroupCombined, sceneView);
			}

			if (gridMustBeVisible != gridVisible)
			{
				if (gridMustBeVisible)
				{
					gridVisible = true;
					if (previewTr != null) previewTr.gameObject.SetActive(true);
				}
				else
				{
					gridVisible = false;
					if (previewTr != null) previewTr.gameObject.SetActive(false);
					return;
				}
			}

			if (gridVisible)
			{
				this.sceneView = sceneView;
				TileEdGUI.LoadSceneResources();
				DrawGrid();
				DrawCursor();
			}
		}

		public void OnGridVisibleChange(bool visible)
		{
			gridVisible = visible;
			if (previewTr != null) previewTr.gameObject.SetActive(visible);
		}

		public void ShowMessage(GUIContent gc, SceneView sceneView)
		{
			if (Event.current.type == EventType.Repaint)
			{
				Handles.BeginGUI();
				Vector2 v = TileEdGUI.Styles.GridSceneMessage.CalcSize(gc);
				Rect r = new Rect(sceneView.position.width / 2 - v.x / 2, 5, v.x, v.y);
				TileEdGUI.Styles.GridSceneMessage.Draw(r, gc, false, false, false, false);
				Handles.EndGUI();
			}
		}

		public void OnPreviewToggle()
		{
			// make sure there is not some old object present
			if (previewTr != null) Object.DestroyImmediate(previewTr.gameObject);
			else plyEdUtil.FindAndDestroy(PREVIEW_OBJ_NAME, typeof(GameObject)); // just to be sure
			previewTr = null;

			// create new if should be visible
			if (TileEd.Instance.group.showPreview && previewFab != null)
			{
				GameObject go = Object.Instantiate(previewFab);
				go.hideFlags = HideFlags.HideAndDontSave;
				go.name = PREVIEW_OBJ_NAME;
				go.SetActive(gridVisible);
				previewTr = go.transform;
				previewTr.position = gridWorldPos + PreviewOffset;
			}
		}

		public void UpdatePreviewObject(GameObject fab, float rotation)
		{
			if (previewFab != fab)
			{
				DestroyPreview();
				previewFab = fab;
				if (previewFab != null && TileEd.Instance.group != null && TileEd.Instance.group.showPreview)
				{
					GameObject go = Object.Instantiate(previewFab);
					go.hideFlags = HideFlags.HideAndDontSave;
					plyEdUtil.SetHideFlagsRecursive(go, HideFlags.HideAndDontSave);
					plyEdUtil.SetLayerRecursive(go, LayerMask.NameToLayer("Ignore Raycast"));
					go.name = PREVIEW_OBJ_NAME;
					go.SetActive(gridVisible);
					previewTr = go.transform;
					previewTr.position = gridWorldPos + PreviewOffset;

					plyEdUtil.HideWireframes(go);
					plyEdUtil.SetStaticEditorFlagsRecursive(go, 0, 1); // idx 1 = non-walkable but that should not matter since no static flags are set
				}
			}

			if (previewTr != null)
			{
				previewTr.rotation = Quaternion.Euler(0f, rotation, 0f);
			}
		}

		public void UpdatePreviewObjectRotation(float rotation)
		{
			if (previewTr != null)
			{
				previewTr.rotation = Quaternion.Euler(0, rotation, 0);
			}
		}

		public void UpdatePreviewObjectYPos(float y)
		{
			if (previewTr != null)
			{
				previewTr.position = new Vector3(previewTr.position.x, y, previewTr.position.z);
			}
		}

		private void DestroyPreview()
		{
			if (previewTr != null) Object.DestroyImmediate(previewTr.gameObject);
			else plyEdUtil.FindAndDestroy(PREVIEW_OBJ_NAME, typeof(GameObject)); // just to be sure
			previewTr = null;
			previewFab = null;
		}

		public void ClearPasteMode()
		{
			if (TileEd.grid.cursorMode == TileEdCursorMode.Paste)
			{
				cursorMode = TileEdCursorMode.Normal;
				UpdatePreviewObject(null, 0f);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region events

		public void HandleEvents(SceneView sceneView)
		{
			if (gridVisible == false) return;

			this.sceneView = sceneView;
			Event ev = Event.current;

			// check if Shift+F - move to tile 0x0x0
			if (ev.commandName == "FrameSelectedWithLock")
			{
				if (ev.type == EventType.ExecuteCommand) { sceneView.LookAt(Vector3.zero); ev.Use(); }
				if (ev.type == EventType.ValidateCommand) ev.Use();
			}

			// check if F (Frame Selected) was pressed. Normally this would cause the whole map to be framed but I only want scene to look at the grid cursor position
			if (ev.commandName == "FrameSelected")
			{
				if (ev.type == EventType.ExecuteCommand) { sceneView.LookAt(gridWorldPos); ev.Use(); }
				if (ev.type == EventType.ValidateCommand) ev.Use();
			}

			// let tool handle events
			TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.HandleGridEvents(ev);

			// check if should be in delete mode or not
			if (ev.modifiers == EventModifiers.Shift && cursorMode != TileEdCursorMode.Delete)
			{
				ClearPasteMode();
				cursorMode = TileEdCursorMode.Delete;
				if (previewTr != null) previewTr.gameObject.SetActive(false);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
			else if (ev.modifiers != EventModifiers.Shift && cursorMode == TileEdCursorMode.Delete)
			{
				cursorMode = TileEdCursorMode.Normal;
				if (previewTr != null) previewTr.gameObject.SetActive(true);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}

			// check if should be in mark mode or not
			if (ev.modifiers == EventModifiers.Control && cursorMode != TileEdCursorMode.Mark && cursorMode != TileEdCursorMode.Paste)
			{
				cursorMode = TileEdCursorMode.Mark;
				if (previewTr != null) previewTr.gameObject.SetActive(false);
				plyEdUtil.RepaintInspector(typeof(TileEd));
			}
			//else if (ev.modifiers != EventModifiers.Control && cursorMode == TileEdCursorMode.Mark)
			else if (cursorMode == TileEdCursorMode.Mark)
			{
				// Control Modifier does not seem to "stick" so I'll check against actual keys
				if (ev.modifiers != EventModifiers.Control || ev.type == EventType.KeyUp && (ev.keyCode == KeyCode.LeftControl || ev.keyCode == KeyCode.RightControl))
				{
					cursorMode = TileEdCursorMode.Normal;
					if (previewTr != null) previewTr.gameObject.SetActive(true);
					plyEdUtil.RepaintInspector(typeof(TileEd));
				}
			}

			// reset few things when mouse button released
			if (ev.type == EventType.MouseUp)
			{
				lastClickPos.defined = false; // so that a new left-click on same tile will result in a forced call of ed.OnGridLeftClick()
			}

			// left-click/drag in grid (Shift+Left = delete tile) (Ctrl+Click = Select)
			if ((ev.type == EventType.MouseDown || ev.type == EventType.MouseDrag) && (ev.button == 0 && (ev.modifiers == EventModifiers.None || ev.modifiers == EventModifiers.Shift || ev.modifiers == EventModifiers.Control)))
			{
				UpdateGridPosition(ev.mousePosition);

				gridPos = new IntVector3()
				{
					x = Mathf.RoundToInt(gridWorldPos.x / TileEd.Instance.group.tileSize),
					y = TileEd.Instance.group.gridYPos,
					z = Mathf.RoundToInt(gridWorldPos.z / TileEd.Instance.group.tileSize)
				};

				if (!lastClickPos.defined || lastClickPos != gridPos)
				{
					lastClickPos = gridPos; // this is so that i do not continuously call ed.OnGridLeftClick() while the click/drag position did not actually change

					if (TileEd.Instance.group.brushSize == 1)
					{
						TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnGridClick(new IntVector3[] { gridPos }, cursorMode, ev.type == EventType.MouseDrag, mouseWorldPos);
					}
					else
					{
						// calculate which positions in grid the brush covers
						IntVector3[] gridPositions = new IntVector3[TileEd.Instance.group.brushSize * TileEd.Instance.group.brushSize];

						int end = (TileEd.Instance.group.brushSize / 2);
						int start = -end + (TileEd.Instance.group.brushSize % 2 == 0 ? 1 : 0);
						int idx = -1;

						for (int x = start; x <= end; x++)
						{
							for (int z = start; z <= end; z++)
							{
								idx++;
								gridPositions[idx] = gridPos + new IntVector3(x, 0, z);
							}
						}

						// and send click to active tool
						TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.OnGridClick(gridPositions, cursorMode, ev.type == EventType.MouseDrag, mouseWorldPos);
					}
				}

				ev.Use();
				return;
			}

			// move the grid
			if (ev.type == EventType.MouseMove || gridPosDirty)
			{				
				UpdateGridPosition(ev.mousePosition);
				return;
			}

			if (ev.type == EventType.ScrollWheel)
			{
				// move grid up/ down
				if (ev.modifiers == (EventModifiers.Control | EventModifiers.Shift))
				{
					if (ev.delta.y != 0.0f)
					{
						TileEd.Instance.group.gridYPos += (ev.delta.y > 0.0f ? -1 : 1);
					}
					else if (ev.delta.x != 0.0f)
					{
						TileEd.Instance.group.gridYPos += (ev.delta.x > 0.0f ? -1 : 1);
					}

					ev.Use();
					UpdateGridPosition(ev.mousePosition);
					sceneView.Repaint();
					plyEdUtil.RepaintInspector(typeof(TileEd));
					return;
				}

				// resize brush
				if (ev.modifiers == EventModifiers.Control)
				{
					TileEd.Instance.group.brushSize += (ev.delta.y > 0.0f ? -1 : 1);
					if (TileEd.Instance.group.brushSize < 1) TileEd.Instance.group.brushSize = 1;
					if (TileEd.Instance.group.brushSize > 5) TileEd.Instance.group.brushSize = 5;
					UpdateGridPosition(ev.mousePosition);
					ev.Use();
					sceneView.Repaint();
					plyEdUtil.RepaintInspector(typeof(TileEd));
					return;
				}
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
		#region grid

		private void UpdateGridPosition(Vector3 mousePosition)
		{
			gridPosDirty = false;
			float y = TileEd.Instance.group.tileHeight * TileEd.Instance.group.gridYPos;

			if (lastPlaneY != y)
			{
				lastPlaneY = y;
				plane = new Plane(Vector3.up, new Vector3(0f, lastPlaneY, 0f));
			}

			float d;
			Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
			if (plane.Raycast(ray, out d))
			{
				// find world position
				mouseWorldPos = ray.GetPoint(d);
				mouseWorldPos.y = y;
				gridWorldPos = mouseWorldPos;

				RecalcCalcGridPos();

				if (previewTr != null)
				{
					//if (TileEd.Instance.group.brushSize % 2 == 0)
					//{
					//	previewTr.position = gridWorldPos + new Vector3(TileEd.Instance.group.tileSize / 2f, 0f, TileEd.Instance.group.tileSize / 2f);
					//}
					//else
					//{
					//	previewTr.position = gridWorldPos;
					//}

					//if (TileEd.Instance.group.brushSize == 1)
					//{
					//	previewTr.position = TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.PreviewPosition(gridWorldPos, mouseWorldPos, gridWorldPos, gridPos);
					//}
					//else
					//{
					//	if (TileEd.Instance.group.brushSize % 2 == 0) previewTr.position = gridWorldPos + new Vector3(TileEd.Instance.group.tileSize / 2f, 0f, TileEd.Instance.group.tileSize / 2f);
					//	else previewTr.position = gridWorldPos;
					//}
					//previewTr.position += PreviewOffset;

					float offs = TileEd.Instance.group.centreTiles ? 
							(TileEd.Instance.group.brushSize % 2 == 0 ? TileEd.Instance.group.tileSize / 2f : 0f) :
							(TileEd.Instance.group.brushSize % 2 == 0 ? 0f : -TileEd.Instance.group.tileSize / 2f);
					Vector3 previewPos = gridWorldPos + new Vector3(offs, 0f, offs);

					if (TileEd.Instance.group.brushSize == 1)
					{
						previewTr.position = TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.PreviewPosition(previewPos, mouseWorldPos, gridWorldPos, gridPos);
						previewTr.position += PreviewOffset;
					}
					else
					{
						previewTr.position = previewPos + PreviewOffset;
					}
				}

				// issue repaint
				sceneView.Repaint();
			}
		}

		public void RecalcCalcGridPos()
		{
			if (TileEd.Instance.group.centreTiles == false)
			{
				float offs = TileEd.Instance.group.tileSize / 2f;
				gridWorldPos.x += offs;
				gridWorldPos.z += offs;
			}

			// snap position to grid
			gridWorldPos.x = TileEd.Instance.group.tileSize * Mathf.Round(gridWorldPos.x / TileEd.Instance.group.tileSize);
			gridWorldPos.y = TileEd.Instance.group.tileHeight * TileEd.Instance.group.gridYPos;
			gridWorldPos.z = TileEd.Instance.group.tileSize * Mathf.Round(gridWorldPos.z / TileEd.Instance.group.tileSize);

			gridPos = new IntVector3()
			{
				x = Mathf.RoundToInt(gridWorldPos.x / TileEd.Instance.group.tileSize),
				y = TileEd.Instance.group.gridYPos,
				z = Mathf.RoundToInt(gridWorldPos.z / TileEd.Instance.group.tileSize)
			};
		}

		private void DrawCursor()
		{
			if (TileEdGlobal.activeTileEdToolIdx >= 0)
			{
				if (TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.CanShowCursor() == false) return;
			}

			if (TileEdGlobal.cursorStyleChanged)
			{
				TileEdGlobal.cursorStyleChanged = false;
				TileEdGUI.cursorMats[0].SetTexture(TileEdGUI.matTexturePropID, TileEdGUI.cursorTextures[0]);
				TileEdGUI.cursorMats[1].SetTexture(TileEdGUI.matTexturePropID, TileEdGUI.cursorTextures[1]);
			}

			if (cursorMode == TileEdCursorMode.Normal || cursorMode == TileEdCursorMode.Paste)
			{
				TileEdGUI.cursorMats[0].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridPlacementCursor);
				TileEdGUI.cursorMats[1].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridPlacementCursor);
			}
			else if (cursorMode == TileEdCursorMode.Delete)
			{
				if (TileEdGlobal.activeTileEdToolIdx >= 0)
				{
					lastDeleteCursorStyle = TileEdGlobal.editors[TileEdGlobal.activeTileEdToolIdx].ed.WantedDeleteCursorStyle();
				}
				else
				{
					lastDeleteCursorStyle = CursorStyle.Delete;
				}

				TileEdGUI.cursorMats[0].SetColor(TileEdGUI.matColorPropID, lastDeleteCursorStyle == CursorStyle.Delete ? TileEdGlobal.gridDeleteCursor : TileEdGlobal.gridSculptDownCursor);
				TileEdGUI.cursorMats[1].SetColor(TileEdGUI.matColorPropID, lastDeleteCursorStyle == CursorStyle.Delete ? TileEdGlobal.gridDeleteCursor : TileEdGlobal.gridSculptDownCursor);
			}
			else if (cursorMode == TileEdCursorMode.Mark)
			{
				TileEdGUI.cursorMats[0].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridMarkCursor);
				TileEdGUI.cursorMats[1].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridMarkCursor);
			}

			// --------------------------------------------------------------------------------------------------------

			float sz = TileEd.Instance.group.tileSize / 2f * TileEd.Instance.group.brushSize;
			//float offs = (TileEd.Instance.group.brushSize % 2 == 0 ? TileEd.Instance.group.tileSize / 2f : 0f);
			float offs = TileEd.Instance.group.centreTiles ? 
				(TileEd.Instance.group.brushSize % 2 == 0 ? TileEd.Instance.group.tileSize / 2f : 0f) :
				(TileEd.Instance.group.brushSize % 2 == 0 ? 0f : -TileEd.Instance.group.tileSize / 2f);
			
			// update the grid mesh data
			Vector3[] verts = new Vector3[]
			{
				new Vector3(gridWorldPos.x - sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z + sz + offs),
				new Vector3(gridWorldPos.x + sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z + sz + offs),
				new Vector3(gridWorldPos.x - sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z - sz + offs),
				new Vector3(gridWorldPos.x + sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z - sz + offs),
			};

			sz = TileEd.Instance.group.brushSize;
			Vector2[] uvs = new Vector2[]
			{
				new Vector2(0f, 0f),
				new Vector2(sz, 0f),
				new Vector2(0f, sz),
				new Vector2(sz, sz),
			};

			// update grid mesh
			TileEdGUI.cursorMesh.Clear();
			TileEdGUI.cursorMesh.vertices = verts;
			TileEdGUI.cursorMesh.triangles = PlaneTriangles;
			TileEdGUI.cursorMesh.normals = PlaneNormals;
			TileEdGUI.cursorMesh.uv = uvs;

			// --------------------------------------------------------------------------------------------------------

			// render
			if (TileEdGUI.cursorMats[0].SetPass(0))
			{
				Graphics.DrawMeshNow(TileEdGUI.cursorMesh, Vector3.zero, Quaternion.identity);
			}

			if (TileEdGUI.cursorMats[1].SetPass(0))
			{
				Graphics.DrawMeshNow(TileEdGUI.cursorMesh, Vector3.zero, Quaternion.identity);
			}

			#if DEBUG
			if (TileEdGlobal.debugGridNumbers)
			{
				// show coords around cursor
				TileEdGUI.Handles_DrawGridCoord(gridWorldPos, gridPos.ToString());
				for (int i = 0; i < 8; i++)
				{
					IntVector3 p = gridPos + Direction[i];
					TileEdGUI.Handles_DrawGridCoord(new Vector3(p.x * TileEd.Instance.group.tileSize, p.y * TileEd.Instance.group.tileHeight, p.z * TileEd.Instance.group.tileSize), i.ToString() + "::" + p.ToString());
				}
			}
			#endif
		}

		private void DrawGrid()
		{
			if (TileEdGlobal.gridStyleChanged)
			{
				TileEdGlobal.gridStyleChanged = false;
				TileEdGUI.gridMats[0].SetTexture(TileEdGUI.matTexturePropID, TileEdGUI.gridTextures[(TileEdGlobal.gridStyle[0] == 0 ? 0 : 2) + (TileEdGlobal.gridThin[0] ? 0 : 1)]);
				TileEdGUI.gridMats[1].SetTexture(TileEdGUI.matTexturePropID, TileEdGUI.gridTextures[(TileEdGlobal.gridStyle[1] == 0 ? 0 : 2) + (TileEdGlobal.gridThin[1] ? 0 : 1)]);
				TileEdGUI.gridMats[0].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridColor[0]);
				TileEdGUI.gridMats[1].SetColor(TileEdGUI.matColorPropID, TileEdGlobal.gridColor[1]);
			}

			// --------------------------------------------------------------------------------------------------------

			float sz = TileEd.Instance.group.tileSize / 2f * GridExpand;
			float offs = TileEd.Instance.group.centreTiles ? (GridExpand % 2 == 0 ? TileEd.Instance.group.tileSize / 2f : 0f) : 0f;

			// update the grid mesh data
			Vector3[] verts = new Vector3[]
			{
				new Vector3(gridWorldPos.x - sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z + sz + offs),
				new Vector3(gridWorldPos.x + sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z + sz + offs),
				new Vector3(gridWorldPos.x - sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z - sz + offs),
				new Vector3(gridWorldPos.x + sz + offs, gridWorldPos.y + 0.05f, gridWorldPos.z - sz + offs),
			};

			sz = GridExpand;
			Vector2[] uvs = new Vector2[]
			{
				new Vector2(0f, 0f),
				new Vector2(sz, 0f),
				new Vector2(0f, sz),
				new Vector2(sz, sz),
			};

			// update grid mesh
			TileEdGUI.gridMesh.Clear();
			TileEdGUI.gridMesh.vertices = verts;
			TileEdGUI.gridMesh.triangles = PlaneTriangles;
			TileEdGUI.gridMesh.normals = PlaneNormals;
			TileEdGUI.gridMesh.uv = uvs;

			// --------------------------------------------------------------------------------------------------------

			// render grid
			if (TileEdGUI.gridMats[0].SetPass(0))
			{
				Graphics.DrawMeshNow(TileEdGUI.gridMesh, Vector3.zero, Quaternion.identity);
			}

			if (TileEdGUI.gridMats[1].SetPass(0))
			{
				Graphics.DrawMeshNow(TileEdGUI.gridMesh, Vector3.zero, Quaternion.identity);
			}
		}

		#endregion
		// ------------------------------------------------------------------------------------------------------------
    }
}
