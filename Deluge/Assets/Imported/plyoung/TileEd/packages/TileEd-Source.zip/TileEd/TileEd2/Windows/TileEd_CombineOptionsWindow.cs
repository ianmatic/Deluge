﻿using UnityEngine;
using UnityEditor;
using plyLibEditor;

namespace TileEd
{
	public class TileEd_CombineOptionsWindow : EditorWindow
	{
		public bool GenerateUV2 { get; private set; }
		public UnwrapParam GenerateUV2WithUnwrapParam { get; private set; }

		private System.Action<TileEd_CombineOptionsWindow> callback;
		private bool accepted = false;
		private bool lostFocus = false;
		private static readonly GUIContent GC_DoGen = new GUIContent("Generate Secondary UV Set (uv2)");
		private static readonly GUIContent GC_WrapSettings = new GUIContent("Unwrapping settings");
		private static readonly GUIContent GC_angleError = new GUIContent("angleError", "Maximum allowed angle distortion (0..1).");
		private static readonly GUIContent GC_areaError = new GUIContent("areaError", "Maximum allowed area distortion (0..1).");
		private static readonly GUIContent GC_hardAngle = new GUIContent("hardAngle", "This angle (in degrees) or greater between triangles will cause seam to be created.");
		private static readonly GUIContent GC_packMargin = new GUIContent("packMargin", "How much uv-islands will be padded.");

		public static void ShowWiz(System.Action<TileEd_CombineOptionsWindow> callback)
		{
			TileEd_CombineOptionsWindow wiz = GetWindow<TileEd_CombineOptionsWindow>(true, "Combine Options", true);

			UnwrapParam.SetDefaults(out UnwrapParam uvparams);
			wiz.GenerateUV2WithUnwrapParam = uvparams;
			wiz.GenerateUV2 = false;

			wiz.callback = callback;
			wiz.minSize = wiz.maxSize = new Vector2(250, 170);
			wiz.ShowUtility();
		}

		protected void OnFocus() { lostFocus = false; }
		protected void OnLostFocus() { lostFocus = true; }

		protected void Update()
		{
			if (lostFocus) this.Close();
			if (accepted && callback != null) callback(this);
		}

		protected void OnGUI()
		{
			EditorGUILayout.Space();
			EditorGUIUtility.labelWidth = 100;

			GenerateUV2 = EditorGUILayout.ToggleLeft(GC_DoGen, GenerateUV2);

			EditorGUILayout.Space();
			if (GenerateUV2)
			{
				GUILayout.BeginHorizontal();
				{
					GUILayout.Label(GC_WrapSettings);
					GUILayout.Space(10);
					if (GUILayout.Button("Reset", EditorStyles.miniButton))
					{
						plyEdGUI.ClearFocus();
						UnwrapParam.SetDefaults(out UnwrapParam uvparams);
						GenerateUV2WithUnwrapParam = uvparams;
					}
					GUILayout.FlexibleSpace();
				}
				GUILayout.EndHorizontal();
				EditorGUILayout.Space();

				EditorGUI.BeginChangeCheck();
				EditorGUI.indentLevel++;
				float angleError = EditorGUILayout.FloatField(GC_angleError, GenerateUV2WithUnwrapParam.angleError);
				float areaError = EditorGUILayout.FloatField(GC_areaError, GenerateUV2WithUnwrapParam.areaError);
				float hardAngle = EditorGUILayout.FloatField(GC_hardAngle, GenerateUV2WithUnwrapParam.hardAngle);
				float packMargin = EditorGUILayout.FloatField(GC_packMargin, GenerateUV2WithUnwrapParam.packMargin);
				EditorGUI.indentLevel--;
				if (EditorGUI.EndChangeCheck())
				{
					GenerateUV2WithUnwrapParam = new UnwrapParam
					{
						angleError = angleError,
						areaError = areaError,
						hardAngle = hardAngle,
						packMargin = packMargin
					};
				}
			}

			GUILayout.FlexibleSpace();
			EditorGUILayout.BeginHorizontal();
			{
				GUILayout.FlexibleSpace();
				if (GUILayout.Button("Accept", GUILayout.Width(80))) accepted = true;
				GUILayout.Space(5);
				if (GUILayout.Button("Cancel", GUILayout.Width(80))) this.Close();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			GUILayout.Space(10);
		}

		// ------------------------------------------------------------------------------------------------------------
	}
}
