﻿using UnityEngine;
using System.Collections.Generic;
using plyLib;

namespace TileEd
{
	/// <summary>
	/// Tile data. Note that this can be either Tiles or Props.
	/// In fact, this could be any other map object that a new TileEd Tool might define
	/// </summary>
	[System.Serializable]
	public class TileEdMapTile
	{
		/// <summary> the TileEd tool that placed and knows how to edit this tile.
		/// By default TileEd include 2 tools.
		/// 1: Tiles (TileEd_Ed_Tiles.TOOL_IDENT)
		/// 2: Props (TileEd_Ed_Props.TOOL_IDENT)
		/// </summary>
		public int toolIdent;

		/// <summary> Extra data associated with this tile. Each tool will use this differently.
		/// Ex, the tile set this tile belongs to, the prefab from the tile, or even rotation. </summary>
		public int[] data;

		/// <summary> The grid position of this tile. This is normally unique among tiles in the same group but
		/// there are other objects, like Props, which can share a grid position. This is also the value used
		/// to create the name of the tile GameObject in the scene, ex "(1x-3x4)" </summary>
		public IntVector3 gridPos;

		/// <summary> Offset from the tile centre, if applicable. Mainly used by the Props tool. </summary>
		public Vector3 offsPos;

		/// <summary> Additional data a tool might need to add to the tile. This is data that the int[] data
		/// can't handle. The props tool mainly uses this for things like prop scale, rotation, etc. </summary>
		public string[] extraData = new string[0];

		/// <summary> This is the meta (custom data) the user entered for the tile or prop when setting up the Tile/ Prop set.
		/// This data comes from either TileEdTile.meta or TileEdProp.meta. A developer can use this to attach addition data to tiles to read at runtime. </summary>
		public string meta;

		//[System.NonSerialized] public GameObject cachedTileObject=null; - disabled since it causes problem when i use this after/during an undo

		// ------------------------------------------------------------------------------------------------------------

		public TileEdMapTile Copy()
		{
			TileEdMapTile t = new TileEdMapTile();
			t.toolIdent = this.toolIdent;
			t.data = new int[this.data.Length];
			for (int i = 0; i < this.data.Length; i++) t.data[i] = this.data[i];
			t.gridPos = this.gridPos;
			t.offsPos = this.offsPos;
			t.extraData = new string[this.extraData.Length];
			for (int i = 0; i < this.extraData.Length; i++) t.extraData[i] = this.extraData[i];
			t.meta = this.meta;
			return t;
		}

		// ------------------------------------------------------------------------------------------------------------
    }
}
