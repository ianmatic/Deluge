jQuery(function($)  
{
    $("#contact_form").submit(function()
    {
    	$("#submit").hide();
    	$("#gif").show();
        var email = $("#email").val();
        var name = $("#name").val();
        var msg = $("#msg").val();        
        $.ajax(
        {
            type: "POST",
            url: "http://www.plyoung.com/submit2.php",
            data: {'name':name,'email':email,'msg':msg}
        })
        .done(function(response) {
        	$("#submit").show();
        	$("#gif").hide();
			$("#result").hide().html('<div data-alert class="alert-box success">Message Sent</div>').slideDown();
            $("#name").val('');
            $("#email").val('');
            $("#msg").val('');
        })
        .fail(function(response) {
        	$("#submit").show();
        	$("#gif").hide();
            $("#result").hide().html('<div data-alert class="alert-box alert">Failed to send</div>').slideDown();
        });
        return false;
    });
});
